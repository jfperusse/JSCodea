portalColors = {
    color(255, 14, 0),
    color(108, 255, 0),
    color(0, 44, 255)
}

laserColors = {
    color(0, 255, 0),
    color(255, 255, 0),
    color(255, 125, 0),
    color(255, 0, 0)
}

doorColors = {
    color(255, 14, 0),
    color(108, 255, 0),
    color(0, 44, 255)
}

doorDarkColors = {
    color(100, 14, 0),
    color(8, 100, 0),
    color(0, 44, 100)
}

function drawCell(x, y, levelCol, levelRow)
    if levelCol >= 1 and levelCol <= levelWidth and
    levelRow >= 1 and levelRow <= levelHeight then
        value = game:getValue(levelRow, levelCol)
        box = getBox(levelRow, levelCol)
        local byteValue = string.byte(value)
        local isPortal = isPortalByte(byteValue)
        if isPortal then
            local portalIndex = byteValue - firstPortal + 1
            local portalColor = portalColors[portalIndex]
            tint(portalColor)
            sprite(animPortal.image, x, y, cellSize, cellSize)
            tint(255)
        end
        
        if value == "*" and (levelCol ~= playerCol or levelRow ~= playerLine) then
            sprite(animCrystal.image, x, y, cellSize, cellSize)
        end
        
        local itemColor = color(255)
        if isLaser(value) then
            local offset = getLevelType(levelRow, levelCol)
            local phase = (((laserPhase - 1) + (offset - 1)) % 4) + 1
            itemColor = laserColors[phase]
            sprite(laserSprites[value].image, x, y, cellSize, cellSize)
            tint(itemColor)
            sprite(laserLightSprites[value].image, x, y, cellSize, cellSize)
            tint(255)
        elseif isDoor(value) then
            local door = getDoor(levelRow, levelCol)
            local doorColor
            local doorOpened = isDoorOpened(levelRow, levelCol)
            if doorOpened == door.startOpened then
                doorColor = doorDarkColors[door.type]
            else
                doorColor = doorColors[door.type]
            end
            if doorOpened then
                sprite(doorOpenedSprite.image, x, y, cellSize, cellSize)
                tint(doorColor)
                sprite(doorLightsOpenedSprite.image, x, y, cellSize, cellSize)
            else
                sprite(doorClosedSprite.image, x, y, cellSize, cellSize)
                tint(doorColor)
                sprite(doorLightsClosedSprite.image, x, y, cellSize, cellSize)
            end            
            tint(255)
        elseif isSwitch(value) then
            local switch = getSwitch(levelRow, levelCol)
            local blood = game:getBlood(levelRow, levelCol)
            
            local switchColor
            if blood ~= nil and blood > 0 then
                switchColor = doorColors[switch.type]
            else
                switchColor = doorDarkColors[switch.type]
            end
            
            sprite(switchSprite.image, x, y, cellSize, cellSize)
            tint(switchColor)
            sprite(switchLights.image, x, y, cellSize, cellSize)
            tint(255)
        end
        
        itemCount = countGround(levelRow, levelCol)
        if itemCount > 0 then
            index = math.floor(os.time()) % itemCount + 1
            value = getGround(levelRow, levelCol, index)
            if value == "p" then
                tint(92, 32, 104)
                sprite(animPortablePortal.image, x, y, cellSize, cellSize)
                tint(255)
            else
                sprite(itemSprites[value].image, x, y, cellSize, cellSize)
            end
        end
        
        fill(255)
        
        if levelCol == playerCol and levelRow == playerLine then
            sprite(animRobot.image, x, y, cellSize, cellSize)
        end
        
        if box ~= nil then
            sprite(boxSprite.image, x, y, cellSize, cellSize)
        end
    end
end

function drawFull()
    local width = levelWidth * cellSize
    local height = levelHeight * cellSize
    
    local x = math.floor(WIDTH/2 - width/2 - cellSize)
    local y = math.floor(levelY - height/2 - cellSize)
    
    spriteMode(CORNER)
    for row = 1, levelHeight + 2 do
        for col = 1, levelWidth + 2 do
            local levelCol = col - 1
            local levelRow = levelHeight - (row - 1) + 1
            if fullLevelLimit == nil or 
            isEditorLevel or
            (math.abs(levelRow - playerLine) <= fullLevelLimit and math.abs(levelCol - playerCol) <= fullLevelLimit) then
                local value = game:getValue(levelRow, levelCol)
                local currentX = x + (col - 1) * cellSize
                local currentY = y + (row - 1) * cellSize
                for layer = 1, #levelGrid[row][col] do
                    local spr = levelGrid[row][col][layer]
                    if spr.image ~= nil then
                        sprite(spr.image, currentX, currentY, cellSize, cellSize)
                    end
                end
                if levelRow >= 1 and levelRow <= levelHeight and levelCol >= 1 and levelCol <= levelWidth then
                    if value == "f" then
                        sprite(animFan.image, currentX, currentY, cellSize, cellSize)
                    end
                    cellBlood = blood[levelRow][levelCol]
                    if cellBlood > 0 then
                        cellBlood = math.min(3, cellBlood)
                        for index = 1, cellBlood do
                            sprite(bloodSprite.image, currentX, currentY, cellSize, cellSize)
                        end
                    end
                    if value == "~" then
                        sprite(waterSprite.image, currentX, currentY, cellSize, cellSize)
                    end
                end
            end
        end
    end
    
    for row = 1, levelHeight do
        for col = 1, levelWidth do
            local levelRow = levelHeight - row + 1
            if fullLevelLimit == nil or isEditorLevel or
            (math.abs(levelRow - playerLine) <= fullLevelLimit and math.abs(col - playerCol) <= fullLevelLimit) then
                drawCell(x + (col) * cellSize, y + (row) * cellSize, col, levelRow)
            end
        end
    end
end

function drawGame()
    if intro then
        local alpha = 255
        if introTime < 3 then alpha = (introTime / 3.0) end
        if introTime > 6 then
            alpha = (9 - introTime) / 3.0
            if alpha <= 0 then
                endIntro()
            end
        end
        fill(255, 255, 255, alpha * 255)
        font("Copperplate")
        fontSize(96)
        textMode(CENTER)
        textAlign(CENTER)
        
        pushMatrix()
        translate(WIDTH/2,HEIGHT/2)
        scale(0.7 + math.min(0.3, (introTime / 9.0) * 0.3))
        text(localization:get("title", gameText))
        
        translate(0, -100)
        font("AcademyEngravedLetPlain")
        fontSize(40)
        text("Introduction")
        introTime = introTime + 0.01667
        popMatrix()
        return
    end
    
    font("SourceSansPro-Bold")
    
    fontSize(charSize)
    
    textMode(CENTER)
    textAlign(CENTER)
    
    if showLevel then
        if anims ~= nil then
            updateAnims(anims)
        end
        
        drawFull()
    end
    
    if levelIndex > 0 then
        if levelNames[levelIndex] ~= nil then
            fill(255)
            textMode(CORNER)
            local levelName = localization:get(levelNames[levelIndex], localizedLevelNames) 
            local levelString = levelName .. " (" .. levelIndex .. " / " .. #levels .. ")"
            local textWidth = textSize(levelString)
            text(levelString, WIDTH - textWidth - 5, 65)
        end
        
        if levelAuthors[levelIndex] ~= "" then
            fontSize(12)
            fill(100)
            textMode(CORNER)
            local authorText = localization:get("levelBy", gameText) .. levelAuthors[levelIndex]
            local textWidth = textSize(authorText)
            text(authorText, WIDTH - textWidth - 5, 90)
            fontSize(charSize)
        end
    end
    
    game:draw()
    
    if gameController ~= nil then
        textMode(CENTER)
        text("Controller connected. Battery " .. gameController.controller.battery.batteryLevel * 100 .. " %", WIDTH / 2, 15)
    end
    
    if _isJSCodea then
        textMode(CORNER)
        fill(100)
        local jscodea = localization:get("jscodea", gameText)
        text(jscodea, 5, 65)
    end    
end
