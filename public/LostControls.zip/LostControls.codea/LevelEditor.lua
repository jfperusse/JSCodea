LevelEditor = class()

function LevelEditor:init()
    self.mandatoryCharacters = "P*"
    self.moduleCharacters = "NSEWBMVH"
    self.inventoryCharacters = self.moduleCharacters .. "XIp"
    self.singleCharacters = self.mandatoryCharacters
    self.topCharacters = self.mandatoryCharacters .. self.inventoryCharacters
    self.bottomCharacters = " #_~$123<>^vdD.ofe"
    self.typeCharacters = {
        ["<"] = 4,
        [">"] = 4,
        ["^"] = 4,
        ["v"] = 4,
        ["d"] = 3,
        ["D"] = 3,
        ["."] = 3
    } 
    self.buttonSprites = {
        ["P"] = animRobot.image,
        ["*"] = animCrystal.image,
        ["#"] = defaultWallSprite.image,
        ["p"] = animPortablePortal.image,
        ["f"] = animFan.image,
        ["e"] = animElectric.image,
        ["$"] = sprites[164].image,
        ["~"] = waterSprite.image,
        ["_"] = sprites[177].image,
        ["1"] = animPortal.image,
        ["2"] = animPortal.image,
        ["3"] = animPortal.image,
        ["v"] = laserSprites["v"].image,
        ["<"] = laserSprites["<"].image,
        [">"] = laserSprites[">"].image,
        ["^"] = laserSprites["^"].image,
        ["d"] = doorOpenedSprite.image,
        ["D"] = doorClosedSprite.image,
        ["."] = switchSprite.image,
        ["o"] = boxSprite.image,
        [" "] = asset.Eraser
    }
    self.buttonSpriteTint = {
        ["1"] = portalColors[1],
        ["2"] = portalColors[2],
        ["3"] = portalColors[3],
    }

    self.selectedCharacter = "P"
    self.startingInventory = {}
    self.gridSize = 18
    self.grid = {}
    self.pastedOnce = false
    
    -- Visuals generation
    self.workGrid = {}
    self.visited = {}
    self.pending = {}
    self.sprites = {}
    
    self.gridData = {}
    self.lastTouch = vec2(0, 0)
    self.bloodLevel = 0
    self.levelVisuals = {}
    self:clear()
end

function LevelEditor:addCharButtons(x, y, str)
    for char in str:gmatch(".") do
        local buttonFunction = function() 
            self.selectedCharacter = char
        end
        
        local button
        local buttonSprite = self.buttonSprites[char]
        if buttonSprite == nil and itemSprites[char] ~= nil then
            buttonSprite = itemSprites[char].image
        end
        if buttonSprite ~= nil then
            button = AddSpriteButton(x, y, 40, 40, buttonSprite, buttonFunction)
            button.spriteFit = true
            button.spriteSize = vec2(32, 32)
            button.drawRectangle = true
            if self.buttonSpriteTint[char] ~= nil then
                button.spriteTint = self.buttonSpriteTint[char]
            end
        else
            button = AddButton(x, y, 40, 40, char, buttonFunction)
        end
        button.selectionBorderOnly = true
        button.notSelectedAlpha = 1
        button.backgroundSprite = sprites[20].image
        button.selectedFunc = function()
            return self.selectedCharacter == char
        end
        
        x = x + 46
    end
    
    return x
end

function LevelEditor:clear()
    self.levelName = "LevelName"
    self.hasPlayer = false
    self.hasCrystal = false
    self.validVisuals = false
    
    for row = 1, self.gridSize do
        self.grid[row] = {}
        self.visited[row] = {}
        self.gridData[row] = {}
        for col = 1, self.gridSize do
            self.grid[row][col] = " "
            self.visited[row][col] = false
            self.gridData[row][col] = {}
            self.gridData[row][col].type = 1
            self.gridData[row][col].blood = 0
            self.gridData[row][col].electric = false
        end
    end
    
    for row = 1, self.gridSize + 2 do
        self.sprites[row] = {}
        for col = 1, self.gridSize + 2 do
            self.sprites[row][col] = {}
        end
    end

    for row = 1, self.gridSize + 4 do
        self.workGrid[row] = {}
        for col = 1, self.gridSize + 4 do
            self.workGrid[row][col] = " "
        end
    end
end

function createTimer(name)
    return {
        name = name,
        timer = os.clock(),
        paused = true,
        accum = 0
    }
end

function startTimer(name)
    return {
        name = name,
        time = os.clock(),
        paused = false,
        accum = 0
    }
end

function stopTimer(timer)
    pauseTimer(timer)
    print(timer.name .. ": " .. math.floor(timer.accum * 1000) .. "ms")
end

function pauseTimer(timer)
    if not timer.paused then
        timer.paused = true
        timer.accum = timer.accum + (os.clock() - timer.time)
    end
end

function resumeTimer(timer)
    if timer.paused then
        timer.paused = false
        timer.time = os.clock()
    end
end

function LevelEditor:setWorkGrid(levelRow, levelCol, defaultChar)
    local currentChar = self.grid[levelRow][levelCol]
    if currentChar == " " or mappingEffects[currentChar] == nil then
        self.workGrid[levelRow + 2][levelCol + 2] = defaultChar
    else
        self.workGrid[levelRow + 2][levelCol + 2] = currentChar
    end
end

function LevelEditor:getLevelVisuals()
    self.validVisuals = true
    
    while #self.pending > 0 do
        local current = table.remove(self.pending, 1)
        
        local row = current[1]
        local col = current[2]
        
        if row == 1 or row == self.gridSize or col == 1 or col == self.gridSize then
            self.validVisuals = false
        end
        
        -- Down
        if row > 1 and not self.visited[row - 1][col] and
           self.grid[row - 1][col] ~= "#" then
            table.insert(self.pending, { row - 1, col })
            self.visited[row - 1][col] = true
        end
        
        -- Up
        if row < self.gridSize and not self.visited[row + 1][col] and
           self.grid[row + 1][col] ~= "#" then
            table.insert(self.pending, { row + 1, col })
            self.visited[row + 1][col] = true
        end
        
        -- Left
        if col > 1 and not self.visited[row][col - 1] and
           self.grid[row][col - 1] ~= "#" then
            table.insert(self.pending, { row, col - 1 })
            self.visited[row][col - 1] = true
        end
        
        -- Right
        if col < self.gridSize and not self.visited[row][col + 1] and
           self.grid[row][col + 1] ~= "#" then
            table.insert(self.pending, { row, col + 1 })
            self.visited[row][col + 1] = true
        end
        
        self:setWorkGrid(row, col, "F")
    end
end

function LevelEditor:applyMappingForCell(row, col)
    local fullSize = self.gridSize + 2
    local currentMapping = levelMapping
    local centerChar = self.workGrid[fullSize - row + 2][col + 1]
    local isWall = centerChar == "#"
    local effect = mappingEffectsTable[centerChar]
    for newRow = row + 1, row - 1, -1 do
        for newCol = col - 1, col + 1 do
            if row ~= newRow or col ~= newCol then
                char = self.workGrid[fullSize - newRow + 2][newCol + 1]
                if effect[char] == nil then
                    char = "*"
                end
            else
                char = centerChar
            end
            if currentMapping ~= nil then
                currentMapping = currentMapping[char]
            else
                goto done
            end
        end
    end
    
    ::done::
    
    self.sprites[row][col] = {}
        
    if currentMapping ~= nil then
        for i = 1, #currentMapping do
            local sprIndex = currentMapping[i]
            if sprIndex ~= -1 then
                table.insert(self.sprites[row][col], sprites[sprIndex])
            end
        end
    elseif isWall then
        table.insert(self.sprites[row][col], defaultWallSprite)
    end    
end

function LevelEditor:refreshMappingAround(levelRow, levelCol)    
    local defaultChar = self.workGrid[levelRow + 2][levelCol + 2] == "F" and "F" or " "
    self:setWorkGrid(levelRow, levelCol, defaultChar)
    
    local row = self.gridSize - levelRow + 2
    local col = levelCol + 1
    for newRow = row - 1, row + 1 do
        for newCol = col - 1, col + 1 do
            self:applyMappingForCell(newRow, newCol)
        end
    end
end

function LevelEditor:applyMapping()
    local fullSize = self.gridSize + 2
    local workSize = fullSize + 2
    for row = 1, fullSize do
        for col = 1, fullSize do
            self:applyMappingForCell(row, col)
        end
    end
end

function LevelEditor:updatePreview()
    self.hasPlayer = false
    self.hasCrystal = false
    self.pending = {}
    
    local fullSize = self.gridSize + 2
    
    for fullRow = 1, fullSize do
        for fullCol = 1, fullSize do
            self.sprites[fullRow][fullCol] = {}
            if fullRow ~= 1 and fullCol ~= 1 and
               fullRow ~= fullSize and fullCol ~= fullSize then
                local row = fullRow - 1
                local col = fullCol - 1
                self.visited[row][col] = false
                local gridChar = self.grid[row][col]
                if gridChar == "P" then
                    self.hasPlayer = true
                    table.insert(self.pending, { row, col })
                elseif gridChar == "*" then
                    self.hasCrystal = true
                elseif tonumber(gridChar) ~= nil then
                    table.insert(self.pending, { row, col })
                end
                if mappingEffects[gridChar] ~= nil then
                    self.workGrid[row + 2][col + 2] = gridChar
                else
                    self.workGrid[row + 2][col + 2] = " "
                end
            end
        end
    end
    
    self:getLevelVisuals()    
    self:applyMapping()
end

function LevelEditor:generate()
    self.min_x = self.gridSize
    self.min_y = self.gridSize
    self.max_x = 1
    self.max_y = 1
    
    for row = 1, self.gridSize do
        for col = 1, self.gridSize do
            if self.grid[row][col] ~= " " or
               self.gridData[row][col].blood > 0 or
               self.gridData[row][col].electric == true then
                self.min_x = math.min(col, self.min_x)
                self.min_y = math.min(row, self.min_y)
                self.max_x = math.max(col, self.max_x)
                self.max_y = math.max(row, self.max_y)
            end
        end
    end
    
    self.hasPlayer = false
    self.hasCrystal = false
    self.level = {}
    self.levelType = {}
    self.levelBlood = {}
    self.levelElectric = {}
    for gridRow = self.min_y, self.max_y do
        local row = gridRow - self.min_y + 1
        self.level[row] = ""
        for gridCol = self.min_x, self.max_x do
            if self.grid[gridRow][gridCol] == "P" then
                self.hasPlayer = true
            end
            if self.grid[gridRow][gridCol] == "*" then
                self.hasCrystal = true
            end
            
            self.level[row] = self.level[row] .. self.grid[gridRow][gridCol]

            local col = gridCol - self.min_x + 1
            
            if self.gridData[gridRow][gridCol].type ~= 1 then
                self.levelType[vec2(row, col)] = self.gridData[gridRow][gridCol].type
            end
            
            if self.gridData[gridRow][gridCol].blood > 0 then
                self.levelBlood[vec2(row, col)] = self.gridData[gridRow][gridCol].blood
            end
            
            if self.gridData[gridRow][gridCol].electric == true then
                table.insert(self.levelElectric, vec2(row, col))
            end
        end
    end    
end

function LevelEditor:offset(x, y)
    local gridCopy = {}
    local gridDataCopy = {}
    
    for row = 1, self.gridSize do
        gridCopy[row] = {}
        gridDataCopy[row] = {}
        for col = 1, self.gridSize do
            local sourceRow = row - y
            local sourceCol = col - x
            if sourceRow >= 1 and sourceRow <= self.gridSize and
               sourceCol >= 1 and sourceCol <= self.gridSize then
                gridCopy[row][col] = self.grid[sourceRow][sourceCol]
                gridDataCopy[row][col].type = self.gridData[sourceRow][sourceCol].type
                gridDataCopy[row][col].blood = self.gridData[sourceRow][sourceCol].blood
                gridDataCopy[row][col].electric = self.gridData[sourceRow][sourceCol].electric
            else
                gridCopy[row][col] = " "
                gridDataCopy[row][col].type = 1
                gridDataCopy[row][col].blood = 0
                gridDataCopy[row][col].electric = false
            end     
        end
    end
        
    self.grid = gridCopy
    self.gridData = gridDataCopy
    
    self:updatePreview()
end

function LevelEditor:test()
    self:generate()
    
    loadEditorLevel()
end

function LevelEditor:generateText()
    self:generate()
    
    local result = 'createLevel(\n\t"'
    
    result = result .. self.levelName
    
    result = result .. '",\n\t{'
    
    for i = 1, game.maxInventory do
        local item = self.startingInventory[i]
        if item ~= nil then
            if i > 1 then
                result = result .. ", "
            end
            result = result .. '"' .. item .. '"'
        end
    end
    
    result = result .. "}, {\n"
    
    for i, v in ipairs(self.level) do
        result = result .. '"' .. v .. '",\n'
    end
    
    result = result .. "}"
    
    local hasTypes = false
    local types = {}
    for k, v in pairs(self.levelType) do
        if v > 1 then
            types[vec2(k.x, k.y)] = v
            hasTypes = true
        end
    end
    
    if hasTypes then
        result = result .. ", {\n"
        
        for k, v in pairs(types) do
            result = result .. '[vec2(' .. k.x .. ', ' .. k.y .. ')]'
            result = result .. ' = ' .. v .. ',\n'
        end
        
        result = result .. "}"
    else
        result = result .. ", {}"
    end
    
    local hasBlood = false
    local blood = {}
    for k, v in pairs(self.levelBlood) do
        if v > 0 then
            blood[vec2(k.x, k.y)] = v
            hasBlood = true
        end
    end
    
    if hasBlood then
        result = result .. ", {\n"
        
        for k, v in pairs(blood) do
            result = result .. '[vec2(' .. k.x .. ', ' .. k.y .. ')]'
            result = result .. ' = ' .. v .. ',\n'
        end
        
        result = result .. "}"
    else
        result = result .. ", {}"
    end
    
    -- Author
    result = result .. ", \"\""
    
    if #self.levelElectric > 0 then
        result = result .. ", {\n"
        
        for i, v in ipairs(self.levelElectric) do
            result = result .. 'vec2(' .. v.x .. ', ' .. v.y .. '),\n'
        end
        
        result = result .. "}"
    else
        result = result .. ", {}"
    end
    
    result = result .. ")\n"
    
    return result    
end

function LevelEditor:toClipboard()
    pasteboard.text = self:generateText()
end

function LevelEditor:fromText(levelFunction)
    local prefix = "createLevel("
    local startsWith = string.sub(levelFunction, 1, #prefix)
    local status, error = pcall(load(levelFunction))
    if startsWith ~= prefix then return end
    if error == nil then
        if self.pastedOnce then
            removeLevel(#levels - 1)
            levelIndex = levelIndex - 1
        end
        loadLevel(#levels)
        self:open()
        self.pastedOnce = true
    end
end

function js_paste(txt)
    editor:fromText(txt)
end

function LevelEditor:fromClipboard()
    self:fromText(pasteboard.text)
end

function LevelEditor:open()
    music.paused = true
    
    buttons = {}
    isEditor = true
    
    if not isEditorLevel then
        self:clear()
        self.levelIndex = levelIndex
        self.levelName = levelNames[levelIndex]
        local level = levels[levelIndex]
        local levelType = levelTypes[levelIndex]
        local levelBlood = levelBloods[levelIndex]
        local levelElectric = levelElectrics[levelIndex]
        local height = #level
        local width = #level[1]
        for row, l in ipairs(level) do
            for col = 1, width do
                local x = math.floor(self.gridSize / 2 - width / 2) + col
                local y = math.floor(self.gridSize / 2 - height / 2) + row
                local char = l:sub(col, col)
                self.grid[y][x] = char
                self.gridData[y][x].type = 1
                self.gridData[y][x].electric = false
            end
        end
        
        for k, v in pairs(levelType) do
            local gridCol = math.floor(self.gridSize / 2 - width / 2) + k.y
            local gridRow = math.floor(self.gridSize / 2 - height / 2) + k.x
            self.gridData[gridRow][gridCol].type = v
        end
        
        for k, v in pairs(levelBlood) do
            local gridCol = math.floor(self.gridSize / 2 - width / 2) + k.y
            local gridRow = math.floor(self.gridSize / 2 - height / 2) + k.x
            self.gridData[gridRow][gridCol].blood = v
        end
        
        for i, v in ipairs(levelElectric) do
            local gridCol = math.floor(self.gridSize / 2 - width / 2) + v.y
            local gridRow = math.floor(self.gridSize / 2 - height / 2) + v.x
            self.gridData[gridRow][gridCol].electric = true
        end
        
        self.startingInventory = {}
        for k, v in ipairs(inventories[levelIndex]) do
            table.insert(self.startingInventory, v)
        end
    end
        
    AddButton(10, HEIGHT-60, 50, 50, "X", function()
        loadLevel(levelIndex)
        isEditor = false
        music.paused = false
    end)
    
    local testButton = AddButton(WIDTH-190, HEIGHT-60, 180, 50, localization:get("test", gameText), function()
        if editor:isValid() then
            self:test()
        end
    end)
    testButton.selectedFunc = function() return editor:isValid() end
    
    AddButton(WIDTH-190, HEIGHT-120, 180, 50, localization:get("clear", gameText), function()
        self:clear()
        self:updatePreview()
    end)
    
    AddButton(WIDTH-190, HEIGHT-180, 85, 50, localization:get("clipboard", gameText), function()
        self:toClipboard()
    end)
    
    AddButton(WIDTH-95, HEIGHT-180, 85, 50, localization:get("paste", gameText), function()
        self:fromClipboard()
    end)
    
    AddButton(WIDTH-190, HEIGHT-240, 50, 50, "<", function()
        self:offset(-1, 0)
    end)
    
    AddButton(WIDTH-130, HEIGHT-240, 50, 50, ">", function()
        self:offset(1, 0)
    end)
    
    AddButton(WIDTH-190, HEIGHT-300, 50, 50, "^", function()
        self:offset(0, -1)
    end)
    
    AddButton(WIDTH-130, HEIGHT-300, 50, 50, "v", function()
        self:offset(0, 1)
    end)
    
    local button = AddButton(WIDTH-190, HEIGHT-360, 35, 35, "", function()
        self.bloodLevel = 0
    end)
    button.fillColor = color(0)
    button.selectionBorderOnly = true
    button.selectionTransparency = 1.0
    button.selectedFunc = function() return self.bloodLevel == 0 end
    
    button = AddButton(WIDTH-150, HEIGHT-360, 35, 35, "", function()
        self.bloodLevel = 1
    end)
    button.fillColor = color((1.0 / 3.0) * 255, 0, 0)
    button.selectionBorderOnly = true
    button.selectionTransparency = 1.0
    button.selectedFunc = function() return self.bloodLevel == 1 end
    
    button = AddButton(WIDTH-110, HEIGHT-360, 35, 35, "", function()
        self.bloodLevel = 2
    end)
    button.fillColor = color((2.0 / 3.0) * 255, 0, 0)
    button.selectionBorderOnly = true
    button.selectionTransparency = 1.0
    button.selectedFunc = function() return self.bloodLevel == 2 end
    
    button = AddButton(WIDTH-70, HEIGHT-360, 35, 35, "", function()
        self.bloodLevel = 3
    end)
    button.fillColor = color((3.0 / 3.0) * 255, 0, 0)
    button.selectionBorderOnly = true
    button.selectionTransparency = 1.0
    button.selectedFunc = function() return self.bloodLevel == 3 end
    
    button = AddButton(WIDTH-190, HEIGHT-420, 180, 50, "prevLevel", prevLevel)
    button.localizedText = true
    button.localizedArray = gameText
        
    button = AddButton(WIDTH-190, HEIGHT-480, 180, 50, "nextLevel", function() nextLevel(true) end)
    button.localizedText = true
    button.localizedArray = gameText
    
    button = AddSpriteButton(WIDTH-135, HEIGHT-600, 64, 64, asset.share_2, shareLevel)
    button.localizedText = true
    button.localizedArray = gameText
    button.text = "share"
    button.textOffset = vec2(0, -50)
            
    local x = 10
    x = self:addCharButtons(x, 10, self.bottomCharacters)
    
    x = 10
    x = self:addCharButtons(x, 60, self.topCharacters)
    
    for i = 1, 3 do
        local button = AddButton(10 + (i - 1) * 45, HEIGHT - 150, 40, 40, "", function()
            local isItem = self.inventoryCharacters:find(self.selectedCharacter, nil, true)
            if isItem then
                if self.startingInventory[i] ~= self.selectedCharacter then
                    self.startingInventory[i] = self.selectedCharacter
                else
                    self.startingInventory[i] = nil
                end
            else
                self.startingInventory[i] = nil
            end
        end)
        button.notSelectedAlpha = 1
        button.spriteFit = false
        button.spriteSize = vec2(32, 32)
        button.backgroundSprite = sprites[20].image
        button.spriteFunc = function()
            local item = self.startingInventory[i]
            local buttonSprite = self.buttonSprites[item]
            if buttonSprite == nil and itemSprites[item] ~= nil then
                buttonSprite = itemSprites[item].image
            end
            button.spriteTint = self.buttonSpriteTint[item]
            return buttonSprite
        end
        button.selectedFunc = function() return false end
    end
        
    self:updatePreview()
end

function shareLevel()
    local result = editor:generateText()
    if _isJSCodea and context ~= nil then
        context:shareLevel(result)
    else
        local items = {}
        table.insert(items, result)
        local vc = objc.cls.UIActivityViewController:alloc():initWithActivityItems_applicationActivities_(items, {})
        
        if is_ipad then
            vc.modalPresentationStyle = objc.enum.UIModalPresentationStyle.UIModalPresentationPopover
            vc.preferredContentSize = objc.size(500, 500)
            popover = vc.popoverPresentationController
            popover.sourceView = objc.viewer.view
            popover.sourceRect = objc.rect(1, 1, 1, 1)
        end
        
        objc.viewer:presentViewController_animated_completion_(vc, true, nil)
    end
end

function LevelEditor:isValid()
    return self.validVisuals and self.hasPlayer and self.hasCrystal
end

-- Returns true if the character can be found with blood of electricity
function LevelEditor:canHaveBlood(char)
    return 
        char == " " or
        char == "P" or
        char == "*" or
        char == "e" or
        char == "." or
        self.inventoryCharacters:find(char, nil, true)
end

function LevelEditor:canHaveElectric(char)
    return self:canHaveBlood(char) or tonumber(char) ~= nil
end

function LevelEditor:placeCharacter(row, col)
    if self.touching and self.lastTouch.x == row and self.lastTouch.y == col then
        return
    end
    
    local isSingleCharacter = self.singleCharacters:find(self.selectedCharacter, nil, true)
    if isSingleCharacter then
        for clearRow = 1, self.gridSize do
            for clearCol = 1, self.gridSize do
                if (row ~= clearRow or col ~= clearCol) and
                    self.grid[clearRow][clearCol] == self.selectedCharacter then
                    self.grid[clearRow][clearCol] = " "
                    self.gridData[clearRow][clearCol].type = 1
                    self:refreshMappingAround(clearRow, clearCol)
                end
            end
        end
    end
        
    if self:canHaveBlood(self.selectedCharacter) then
        self.gridData[row][col].blood = self.bloodLevel
    else
        self.gridData[row][col].blood = 0
    end
    
    local canHaveElectric = self:canHaveElectric(self.selectedCharacter)
    
    if not self.touching then
        if self.selectedCharacter == " " or not canHaveElectric then
            self.gridData[row][col].electric = false
        end
        if self.grid[row][col] == self.selectedCharacter then
            local types = self.typeCharacters[self.selectedCharacter]
            if types ~= nil then
                self.gridData[row][col].type = (self.gridData[row][col].type % types) + 1
            end
        else
            if self.selectedCharacter == "e" then
                self.gridData[row][col].electric = true
                if not self:canHaveElectric(self.grid[row][col]) then
                    self.grid[row][col] = " "
                end
            else
                self.grid[row][col] = self.selectedCharacter
                self.gridData[row][col].type = 1
            end
            self:refreshMappingAround(row, col)
        end
    else
        if isSingleCharacter then
            self.grid[row][col] = self.selectedCharacter
            self.gridData[row][col].type = 1
            self:refreshMappingAround(row, col)
        else
            local currentRow = self.lastTouch.x
            local currentCol = self.lastTouch.y
            repeat
                local diffRow = row - currentRow
                local diffCol = col - currentCol
                local absRow = math.abs(diffRow)
                local absCol = math.abs(diffCol)
                if absRow > absCol then
                    currentRow = currentRow + absRow / diffRow
                else
                    currentCol = currentCol + absCol / diffCol
                end
                if self.selectedCharacter == " " or not canHaveElectric then
                    self.gridData[currentRow][currentCol].electric = false
                end
                if self.selectedCharacter == "e" then
                    self.gridData[currentRow][currentCol].electric = true
                    if not self:canHaveElectric(self.grid[currentRow][currentCol]) then
                        self.grid[currentRow][currentCol] = " "
                    end
                else
                    if self.grid[currentRow][currentCol] ~= self.selectedCharacter then
                        self.grid[currentRow][currentCol] = self.selectedCharacter
                        self.gridData[currentRow][currentCol].type = 1
                    end
                end
                self:refreshMappingAround(currentRow, currentCol)
            until currentRow == row and currentCol == col
        end
    end
end

function LevelEditor:draw()
    drawButtons()
    
    --updateAnims(anims)
    
    pushStyle()
    
    textMode(CORNER)
    text(localization:get("startingInventory", gameText), 10, HEIGHT - 100)
    
    textMode(CENTER)
    local displayName = self.levelIndex .. " - " .. self.levelName
    text(displayName, WIDTH-100, HEIGHT-500)
    
    rectMode(CORNER)
    
    noFill()
    stroke(255)
    strokeWidth(1)
    spriteMode(CORNER)
    
    local cellSize = 32
    local cornerOffset = (self.gridSize / 2) * cellSize
    local x = math.floor((WIDTH / 2) - cornerOffset)
    local y = math.floor((HEIGHT / 2) + cornerOffset + 30)

    local lineSize = self.gridSize * cellSize
    for rowCol = 1, self.gridSize + 1 do
        local rx = x + (rowCol - 1) * cellSize
        local ry = y - (rowCol - 2) * cellSize
        line(x, ry, x + lineSize, ry)
        line(rx, y + cellSize, rx, y - lineSize + cellSize) 
    end
    
    for row = 1, self.gridSize + 2 do
        for col = 1, self.gridSize + 2 do
            local gridRow = (self.gridSize + 2) - row + 1
            for i = 1, #self.sprites[gridRow][col] do
                local rx = x + (col - 2) * cellSize
                local ry = y - (row - 2) * cellSize
                sprite(self.sprites[gridRow][col][i].image, rx, ry, cellSize, cellSize)
            end
            local levelRow = row - 2
            local levelCol = col - 2
            if levelRow >= 1 and levelRow <= self.gridSize and
               levelCol >= 1 and levelCol <= self.gridSize then
                local rx = x + (levelCol - 1) * cellSize
                local ry = y - (levelRow - 1) * cellSize
                local value = self.grid[levelRow][levelCol]
                local cellBlood = self.gridData[levelRow][levelCol].blood
                
                if self.gridData[levelRow][levelCol].electric == true then
                    sprite(animElectric.image, rx, ry, cellSize, cellSize)
                end
                
                if cellBlood > 0 then
                    cellBlood = math.min(3, cellBlood)
                    for index = 1, cellBlood do
                        sprite(bloodSprite.image, rx, ry, cellSize, cellSize)
                    end
                end
                                
                local byteValue = string.byte(value)
                local isPortal = isPortalByte(byteValue)
                if isPortal then
                    local portalIndex = byteValue - firstPortal + 1
                    local portalColor = portalColors[portalIndex]
                    tint(portalColor)
                    sprite(animPortal.image, rx, ry, cellSize, cellSize)
                    tint(255)
                elseif isLaser(value) then
                    local phase = self.gridData[levelRow][levelCol].type
                    itemColor = laserColors[phase]
                    sprite(laserSprites[value].image, rx, ry, cellSize, cellSize)
                    tint(itemColor)
                    sprite(laserLightSprites[value].image, rx, ry, cellSize, cellSize)
                    tint(255)
                elseif isDoor(value) then
                    local door = getDoor(levelRow, levelCol)
                    local doorType = self.gridData[levelRow][levelCol].type
                    local doorColor = doorDarkColors[doorType]
                    local doorOpened = value == "d"
                    if doorOpened then
                        sprite(doorOpenedSprite.image, rx, ry, cellSize, cellSize)
                        tint(doorColor)
                        sprite(doorLightsOpenedSprite.image, rx, ry, cellSize, cellSize)
                    else
                        sprite(doorClosedSprite.image, rx, ry, cellSize, cellSize)
                        tint(doorColor)
                        sprite(doorLightsClosedSprite.image, rx, ry, cellSize, cellSize)
                    end            
                    tint(255)
                elseif isSwitch(value) then
                    local switchType = self.gridData[levelRow][levelCol].type
                    local switchColor = doorDarkColors[switchType]            
                    sprite(switchSprite.image, rx, ry, cellSize, cellSize)
                    tint(switchColor)
                    sprite(switchLights.image, rx, ry, cellSize, cellSize)
                    tint(255)
                elseif value == "*" then
                    sprite(animCrystal.image, rx, ry, cellSize, cellSize)
                elseif value == "P" then
                    sprite(animRobot.image, rx, ry, cellSize, cellSize)
                elseif itemSprites[value] ~= nil then
                    sprite(itemSprites[value].image, rx, ry, cellSize, cellSize)
                elseif value == "~" then
                    sprite(waterSprite.image, rx, ry, cellSize, cellSize)
                elseif value == "o" then
                    sprite(boxSprite.image, rx, ry, cellSize, cellSize)
                elseif value == "p" then
                    tint(92, 32, 104)
                    sprite(animPortablePortal.image, rx, ry, cellSize, cellSize)
                    tint(255)
                elseif value == "f" then
                    sprite(animFan.image, rx, ry, cellSize, cellSize)
                end 
                
                local mx = rx + cellSize
                local my = ry + cellSize
                
                if CurrentTouch.state ~= ENDED and
                   CurrentTouch.pos.x >= rx and CurrentTouch.pos.x < mx and
                   CurrentTouch.pos.y >= ry and CurrentTouch.pos.y < my then
                    self:placeCharacter(levelRow, levelCol)
                    self.lastTouch = vec2(levelRow, levelCol)
                    self.touching = true
                elseif CurrentTouch.state == ENDED and self.touching then
                    self.lastTouch = vec2(0, 0)
                    self:updatePreview()
                    self.touching = false
                end
            end
        end
    end
    
    popStyle()
end

function LevelEditor:touched(touch, anyButton)
    
end
