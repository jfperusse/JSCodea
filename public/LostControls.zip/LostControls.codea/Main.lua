-- LostControls

levels = {}
stories = {}
inventories = {}
levelTypes = {}
levelBloods = {}
levelElectrics = {}
levelNames = {}
levelStrings = {}
levelAuthors = {}

function addAnim(assetName, msPerFrame)
    local anim = readAnimAsset(assetName, msPerFrame)
    table.insert(sprites, anim)
end
 
-- Use this function to perform your initial setup
function setup()
    Button.useAppFont = true
    Button.defaultStrokeWidth = 2

    --local icon = readImage(asset.LostControlsIcon)
    --saveImage(asset.Icon,icon)
    
    localization = Localization("fr")

    sprites = {}
    isEditor = false
    introTime = 0
    waitForButtonRelease = false
    isDeveloper = false
    tileSize = 16
    cellSize = tileSize * 2
    levelY = HEIGHT/2 - 40
    torchWallIndex = 146
    waitToStart = true
    maxUndo = 500
    
    platform = deviceMetrics().platform
    is_ipad = platform:sub(1, 4) == "iPad"

    noSmooth()
    
    readTilesetAsset(tileSize, asset.Dungeon_Tileset, sprites)
    
    animTorch = readAnimAsset(tileSize, asset.torch_prop_anim_strip_5, 100)
    animCrystal = readAnimAsset(tileSize, asset.crystal_item_anim_strip_6, 100)
    animRobot = readAnimAsset(tileSize, asset.Robot_v1, 400)
    animPortal = readAnimAsset(tileSize, asset.Portal, 100)
    animPortablePortal = readAnimAsset(tileSize, asset.PortablePortal, 100)
    animFan = readAnimAsset(tileSize, asset.Fan, 66)
    animElectric = readAnimAsset(tileSize, asset.ElectricFloor, 150)

    defaultFloorSprite = sprites[20]
    defaultWallSprite = sprites[70]
    bloodSprite = sprites[120]
    waterSprite = sprites[163]
    
    laserSprites = {}
    laserSprites[">"] = sprites[133]
    laserSprites["<"] = sprites[134]
    laserSprites["^"] = sprites[135]
    laserSprites["v"] = sprites[136]
    
    laserLightSprites = {}
    laserLightSprites[">"] = sprites[137]
    laserLightSprites["<"] = sprites[138]
    laserLightSprites["^"] = sprites[139]
    laserLightSprites["v"] = sprites[140]
    
    boxSprite = sprites[141]
    
    doorClosedSprite = sprites[151]
    doorOpenedSprite = sprites[152]
    doorLightsClosedSprite = sprites[153]
    doorLightsOpenedSprite = sprites[154]
    switchSprite = sprites[155]
    switchLights = sprites[156]
    
    levelMapping = json.decode(tileMappingJson)
    mappingEffects = {
        ["F"] = {},
        ["#"] = { "#", " " },
        ["_"] = { "_" },
        ["$"] = {},
        [" "] = { "#" }
    }
    mappingEffectsTable = {}
    for k, v in pairs(mappingEffects) do
        mappingEffectsTable[k] = {}
        for i = 1, #v do
            mappingEffectsTable[k][v[i]] = true
        end
    end
    
    floorSprites = {}
    floorSprites[20] = true
    
    itemSprites = {}
    for k, v in pairs(itemSpriteIndex) do
        itemSprites[k] = sprites[v]
    end
    
    parameter.integer("charSize", 8, 40, 20)
    parameter.action("Test JSCodea", function()
        if _isJSCodea then
            _isJSCodea = nil
        else
            _isJSCodea = true
        end
    end)
        
    viewer.mode = FULLSCREEN_NO_BUTTONS
    
    editor = LevelEditor()
    game = Game()
    showLevel = true
    
    firstPortal = string.byte("1")
    lastPortal = string.byte("3")
    
    local levelToLoad = 1
    
    if _isJSCodea == true and context ~= nil then
        local parameters = context:getParameters()
        if parameters["levelToLoad"] ~= nil then
            levelToLoad = tonumber(parameters["levelToLoad"])
        elseif parameters["levelNameToLoad"] ~= nil then
            local levelNameToLoad = parameters["levelNameToLoad"]
            for i = 1, #levelNames do
                if levelNames[i] == levelNameToLoad then
                    levelToLoad = i
                    break
                end
            end
        end
    end
    
    loadLevel(levelToLoad)
end

function startGame()
    music(asset.downloaded.A_Hero_s_Quest.Dungeon,true,0.5)
    waitToStart = false
end

function createMainButtons(isEditor)
    buttons = {}
    
    if not isRuntime() then
        viewerButton = Button(5, HEIGHT-60, 50, 50, ">", function()
            if viewer.mode == STANDARD then
                viewer.mode = FULLSCREEN_NO_BUTTONS
                viewerButton.text = ">"
            else
                viewer.mode = STANDARD
                viewerButton.text = "<"
            end
        end)
        table.insert(buttons, viewerButton)
        AddButton(65, HEIGHT-60, 50, 50, "X", function()
            viewer.close()
        end)
    end
    
    local buttonHeight = 60
    
    newButton = Button(5, 5, 150, buttonHeight, "developer", function() isDeveloper = not isDeveloper end)
    newButton.localizedText = true
    newButton.localizedArray = gameText
    table.insert(buttons, newButton)
            
    newButton = Button(160, 5, 120, buttonHeight, "prevLevel", prevLevel)
    newButton.localizedText = true
    newButton.localizedArray = gameText
    newButton.testFunc = function() return isDeveloper end
    table.insert(buttons, newButton)
    
    newButton = Button(285, 5, 100, buttonHeight, "nextLevel", function() nextLevel(true) end)
    newButton.localizedText = true
    newButton.localizedArray = gameText
    newButton.testFunc = function() return isDeveloper end
    table.insert(buttons, newButton)
        
    newButton = Button(WIDTH-155, 5, 150, buttonHeight, "restart", restart)
    newButton.localizedText = true
    newButton.localizedArray = gameText
    newButton.keyboardHint = "R"
    newButton.keyboardHintFunc = function() return _isJSCodea end
    newButton.keyboardHintSize = 12
    table.insert(buttons, newButton)
    
    newButton = Button(WIDTH-260, 5, 100, buttonHeight, "currentLanguage", changeLanguage)
    newButton.localizedText = true
    newButton.localizedArray = gameText
    table.insert(buttons, newButton)

    newButton = Button(WIDTH-465, 5, 200, buttonHeight, "editor", function()
        editor:open()
    end)
    newButton.localizedText = true
    newButton.localizedArray = gameText
    table.insert(buttons, newButton)

    newButton = Button(WIDTH-630, 5, 160, buttonHeight, "undo", function()
        if #undoBuffer > 0 then
            undo()
        end
    end)
    newButton.selectedFunc = function() return #undoBuffer > 0 end
    newButton.localizedText = true
    newButton.localizedArray = gameText
    newButton.keyboardHint = "backspace"
    newButton.keyboardHintFunc = function() return _isJSCodea end
    newButton.keyboardHintSize = 12
    table.insert(buttons, newButton)
    
    local actionTop = HEIGHT/2 + 20
    local actionWidth = 180
    
    newButton = Button(WIDTH - actionWidth - 5, actionTop-65, actionWidth, 60, "teleport", function() game:teleport() end)
    newButton.localizedText = true
    newButton.localizedArray = gameText
    newButton.testFunc = canTeleport
    newButton.keyboardHint = "space"
    newButton.keyboardHintFunc = function() return _isJSCodea end
    newButton.keyboardHintSize = 12
    table.insert(buttons, newButton)
    
    newButton = Button(WIDTH - actionWidth - 5, actionTop, actionWidth, 60, "explode", function() game:explode(false) end)
    newButton.localizedText = true
    newButton.localizedArray = gameText
    newButton.testFunc = hasExplosive
    newButton.keyboardHint = "E"
    newButton.keyboardHintFunc = function() return _isJSCodea end
    newButton.keyboardHintSize = 12
    table.insert(buttons, newButton)    

    newButton = Button(WIDTH - actionWidth - 5, actionTop-130, actionWidth, 60, "antiExplode", function() game:explode(true) end)
    newButton.localizedText = true
    newButton.localizedArray = gameText
    newButton.testFunc = hasAntiExplosive
    newButton.keyboardHint = "Q"
    newButton.keyboardHintFunc = function() return _isJSCodea end
    newButton.keyboardHintSize = 12
    table.insert(buttons, newButton)
    
    game:createButtons(false, game.inventoryCenter)
    game:createButtons(true, game.groundCenter)
end

function changeLanguage()
    if localization.language == "en" then
        localization:setLanguage("fr")
    else
        localization:setLanguage("en")
    end
end

function removeFromLine(in_line, in_value)
    level[in_line] = level[in_line]:gsub(in_value, " ")
end

function setShowLevel(in_value)
    showLevel = in_value
    if in_value then
        sound(DATA, "ZgBALy5JQGk5QEBAAAAAALZyQj419rA+QQBAf0BAQEBAQEBA")
    end
end

function introTap()
    if introTime < 6 then
        introTime = 6
    else
        endIntro()
    end
end

function drawButtons()
    for i,v in ipairs(buttons) do
        v:draw()
    end
end

function endIntro()
    intro = false
    game:displayMessage(1)
end

-- This function gets called once every frame
function draw()
    checkGameController()
    
    background(40, 40, 50)
    
    strokeWidth(3)
    
    fill(255, 255, 255, 255)
    
    if waitToStart then
        font("SourceSansPro-Bold")
        fontSize(64)
        textMode(CENTER)
        text(localization:get("tapToStart", gameText), WIDTH/2, HEIGHT/2)
        return
    end
    
    
    if isEditor then
        editor:draw()
        return
    end
    
    drawGame()
end
