function isPortalByte(b)
    return b >= firstPortal and b <= lastPortal
end

function isPortalChar(c)
    local byteValue = string.byte(c)
    return isPortalByte(byteValue)
end

function hasPortal(row, col)
    local value = game:getValue(playerLine, playerCol)
    return isPortalChar(value)
end

function hasPortablePortal(row, col)
    for i = 1, #portablePortals do
        if portablePortals[i].pos.x == row and portablePortals[i].pos.y == col then
            return true
        end
    end
    
    return false
end

function canTeleport()
    if hasPortal(playerLine, playerCol) then
        return true
    end
    
    if hasPortablePortal(playerLine, playerCol) then
        for i = 1, #portablePortals do
            if portablePortals[i].pos.x ~= playerLine or portablePortals[i].pos.y ~= playerCol then
                return true
            end
        end
    end
    
    return false
end

function countInventory()
    local count = 0
    
    for i = 1, game.maxInventory do
        if game.inventory[i] ~= nil then
            count = count + 1
        end
    end
    
    return count
end

function hasInventory(item)
    for i = 1, game.maxInventory do
        if game.inventory[i] == item then
            return true
        end
    end
    
    return false
end

function hasAnyInventory(items)
    for i = 1, game.maxInventory do
        if table.contains(items, game.inventory[i]) then
            return true
        end
    end
end

function hasExplosive()
    return hasInventory("X")
end

function hasAntiExplosive()
    return hasInventory("I")
end

function hasAction()
    return canTeleport() or hasExplosive() or hasAntiExplosive()
end

function isItem(char)
    return table.contains({"N", "S", "E", "W", "B", "X", "M", "I", "V", "H", "p"}, char)
end

function isLaser(char)
    return table.contains({"<", ">", "^", "v"}, char)
end

function isBlocker(char, row, col)
    if isDoor(char) then
        return not isDoorOpened(row, col)
    end
    return isLaser(char) or table.contains({"#", "_", "$", "f"}, char)
end

function canWarpThrough(char, row, col)
    local box = getBox(newRow, newCol)
    if box ~= nil then
        return false
    end
    
    if isDoor(char) then
        return isDoorOpened(row, col)
    end
    
    if isLaser(char) then
        return false
    end
    
    if table.contains({"#", "$", "o"}, char) then
        return false
    end
    
    return true
end

function isDoor(char)
    return char == "d" or char == "D"
end

function getDoor(row, col)
    for k, v in pairs(doors) do
        if k.x == row and k.y == col then
            return v
        end
    end
    
    return nil
end

function getSwitch(row, col)
    for k, v in pairs(switches) do
        if k.x == row and k.y == col then
            return v
        end
    end
    
    return nil
end

function getBox(row, col)
    for i, v in ipairs(boxes) do
        if v.pos.x == row and v.pos.y == col then
            return v
        end
    end
    
    return nil
end

function isDoorOpened(row, col)
    for k, v in pairs(doors) do
        if k.x == row and k.y == col then
            local anySwitch = false
            local allSwitches = true
            local startOpened = v.startOpened
            local doorType = v.type
            for k, v in pairs(switches) do
                if v.type == doorType then
                    local blood = game:getBlood(k.x, k.y)
                    if blood ~= nil and blood > 0 then
                        anySwitch = true
                    else
                        allSwitches = false
                    end
                end
            end
            if startOpened then
                return not anySwitch
            else
                return allSwitches
            end
        end
    end
    
    return false
end

function isSwitch(char)
    return char == "."
end

function canHaveBlood(row, col)
    local char = game:getValue(row, col)
    return not isBlocker(char, row, col) and 
    not isDoor(char) and
    getBox(row, col) == nil and
    char ~= "~"
end

function blocksBlood(char, row, col)
    for i, v in ipairs(boxes) do
        if v.pos.x == row and v.pos.y == col then
            return true
        end
    end
    if isDoor(char) then
        return not isDoorOpened(row, col)
    end
    return char == "#" or char == "o" or char == "f"
    -- or isLaser(char)
end

function getLevelType(row, col)
    for k, v in pairs(levelType) do
        if k.x == row and k.y == col then
            return v
        end
    end
    
    return 1
end

function getLevelBlood(row, col)
    for k, v in pairs(levelBlood) do
        if k.x == row and k.y == col then
            return v
        end
    end
    
    return 0
end

function addToGround(i, j, c)
    for x = 1, game.maxGround do
        if ground[i][j][x] == nil then
            ground[i][j][x] = c
            return
        end
    end
end

function recordUndo()
    local newUndo = {}
    
    newUndo.playerCol = playerCol
    newUndo.playerLine = playerLine
    
    newUndo.laserPhase = laserPhase
    
    newUndo.inventory = {}
    for i = 1, game.maxInventory do
        newUndo.inventory[i] = game.inventory[i]
    end
    
    newUndo.ground = {}
    for row = 1, levelHeight do
        for col = 1, levelWidth do
            local hasGround = false
            if blood[row][col] <= 0 then
                for i = 1, game.maxGround do                
                    if ground[row][col][i] ~= nil then
                        hasGround = true
                        break
                    end
                end
            end
            if hasGround or blood[row][col] > 0 then
                local groundValue = {}
                groundValue.row = row
                groundValue.col = col
                groundValue.ground = {}
                for i = 1, game.maxGround do                
                    groundValue.ground[i] = ground[row][col][i]
                end
                groundValue.blood = blood[row][col]
                table.insert(newUndo.ground, groundValue)
            end
        end
    end
    
    newUndo.boxes = {}
    for i, v in ipairs(boxes) do
        newUndo.boxes[i] = vec2(v.pos.x, v.pos.y)
    end
    
    if #undoBuffer >= maxUndo then
        table.remove(undoBuffer, 1)
    end
    
    table.insert(undoBuffer, newUndo)
end

function undo()
    local undoData = undoBuffer[#undoBuffer]
    table.remove(undoBuffer, #undoBuffer)
    
    playerCol = undoData.playerCol
    playerLine = undoData.playerLine
    portablePortals = {}
    
    laserPhase = undoData.laserPhase
    
    for i = 1, game.maxInventory do
        game.inventory[i] = undoData.inventory[i]
    end
    
    for row = 1, levelHeight do
        for col = 1, levelWidth do
            for i = 1, game.maxGround do
                ground[row][col][i] = nil
                blood[row][col] = 0
            end
        end
    end
    
    for i, v in ipairs(undoData.ground) do
        for groundIndex = 1, game.maxGround do
            local value = v.ground[groundIndex]
            ground[v.row][v.col][groundIndex] = value
            if value == "p" then
                local portablePortal = {}
                portablePortal.pos = vec2(v.row, v.col)
                table.insert(portablePortals, portablePortal)
            end
        end
        blood[v.row][v.col] = v.blood
    end
    
    for i, v in ipairs(undoData.boxes) do
        boxes[i].pos.x = v.x
        boxes[i].pos.y = v.y
    end
end

function getShortItemName(char)
    if localization:hasKey(char, shortItemName) then
        return localization:get(char, shortItemName)
    end
    
    return char
end

function countGround(i, j)
    local count = 0
    
    for x = 1, game.maxGround do
        if ground[i][j][x] ~= nil then
            count = count + 1
        end
    end
    
    return count
end

function getGround(i, j, index)
    local count = 0
    
    for x = 1, game.maxGround do
        if ground[i][j][x] ~= nil then
            count = count + 1
            
            if count == index then
                return ground[i][j][x]
            end
        end
    end
    
    return nil
end
