itemDesc = {}
itemDesc["en"] = {}
itemDesc["fr"] = {}

itemDesc["en"]["N"] = "North"
itemDesc["fr"]["N"] = "Nord"
itemDesc["en"]["S"] = "South"
itemDesc["fr"]["S"] = "Sud"
itemDesc["en"]["E"] = "East"
itemDesc["fr"]["E"] = "Est"
itemDesc["en"]["W"] = "West"
itemDesc["fr"]["W"] = "Ouest"
itemDesc["en"]["B"] = "Follow"
itemDesc["fr"]["B"] = "Suivre"
itemDesc["en"]["X"] = "Explosion"
itemDesc["fr"]["X"] = "Explosion"
itemDesc["en"]["I"] = "Implosion"
itemDesc["fr"]["I"] = "Implosion"
itemDesc["en"]["M"] = "Omni"
itemDesc["fr"]["M"] = "Omni"
itemDesc["en"]["H"] = "Horizontal"
itemDesc["fr"]["H"] = "Horizontal"
itemDesc["en"]["V"] = "Vertical"
itemDesc["fr"]["V"] = "Vertical"

itemName = {}
itemName["en"] = {}
itemName["fr"] = {}

itemName["en"]["N"] = "NORTH"
itemName["fr"]["N"] = "NORD"
itemName["en"]["S"] = "SOUTH"
itemName["fr"]["S"] = "SUD"
itemName["en"]["E"] = "EAST"
itemName["fr"]["E"] = "EST"
itemName["en"]["W"] = "WEST"
itemName["fr"]["W"] = "OUEST"
itemName["en"]["M"] = "MULTI"
itemName["fr"]["M"] = "MULTI"
itemName["en"]["H"] = "HORIZONTAL"
itemName["fr"]["H"] = "HORIZONTAL"
itemName["en"]["V"] = "VERTICAL"
itemName["fr"]["V"] = "VERTICAL"

shortItemName = {}
shortItemName["en"] = {}
shortItemName["fr"] = {}

shortItemName["en"]["N"] = "⬆️️️"
shortItemName["fr"]["N"] = "⬆️"
shortItemName["en"]["S"] = "⬇"
shortItemName["fr"]["S"] = "⬇"
shortItemName["en"]["W"] = "⬅"
shortItemName["fr"]["W"] = "⬅"
shortItemName["en"]["E"] = "➡️️"
shortItemName["fr"]["E"] = "➡️️"
shortItemName["en"]["B"] = "🩸"
shortItemName["fr"]["B"] = "🩸"
shortItemName["en"]["X"] = "💣"
shortItemName["fr"]["X"] = "💣"
shortItemName["en"]["I"] = "💢"
shortItemName["fr"]["I"] = "💢"
shortItemName["en"]["M"] = "✢"
shortItemName["fr"]["M"] = "✢"
shortItemName["en"]["H"] = "↔️"
shortItemName["fr"]["H"] = "↔"
shortItemName["en"]["V"] = "↕️"
shortItemName["fr"]["V"] = "↕"

itemSpriteIndex = {}
itemSpriteIndex["N"] = 169
itemSpriteIndex["S"] = 170
itemSpriteIndex["W"] = 172
itemSpriteIndex["E"] = 171
itemSpriteIndex["B"] = 176
itemSpriteIndex["X"] = 160
itemSpriteIndex["I"] = 161
itemSpriteIndex["M"] = 173
itemSpriteIndex["H"] = 175
itemSpriteIndex["V"] = 174

itemFont = {}
itemFont["N"] = "AppleColorEmoji"
itemFont["S"] = "AppleColorEmoji"
itemFont["W"] = "AppleColorEmoji"
itemFont["E"] = "AppleColorEmoji"
itemFont["B"] = "AppleColorEmoji"
itemFont["X"] = "AppleColorEmoji"
itemFont["I"] = "AppleColorEmoji"
itemFont["H"] = "AppleColorEmoji"
itemFont["V"] = "AppleColorEmoji"

itemColors = {}

itemSizes = {}
itemSizes["N"] = 12
itemSizes["S"] = 12
itemSizes["W"] = 12
itemSizes["E"] = 12
itemSizes["B"] = 12
itemSizes["X"] = 12
itemSizes["I"] = 12
itemSizes["H"] = 12
itemSizes["V"] = 12

itemVolts = {}
itemVolts["N"] = 1
itemVolts["S"] = 1
itemVolts["E"] = 1
itemVolts["W"] = 1
itemVolts["B"] = 2
itemVolts["X"] = 1
itemVolts["I"] = 1
itemVolts["M"] = 3
itemVolts["H"] = 2
itemVolts["V"] = 2
itemVolts["p"] = 1

gameText = {}
gameText["en"] = {}
gameText["fr"] = {}

gameText["en"]["currentLanguage"] = "Français"
gameText["fr"]["currentLanguage"] = "English"

gameText["en"]["level"] = "Level"
gameText["fr"]["level"] = "Niveau"

gameText["en"]["prevLevel"] = "Previous"
gameText["fr"]["prevLevel"] = "Précédent"

gameText["en"]["nextLevel"] = "Next"
gameText["fr"]["nextLevel"] = "Suivant"

gameText["en"]["restart"] = "Restart"
gameText["fr"]["restart"] = "Recommencer"

gameText["en"]["editor"] = "Level Editor"
gameText["fr"]["editor"] = "Éditeur de niveau"

gameText["en"]["teleport"] = "Teleport"
gameText["fr"]["teleport"] = "Téléporter"

gameText["en"]["explode"] = "Explode"
gameText["fr"]["explode"] = "Exploser"

gameText["en"]["antiExplode"] = "Implode"
gameText["fr"]["antiExplode"] = "Imploser"

gameText["en"]["tapToStart"] = "Tap to Start"
gameText["fr"]["tapToStart"] = "Toucher pour commencer"

gameText["en"]["title"] = "Lost Controls"
gameText["fr"]["title"] = "Contrôles Perdus"

gameText["en"]["installed1"] = "Installed Modules"
gameText["fr"]["installed1"] = "Modules Installés"

gameText["en"]["ground"] = "Ground"
gameText["fr"]["ground"] = "Sol"

gameText["en"]["energyStatus"] = "Available Power"
gameText["fr"]["energyStatus"] = "Énergie Disponible"

gameText["en"]["actions"] = "Actions"
gameText["fr"]["actions"] = "Actions"

gameText["en"]["energyUsed"] = "In use :"
gameText["fr"]["energyUsed"] = "Utilisée :"

gameText["en"]["energyAvailable"] = "Available :"
gameText["fr"]["energyAvailable"] = "Disponible :"

gameText["en"]["tapContinue"] = "Tap to continue..."
gameText["fr"]["tapContinue"] = "Tapotez pour continuer..."

gameText["en"]["enterContinue"] = "Press Enter to continue..."
gameText["fr"]["enterContinue"] = "Appuyez sur Entrée pour continuer..."

gameText["en"]["drop"] = "Tap to drop"
gameText["fr"]["drop"] = "Tapotez pour déposer"

gameText["en"]["take"] = "Tap to take"
gameText["fr"]["take"] = "Tapotez pour prendre"

gameText["en"]["keyboardDrop"] = "Press number to drop"
gameText["fr"]["keyboardDrop"] = "Appuyez le chiffre pour déposer"

gameText["en"]["keyboardTake"] = "Press number to take"
gameText["fr"]["keyboardTake"] = "Appuyez le chiffre pour prendre"

gameText["en"]["missingModule"] = "-= MISSING DIRECTION MODULE =-"
gameText["fr"]["missingModule"] = "-= MODULE DE DIRECTION MANQUANT =-"

gameText["en"]["impossibleMove"] = "-= MOVEMENT NOT POSSIBLE =-"
gameText["fr"]["impossibleMove"] = "-= DÉPLACEMENT IMPOSSIBLE =-"

gameText["en"]["directionInstalled"] = "-= '{0}' DIRECTION MODULE INSTALLED =-"
gameText["fr"]["directionInstalled"] = "-= MODULE DE DIRECTION '{0}' INSTALLÉ =-"

gameText["en"]["explosionInstalled"] = "-= SINGLE USE EXPLOSION INSTALLED =-"
gameText["fr"]["explosionInstalled"] = "-= EXPLOSION À USAGE UNIQUE INSTALLÉE =-"

gameText["en"]["bloodInstalled"] = "-= BLOOD FOLLOWING MODULE INSTALLED =-"
gameText["fr"]["bloodInstalled"] = "-= MODULE DE SUIVI DE SANG INSTALLÉ =-"

gameText["en"]["endOfDemo"] = "-= END OF DEMO REACHED =-"
gameText["fr"]["endOfDemo"] = "-= FIN DE LA DÉMO =-"

gameText["en"]["thanks"] = "-= THANKS FOR PLAYING! =-"
gameText["fr"]["thanks"] = "-= MERCI D'AVOIR JOUÉ! =-"

gameText["en"]["voltageTooHigh"] = "-= SURGE PROTECTION : VOLTAGE IS TOO HIGH =-"
gameText["fr"]["voltageTooHigh"] = "-= PROTECTION DE SURCHARGE : VOLTAGE TROP ÉLEVÉ =-"

gameText["en"]["endOfLevel"] = "-= LEVEL COMPLETED =-"
gameText["fr"]["endOfLevel"] = "-= NIVEAU TERMINÉ =-"

gameText["en"]["startingInventory"] = "Inventory"
gameText["fr"]["startingInventory"] = "Inventaire"

gameText["en"]["test"] = "Test"
gameText["fr"]["test"] = "Essayer"

gameText["en"]["clear"] = "Clear"
gameText["fr"]["clear"] = "Effacer"

gameText["en"]["clipboard"] = "Copy"
gameText["fr"]["clipboard"] = "Copier"

gameText["en"]["paste"] = "Paste"
gameText["fr"]["paste"] = "Coller"

gameText["en"]["developer"] = "Developer"
gameText["fr"]["developer"] = "Développeur"

gameText["en"]["jscodea"] = "Powered by JSCodea"
gameText["fr"]["jscodea"] = "Propulsé par JSCodea"

gameText["en"]["cannotDrop"] = "-= YOU CAN'T DROP HERE =-"
gameText["fr"]["cannotDrop"] = "-= VOUS NE POUVEZ PAS DÉPOSER ICI =-"

gameText["en"]["space"] = "Space"
gameText["fr"]["space"] = "Espace"

gameText["en"]["share"] = "Share"
gameText["fr"]["share"] = "Partager"

gameText["en"]["escape"] = "Escape" 
gameText["fr"]["escape"] = "Échappe"

gameText["en"]["E"] = "E" 
gameText["fr"]["E"] = "E"

gameText["en"]["Q"] = "Q" 
gameText["fr"]["Q"] = "Q"

gameText["en"]["R"] = "R" 
gameText["fr"]["R"] = "R"

gameText["en"]["backspace"] = "Backspace" 
gameText["fr"]["backspace"] = "Retour arrière"

gameText["en"]["undo"] = "Undo"
gameText["fr"]["undo"] = "Annuler"

gameText["en"]["levelBy"] = "A level by "
gameText["fr"]["levelBy"] = "Un tableau par "

globalStory = {}
globalStory[1] = { ["text"] = "impossibleMove" }
globalStory[2] = { ["text"] = "directionInstalled" }
globalStory[3] = { ["text"] = "bloodInstalled" }
globalStory[4] = { ["text"] = "endOfDemo", ["next"] = 5 }
globalStory[5] = { ["text"] = "thanks", ["next"] = 5 }
globalStory[6] = { ["text"] = "voltageTooHigh" }
globalStory[7] = { ["text"] = "endOfLevel", ["postFunc"] = nextLevel }
globalStory[8] = { ["text"] = "explosionInstalled" }
globalStory[9] = { ["text"] = "cannotDrop" }

localizedLevelNames = {}
localizedLevelNames["en"] = {}
localizedLevelNames["fr"] = {}

localizedLevelNames["en"]["Introduction"] = "Introduction"
localizedLevelNames["fr"]["Introduction"] = "Introduction"

localizedLevelNames["en"]["The Cross"] = "The Cross"
localizedLevelNames["fr"]["The Cross"] = "La croix"

localizedLevelNames["en"]["Ups & Downs"] = "Ups & Downs"
localizedLevelNames["fr"]["Ups & Downs"] = "Des hauts et des bas"

localizedLevelNames["en"]["Back & Forth"] = "Back & Forth"
localizedLevelNames["fr"]["Back & Forth"] = "Aller retour"

localizedLevelNames["en"]["The Explosion"] = "Explosion"
localizedLevelNames["fr"]["The Explosion"] = "Explosion"

localizedLevelNames["en"]["The Dog"] = "The Dog"
localizedLevelNames["fr"]["The Dog"] = "Le chien"

localizedLevelNames["en"]["Warping"] = "Warping"
localizedLevelNames["fr"]["Warping"] = "Saut"

localizedLevelNames["en"]["The Garden"] = "The Garden"
localizedLevelNames["fr"]["The Garden"] = "Le jardin"

localizedLevelNames["en"]["Water"] = "Water"
localizedLevelNames["fr"]["Water"] = "Eau"

localizedLevelNames["en"]["The Bottle"] = "The Bottle"
localizedLevelNames["fr"]["The Bottle"] = "La bouteille"

localizedLevelNames["en"]["Teleport"] = "Teleport"
localizedLevelNames["fr"]["Teleport"] = "Téléportation"

localizedLevelNames["en"]["Red Carpet"] = "Red Carpet"
localizedLevelNames["fr"]["Red Carpet"] = "Tapis rouge"

localizedLevelNames["en"]["TNT"] = "TNT"
localizedLevelNames["fr"]["TNT"] = "Dynamite"

localizedLevelNames["en"]["Port Tiny"] = "Port Tiny"
localizedLevelNames["fr"]["Port Tiny"] = "Petit port"

localizedLevelNames["en"]["Porthree"] = "Porthree"
localizedLevelNames["fr"]["Porthree"] = "Portrois"

localizedLevelNames["en"]["Mine Field"] = "Mine Field"
localizedLevelNames["fr"]["Mine Field"] = "Champs de mines"

localizedLevelNames["en"]["Diagon Alley"] = "Diagon Alley"
localizedLevelNames["fr"]["Diagon Alley"] = "Chemin de traverse"

localizedLevelNames["en"]["Shuriken"] = "Shuriken"
localizedLevelNames["fr"]["Shuriken"] = "Shuriken"

localizedLevelNames["en"]["The Wallet"] = "The Wallet"
localizedLevelNames["fr"]["The Wallet"] = "Portefeuille"

localizedLevelNames["en"]["The Fish"] = "The Fish"
localizedLevelNames["fr"]["The Fish"] = "Le poisson"

localizedLevelNames["en"]["The Knife"] = "The Knife"
localizedLevelNames["fr"]["The Knife"] = "Le couteau"

localizedLevelNames["en"]["Stanley Cup"] = "Stanley Cup"
localizedLevelNames["fr"]["Stanley Cup"] = "Coupe Stanley"

localizedLevelNames["en"]["Multidirectional"] = "Omnidirectional"
localizedLevelNames["fr"]["Multidirectional"] = "Omnidirectionnel"

localizedLevelNames["en"]["Diamond"] = "Diamond"
localizedLevelNames["fr"]["Diamond"] = "Diamant"

localizedLevelNames["en"]["Pop It"] = "Pop It"
localizedLevelNames["fr"]["Pop It"] = "Pop It"

localizedLevelNames["en"]["Flooded"] = "Flooded"
localizedLevelNames["fr"]["Flooded"] = "Inondé"

localizedLevelNames["en"]["Lasers"] = "Lasers"
localizedLevelNames["fr"]["Lasers"] = "Lasers"

localizedLevelNames["en"]["Squid Game"] = "Squid Game"
localizedLevelNames["fr"]["Squid Game"] = "Squid Game"

localizedLevelNames["en"]["Desync"] = "Desynchronized"
localizedLevelNames["fr"]["Desync"] = "Désynchronisés"

localizedLevelNames["en"]["Geasy"] = "Geasy"
localizedLevelNames["fr"]["Geasy"] = "G facile"

localizedLevelNames["en"]["Doors & Switches"] = "Doors & Switches"
localizedLevelNames["fr"]["Doors & Switches"] = "Portes & Interrupteurs"

localizedLevelNames["en"]["Snake"] = "Snake"
localizedLevelNames["fr"]["Snake"] = "Serpent"

localizedLevelNames["en"]["Tic Tac Toe"] = "Tic Tac Toe"
localizedLevelNames["fr"]["Tic Tac Toe"] = "Tic Tac Toe"

localizedLevelNames["en"]["Ballet"] = "Ballet"
localizedLevelNames["fr"]["Ballet"] = "Ballet"

localizedLevelNames["en"]["The Offset"] = "The Offset"
localizedLevelNames["fr"]["The Offset"] = "Décalage"

localizedLevelNames["en"]["The Spade"] = "The Spade"
localizedLevelNames["fr"]["The Spade"] = "La pelle"

localizedLevelNames["en"]["The Corridor"] = "The Corridor"
localizedLevelNames["fr"]["The Corridor"] = "Le corridor"

localizedLevelNames["en"]["The Box"] = "The Box"
localizedLevelNames["fr"]["The Box"] = "La boîte"

localizedLevelNames["en"]["Flower"] = "Flower"
localizedLevelNames["fr"]["Flower"] = "Fleur"

localizedLevelNames["en"]["Little Solier"] = "Little Solier"
localizedLevelNames["fr"]["Little Solier"] = "Petit soldat"

localizedLevelNames["en"]["The First Implosion"] = "The First Implosion"
localizedLevelNames["fr"]["The First Implosion"] = "La première implosion"

localizedLevelNames["en"]["Bomb"] = "Bomb"
localizedLevelNames["fr"]["Bomb"] = "Bombe"

localizedLevelNames["en"]["Meditation"] = "Meditation"
localizedLevelNames["fr"]["Meditation"] = "Méditation"

localizedLevelNames["en"]["The Rabbit"] = "The Rabbit"
localizedLevelNames["fr"]["The Rabbit"] = "Le lapin"

localizedLevelNames["en"]["The Head"] = "The Head"
localizedLevelNames["fr"]["The Head"] = "La tête"

localizedLevelNames["en"]["Placement"] = "Placement"
localizedLevelNames["fr"]["Placement"] = "Placement"

localizedLevelNames["en"]["Grenadier"] = "Grenadier"
localizedLevelNames["fr"]["Grenadier"] = "Grenadier"

localizedLevelNames["en"]["Frogger"] = "Frogger"
localizedLevelNames["fr"]["Frogger"] = "Frogger"

localizedLevelNames["en"]["Directional"] = "Directional"
localizedLevelNames["fr"]["Directional"] = "Directionnel"

localizedLevelNames["en"]["Portable"] = "Portable"
localizedLevelNames["fr"]["Portable"] = "Portable"

localizedLevelNames["en"]["The Wave"] = "The Wave"
localizedLevelNames["fr"]["The Wave"] = "La vague"

localizedLevelNames["en"]["Mine Field 2"] = "Mine Field 2"
localizedLevelNames["fr"]["Mine Field 2"] = "Champs de mines 2"

localizedLevelNames["en"]["Mine Field 3"] = "Mine Field 3"
localizedLevelNames["fr"]["Mine Field 3"] = "Champs de mines 3"

localizedLevelNames["en"]["Cracks"] = "Cracks"
localizedLevelNames["fr"]["Cracks"] = "Fissures"

localizedLevelNames["en"]["Portable 2"] = "Portable 2"
localizedLevelNames["fr"]["Portable 2"] = "Portable 2"

localizedLevelNames["en"]["Ruby"] = "Ruby"
localizedLevelNames["fr"]["Ruby"] = "Rubis"

localizedLevelNames["en"]["Left Behind"] = "Left Behind"
localizedLevelNames["fr"]["Left Behind"] = "Laissé derrière"

localizedLevelNames["en"]["Red Velvet"] = "Red Velvet"
localizedLevelNames["fr"]["Red Velvet"] = "Red Velvet"

localizedLevelNames["en"]["Yoga"] = "Yoga"
localizedLevelNames["fr"]["Yoga"] = "Yoga"

localizedLevelNames["en"]["Springboard"] = "Springboard"
localizedLevelNames["fr"]["Springboard"] = "Tremplin"

localizedLevelNames["en"]["Plugged In"] = "Plugged In"
localizedLevelNames["fr"]["Plugged In"] = "Branché"

localizedLevelNames["en"]["Demining"] = "Demining"
localizedLevelNames["fr"]["Demining"] = "Déminage"

localizedLevelNames["en"]["Hip Hop"] = "Hip Hop"
localizedLevelNames["fr"]["Hip Hop"] = "Hip Hop"
