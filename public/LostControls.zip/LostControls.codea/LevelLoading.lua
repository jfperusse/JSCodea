function getLevelVisuals(level, levelHeight, levelWidth)
    local pending = {}
    local visuals = {}
    local visited = {}
    local valid = true
    for row = 1, levelHeight do
        visited[row] = {}
        visuals[row] = {}
        for col = 1, levelWidth do
            visited[row][col] = false
            local levelChar = string.sub(level[row], col, col)
            visuals[row][col] = levelChar
            if levelChar == "P" or tonumber(levelChar) ~= nil then
                table.insert(pending, vec2(row, col))
            end
        end
    end
     
    while #pending > 0 do
        local current = table.remove(pending, 1)
        
        if current.x == 1 or current.x == levelHeight or
        current.y == 1 or current.y == levelWidth then
            valid = false
        end
        
        -- Down
        if current.x > 1 and not visited[current.x - 1][current.y] and
        string.sub(level[current.x - 1], current.y, current.y) ~= "#" then
            table.insert(pending, vec2(current.x - 1, current.y))
            visited[current.x - 1][current.y] = true
        end
        
        -- Up
        if current.x < levelHeight and not visited[current.x + 1][current.y] and
        string.sub(level[current.x + 1], current.y, current.y) ~= "#" then
            table.insert(pending, vec2(current.x + 1, current.y))
            visited[current.x + 1][current.y] = true
        end
        
        -- Left
        if current.y > 1 and not visited[current.x][current.y - 1] and
        string.sub(level[current.x], current.y - 1, current.y - 1) ~= "#" then
            table.insert(pending, vec2(current.x, current.y - 1))
            visited[current.x][current.y - 1] = true
        end
        
        -- Right
        if current.y < levelWidth and not visited[current.x][current.y + 1] and
        string.sub(level[current.x], current.y + 1, current.y + 1) ~= "#" then
            table.insert(pending, vec2(current.x, current.y + 1))
            visited[current.x][current.y + 1] = true
        end
        
        local currentChar = string.sub(level[current.x], current.y, current.y)
        if not table.contains({ "$", "_" }, currentChar) then
            visuals[current.x][current.y] = "F"
        elseif mappingEffects[currentChar] ~= nil then
            visuals[current.x][current.y] = currentChar
        else
            visuals[current.x][current.y] = " "
        end
    end
    
    return visuals, valid
end

function loadEditorLevel()
    createMainButtons(true)
    
    laserPhase = 1
    intro = false
    isEditor = false
    isEditorLevel = true
    music.paused = false
    
    level = table.clone(editor.level)
    levelType = editor.levelType
    levelBlood = editor.levelBlood
    levelElectric = editor.levelElectric
    
    loadGlobalLevel()
    
    for i = 1, game.maxInventory do
        local item = editor.startingInventory[i]
        if item ~= nil then
            game:addInventory(item, true)
        end
    end
    
    game.currentMessageId = -1
end

function getLevelCharFromGrid(levelVisuals, row, col, levelHeight, levelWidth)
    local levelCol = col - 1
    local levelRow = levelHeight - (row - 1) + 1
    if levelVisuals[levelRow] == nil or levelVisuals[levelRow][levelCol] == nil then
        return " "
    else
        local char = levelVisuals[levelRow][levelCol]
        if mappingEffects[char] ~= nil then
            return char
        else
            return " "
        end
    end
end

function applyMapping(levelGrid, levelVisuals, levelHeight, levelWidth)    
    if levelMapping == nil then
        return
    end
    
    local nextTorch = math.random(0, 3)
    
    for row = 1, levelHeight + 2 do
        levelGrid[row] = {}
        for col = 1, levelWidth + 2 do
            levelGrid[row][col] = {}
            nextTorch = nextTorch - 1
            local currentMapping = levelMapping
            local centerChar = getLevelCharFromGrid(levelVisuals, row, col, levelHeight, levelWidth)
            local effect = mappingEffects[centerChar]
            for newRow = row + 1, row - 1, -1 do
                for newCol = col - 1, col + 1 do
                    local char = getLevelCharFromGrid(levelVisuals, newRow, newCol, levelHeight, levelWidth)
                    if (newRow ~= row or newCol ~= col) and not table.contains(effect, char) then
                        char = "*"
                    end
                    if currentMapping ~= nil then
                        currentMapping = currentMapping[char]
                    end
                end
            end
            if currentMapping ~= nil then
                for i = 1, #currentMapping do
                    local sprIndex = currentMapping[i]
                    local spr 
                    if sprIndex ~= -1 then
                        spr = sprites[sprIndex]
                    else
                        spr = {}
                    end
                    table.insert(levelGrid[row][col], spr)
                    if sprIndex == torchWallIndex and nextTorch <= 0 then
                        nextTorch = 2
                        local torch = copyAnim(animTorch)
                        table.insert(levelGrid[row][col], torch)
                        table.insert(anims, torch)
                    end
                end
            elseif centerChar == "#" then
                table.insert(levelGrid[row][col], defaultFloorSprite)
                table.insert(levelGrid[row][col], defaultWallSprite)
            end
        end
    end
end

function loadGlobalLevel()
    blood = {}
    electric = {}
    ground = {}
    portals = {}
    portablePortals = {}
    lasers = {}
    doors = {}
    switches = {}
    boxes = {}
    anims = { animRobot, animPortal, animPortablePortal, animCrystal, animFan, animElectric }
    levelContainsExplosions = false
    levelContainsAntiExplosions = false
    undoBuffer = {}
    
    levelWidth = #level[1]
    levelHeight = #level
    
    levelVisuals = getLevelVisuals(level, levelHeight, levelWidth)
    
    for i, v in ipairs(level) do
        blood[i] = {}
        electric[i] = {}
        ground[i] = {}
        for j = 1, #v do
            c = v:sub(j, j)
            blood[i][j] = getLevelBlood(i, j)
            electric[i][j] = getLevelElectric(i, j)
            ground[i][j] = { nil, nil, nil }
            local charByte = string.byte(c)
            if isPortalByte(charByte) then
                if portals[charByte] == nil then
                    portals[charByte] = {}
                end
                table.insert(portals[charByte], vec2(i, j))
            elseif c == "p" then
                addToGround(i, j, c)
                removeFromLine(i, c)
                local portablePortal = {}
                portablePortal.pos = vec2(i, j)
                table.insert(portablePortals, portablePortal)
            elseif c == "P" then
                playerLine = i
                playerCol = j
                removeFromLine(i, c)
            elseif isItem(c) then
                addToGround(i, j, c)
                removeFromLine(i, c)
                if c == "X" then
                    levelContainsExplosions = true
                elseif c == "I" then
                    levelContainsAntiExplosions = true
                end
            elseif c == "o" then
                box = {}
                box.pos = vec2(i, j)
                table.insert(boxes, box)
                removeFromLine(i, c)
            elseif isLaser(c) then
                laser = {}
                laser.pos = vec2(i, j)
                if c == "<" then
                    laser.dir = vec2(0, -1)
                elseif c == ">" then
                    laser.dir = vec2(0, 1)
                elseif c == "^" then
                    laser.dir = vec2(-1, 0)
                elseif c == "v" then
                    laser.dir = vec2(1, 0)
                end
                table.insert(lasers, laser)
            elseif isDoor(c) then
                door = {}
                door.type = getLevelType(i, j)
                door.startOpened = (c == "d")
                doors[vec2(i, j)] = door
            elseif isSwitch(c) then
                switch = {}
                switch.type = getLevelType(i, j)
                switches[vec2(i, j)] = switch
            end
        end
    end
    
    showLevel = true
    game.inventory = { nil, nil, nil }
    game.showVoltages = true
    if blood[playerLine][playerCol] == 0 then
        blood[playerLine][playerCol] = 1
    end
    
    levelGrid = {}
    
    applyMapping(levelGrid, levelVisuals, levelHeight, levelWidth)
end

function loadLevel(in_levelIndex)
    createMainButtons(false)
    
    intro = (in_levelIndex == 1 and not isEditor)
    laserPhase = 1
    isEditorLevel = false
    levelIndex = in_levelIndex
    localizedStrings = levelStrings[levelIndex]
    level = table.clone(levels[levelIndex])
    levelType = levelTypes[levelIndex]
    levelBlood = levelBloods[levelIndex]
    levelElectric = levelElectrics[levelIndex]
    story = stories[levelIndex]
    fullLevelLimit = nil
    
    loadGlobalLevel()
    
    if not intro then
        if story ~= nil then
            game:displayMessage(1)
        else
            game.currentMessageId = -1
        end
        if levelIndex ~= 1 then
            for k, v in ipairs(inventories[levelIndex]) do
                game:addInventory(v, true)
            end
        end
    end
end

function prevLevel()
    local prevLevelIndex = levelIndex - 1
    if prevLevelIndex < 1 then
        prevLevelIndex = #levels
    end
    loadLevel(prevLevelIndex)
    
    if isEditor then
        editor:open()
    end
end

function nextLevel(isCheat)
    local nextLevelIndex = levelIndex + 1
    if levels[nextLevelIndex] ~= nil then
        loadLevel(nextLevelIndex)
    else
        if isCheat then
            loadLevel(1)
        else
            game:displayMessage(4, nil, true)
        end
    end
    
    if isEditor then
        editor:open()
    end
end

function restart()
    if isEditorLevel then
        loadEditorLevel()
    else
        loadLevel(levelIndex)
    end
end