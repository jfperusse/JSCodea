function touched(touch)
    if waitToStart then
        startGame()
        return
    end
    
    if intro then
        if touch.state == BEGAN then
            introTap()
        end
        return
    end
     
    local anyButton = false
    for i,v in ipairs(buttons) do
        if v:touched(touch) then
            anyButton = true
        end
    end
    
    if anyButton then
        waitForButtonRelease = true
    end
    
    if isEditor then
        editor:touched(touch, waitForButtonRelease)
    else
        game:touched(touch, waitForButtonRelease)
    end
    
    if not anyButton then
        waitForButtonRelease = false
    end
end

function handleDpadPressed(direction, x, y)
    if not isEditor and not intro then
        game:swipe(vec2(0, 0), direction, x, y)
    end
end

function checkGameController()
    if gameController == nil then
        initGameController()
        
        if gameController ~= nil then
            gameController.dpad.left.pressedChangedHandler = function(objButton, floatValue, boolPressed)
                if boolPressed then
                    handleDpadPressed(SwipeLeft, -1, 0)
                end
            end
            
            gameController.dpad.right.pressedChangedHandler = function(objButton, floatValue, boolPressed)
                if boolPressed then
                    handleDpadPressed(SwipeRight, 1, 0)
                end
            end
            
            gameController.dpad.up.pressedChangedHandler = function(objButton, floatValue, boolPressed)
                if boolPressed then
                    handleDpadPressed(SwipeUp, 0, 1)
                end
            end
            
            gameController.dpad.down.pressedChangedHandler = function(objButton, floatValue, boolPressed)
                if boolPressed then
                    handleDpadPressed(SwipeDown, 0, -1)
                end
            end
            
            gameController.gamepad.buttonA.pressedChangedHandler = function(objButton, floatValue, boolPressed)
                if boolPressed and not isEditor then
                    if waitToStart then
                        startGame()
                    elseif intro then
                        introTap()
                    else
                        game:tap()
                    end
                end
            end
        end
    end
end

function js_keydown(key)
    if waitToStart then
        if (key == "Enter" or key == "\n") then
            startGame()
        end
        return
    end
    
    if key == "Backspace" then
        undo()
    end
    if key == "ArrowLeft" or key == "a" then
        handleDpadPressed(SwipeLeft, -1, 0)
    end
    if key == "ArrowRight" or key == "d" then
        handleDpadPressed(SwipeRight, 1, 0)
    end
    if key == "ArrowUp" or key == "w" then
        handleDpadPressed(SwipeUp, 0, 1)
    end
    if key == "ArrowDown" or key == "s" then
        handleDpadPressed(SwipeDown, 0, -1)
    end
    if (key == "Enter" or key == "\n") and not isEditor then
        if intro then
            introTap()
        else
            game:tap()
        end
    end
    if (key == "r" or key == "R") and not isEditor then
        restart()
    end
    local keyNumber = tonumber(key)
    if keyNumber ~= nil then
        if keyNumber >= 1 and keyNumber <= 3 then
            onDropButton(keyNumber)
        elseif keyNumber >= 4 and keyNumber <= 6 then
            onTakeButton(keyNumber-3)
        end
    end
    if key == " " then
        game:teleport()
    end
    if key == "e" or key == "W" then
        game:explode(false)
    end
    if key == "q" or key == "Q" then
        game:explode(true)
    end
end

function keyboard(key)
    if not isRuntime() and _isJSCodea then
        js_keydown(key)
    end
end
