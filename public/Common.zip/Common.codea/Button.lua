Button = class()

buttons = {}

Button.useAppFont = false
Button.font = "AmericanTypewriter-Bold"
Button.defaultStrokeWidth = 5

function AddButton(in_x, in_y, in_width, in_height, in_text, in_func, in_tag)
    local button = Button(in_x, in_y, in_width, in_height, in_text, in_func, in_tag)
    table.insert(buttons, button)
    return button
end

function CreateSpriteButton(in_x, in_y, in_width, in_height, in_sprite, in_func, in_tag)
    local button = Button(in_x, in_y, in_width, in_height, nil, in_func, in_tag)
    button.sprite = in_sprite
    button.spriteFit = true
    button.drawRectangle = false
    return button
end

function AddSpriteButton(in_x, in_y, in_width, in_height, in_sprite, in_func, in_tag)
    local button = CreateSpriteButton(in_x, in_y, in_width, in_height, in_sprite, in_func, in_tag)
    table.insert(buttons, button)
    return button
end

function removeButtonWithTag(in_tag)
    for i, v in ipairs(buttons) do
        if v.tag == in_tag then
            table.remove(buttons, i)
            return
        end
    end
end

function removeLastButtonWithTag(in_tag)
    for i = 1, #buttons do
        j = #buttons - i + 1
        v = buttons[j]
        if v.tag == in_tag then
            table.remove(buttons, j)
            return
        end        
    end
end

function hasButtonWithTag(in_tag)
    for i, v in ipairs(buttons) do
        if v.tag == in_tag then
            return true
        end
    end
    return false
end

function Button:init(in_x, in_y, in_width, in_height, in_text, in_func, in_tag)
    self.x = in_x
    self.y = in_y
    self.width = in_width
    self.height = in_height
    self.right = in_x + in_width
    self.top = in_y + in_height
    self.font = Button.font
    self.text = in_text
    self.textSize = 32
    self.func = in_func
    self.center = vec2(math.floor(in_x + 0.5 * in_width), math.floor(in_y + 0.5 * in_height))
    self.textColor = color(255, 255, 255, 255)
    self.textOffset = vec2(0, 0)
    self.testFunc = nil
    self.sprite = nil
    self.spriteScale = 1
    self.spriteFit = false
    self.spriteTint = nil
    self.tag = in_tag
    self.localizedText = false
    self.localizedArray = nil
    self.selectedFunc = nil
    self.notSelectedAlpha = 0.25
    self.releasedFunc = nil
    self.touchId = -1
    self.useAppFont = Button.useAppFont
    self.drawRectangle = true
    self.drawBorder = true
    self.spriteAngle = 0
    self.fillColor = color(201, 201, 201, 255)
    self.spriteImage = nil
    self.loadedSprite = nil
    self.selectionTransparency = 0.5
    self.selectionBorderOnly = false
    self.keyboardHint = nil
    self.keyboardHintFunc = nil
    self.keyboardHintSize = nil
    self.fillRectangle = true
    self.strokeWidth = Button.defaultStrokeWidth
    self.selectedSprite = nil
    self.selectedSpriteImage = nil
    self.selectedLoadedSprite = nil
    self.spriteSize = nil
    self.spriteFunc = nil
    self.backgroundSprite = nil
    self.backgroundSpriteTint = nil
    self.foregroundSprite = nil
    self.foregroundSpriteTint = nil
end

function Button:setPos(in_x, in_y)
    self.x = in_x
    self.y = in_y
    self.center = vec2(in_x + 0.5 * self.width, in_y + 0.5 * self.height)
    self.right = self.x + self.width
    self.top = self.y + self.height
end

function Button:setX(in_x)
    self.x = in_x
    self.center.x = in_x + 0.5 * self.width
    self.right = self.x + self.width
end

function Button:setY(in_y)
    self.y = in_y
    self.center.y = in_y + 0.5 * self.height
    self.top = self.y + self.height
end

function Button:offset(in_x, in_y)
    self:setPos(self.x + in_x, self.y + in_y)
end

function Button:setTextColor(in_color)
    self.textColor = in_color
end

function Button:setTextSize(in_size)
    self.textSize = in_size
end

function Button:setTestFunc(in_func)
    self.testFunc = in_func
end

function Button:setReleasedFunc(in_func)
    self.releasedFunc = in_func
end

function Button:setSprite(in_sprite)
    self.sprite = in_sprite
end

function Button:setSpriteWithScale(in_sprite, in_scale)
    self.sprite = in_sprite
    self.spriteScale = in_scale
end

function Button:setUseAppFont()
    self.useAppFont = true
end

function Button:safeAreaLeft()
    return layout.safeArea.left
end

function Button:safeAreaRight()
    return WIDTH - layout.safeArea.right
end

function Button:safeAreaTop()
    return HEIGHT - layout.safeArea.top
end

function Button:safeAreaBottom()
    return layout.safeArea.bottom
end

function Button:safeOffsetX()
    local offset = self:safeAreaLeft() - self.x
    if offset > 0 then
        return offset
    end
    
    offset = self.right - self:safeAreaRight()
    if offset > 0 then
        return -offset
    end
    
    return 0
end

function Button:safeOffsetY()
    local offset = self:safeAreaBottom() - self.y
    if offset > 0 then
        return offset
    end
    
    offset = self.top - self:safeAreaTop()
    if offset > 0 then
        return -offset
    end
    
    return 0
end

function Button:safeX()
    return self.x + self:safeOffsetX()
end

function Button:safeRight()
    return self.right + self:safeOffsetX()
end

function Button:safeCenterX()
    return self.center.x + self:safeOffsetX()
end

function Button:safeY()
    return self.y + self:safeOffsetY()
end

function Button:safeTop()
    return self.top + self:safeOffsetY()
end

function Button:safeCenterY()
    return self.center.y + self:safeOffsetY()
end

function Button:_drawSprite(spriteImage, spriteTint, alpha)
    if spriteImage == nil then return end
    
    local r, g, b, a = tint()
    backupTint = color(r, g, b, a)
    if spriteTint ~= nil then
        tint(spriteTint.r, spriteTint.g, spriteTint.b, alpha * spriteTint.a)
    else
        tint(255, 255, 255, alpha * 255)
    end
    if self.spriteFit then
        sprite(spriteImage, 0, 0, self.width, self.height)
    elseif self.spriteSize ~= nil then
        sprite(spriteImage, 0, 0, self.spriteSize.x, self.spriteSize.y)
    else
        sprite(spriteImage)
    end
    tint(backupTint)
end

function Button:draw()
    if self.testFunc ~= nil and self.testFunc() == false then
        return
    end
    
    local selected = true
    
    if self.selectedFunc ~= nil then
        selected = self.selectedFunc()
    end
    
    if self.spriteFunc ~= nil then
        self.sprite = self.spriteFunc()
    end
    
    local alpha = selected and 1.0 or self.notSelectedAlpha
    
    pushStyle()
    
    if not self.useAppFont then
        font(self.font)
        fontSize(self.textSize)
    end
    
    if self.drawRectangle then
        if self.drawBorder and (not self.selectionBorderOnly or selected) then
            strokeWidth(self.strokeWidth)
            stroke(255, 255, 255, 255)
        else
            noStroke()
        end
        
        if self.fillRectangle then
            if selected then
                fill(self.fillColor)
            else
                fill(self.selectionTransparency * self.fillColor)
            end
        else
            noFill()
        end
        
        rectMode(CORNER)
        if self.sprite ~= nil and self.spriteFit then
            rect(self:safeX() - self.strokeWidth, 
                 self:safeY() - self.strokeWidth,
                 self.width + 2 * self.strokeWidth,
                 self.height + 2 * self.strokeWidth)
        else
            rect(self:safeX(), self:safeY(), self.width, self.height)
        end
        
        if self.keyboardHint then
            if self.keyboardHintFunc == nil or self.keyboardHintFunc() then
                local defaultSize = fontSize()
                if self.keyboardHintSize then
                    fontSize(self.keyboardHintSize)
                end
                local hintText = self.keyboardHint
                if self.localizedArray then
                    hintText = localization:get(hintText, self.localizedArray)
                end    
                textWidth, textHeight = textSize(hintText)
                textWidth = textWidth + 12
                textHeight = textHeight + 10
                local hintX = self:safeX() + self.width - textWidth
                local hintY = self:safeY() + self.height - textHeight
                textMode(CENTER)
                fill(self.textColor.r, self.textColor.g, self.textColor.b, alpha * self.textColor.a)
                                
                text(hintText, hintX + textWidth / 2, hintY + textHeight / 2)
                fontSize(defaultSize)
            end
        end
    end

    fill(self.textColor.r, self.textColor.g, self.textColor.b, alpha * self.textColor.a)
    
    if self.sprite ~= nil then
        if self.spriteImage == nil or self.sprite ~= self.loadedSprite then
            self.loadedSprite = self.sprite
            
            if self.sprite.set ~= nil then
                self.spriteImage = self.sprite
            else
                self.spriteImage = readImage(self.sprite)
                self.spriteImage.premultiplied = false
            end
        end
        if self.selectedSprite and (self.selectedSpriteImage == nil or self.selectedSprite ~= self.selectedLoadedSprite) then
            self.selectedLoadedSprite = self.selectedSprite
            
            if self.selectedSprite.set ~= nil then
                self.selectedSpriteImage = self.selectedSprite
            else
                self.selectedSpriteImage = readImage(self.selectedSprite)
                self.selectedSpriteImage.premultiplied = false
            end
        end
        local imageToUse = (selected and self.selectedSprite) and self.selectedSpriteImage or self.spriteImage
        spriteMode(CENTER)
        pushMatrix()
        translate(self:safeCenterX(), self:safeCenterY())
        if self.spriteAngle ~= 0 then
            rotate(self.spriteAngle)
        end
        if self.spriteScale ~= 0 then
            scale(self.spriteScale)
        end
        
        self:_drawSprite(self.backgroundSprite, self.backgroundSpriteTint, alpha)
        self:_drawSprite(imageToUse, self.spriteTint, alpha)
        self:_drawSprite(self.foregroundSprite, self.foregroundSpriteTint, alpha)
        
        popMatrix()
    end
        
    textMode(CENTER)
    textAlign(CENTER)
    local textX = self:safeCenterX() + self.textOffset.x
    local textY = self:safeCenterY() + self.textOffset.y
    if self.localizedText then
        text(localization:get(self.text, self.localizedArray), textX, textY)
    elseif self.text then
        text(self.text, textX, textY)
    end    
    
    popStyle()
end

function Button:isOver(touch)
    if self.testFunc ~= nil and self.testFunc() == false then
        return false
    end
    return touch.x > self:safeX() and touch.x < self:safeRight() and
           touch.y > self:safeY() and touch.y < self:safeTop()
end

function Button:touched(touch)    
    if self:isOver(touch) then
        if self.touchId == -1 and touch.state == BEGAN then
            self.pressed = true
            self.touchId = touch.id
            if self.func ~= nil then
                self.func()
            end
            return true
        end
    end
    if touch.state == ENDED and self.touchId == touch.id then
        self.touchId = -1
        if self.releasedFunc ~= nil then
            self.releasedFunc()
        end
    end
    return false
end

function DrawButtons()
    for i,v in ipairs(buttons) do
        v:draw()
    end
end

function UpdateButtons(touch)
    local anyButton = false
    
    for i,v in ipairs(buttons) do
        anyButton = v:touched(touch) or anyButton 
    end
    
    return anyButton
end