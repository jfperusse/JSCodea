function initGameController()
    if gameController == nil then
        local controllers = objc.cls.GCController.controllers
        local count = #controllers
        if count > 0 then
            print("Controller connected!")
            gameController = {}
            gameController.controller = controllers[1]
            gameController.gamepad = gameController.controller.extendedGamepad
            gameController.dpad = gameController.gamepad.dpad
        end
    end
end