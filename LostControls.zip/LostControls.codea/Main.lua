-- LostControls

levels = {}
stories = {}
inventories = {}
levelTypes = {}
levelBloods = {}
levelNames = {}
levelStrings = {}
portalColors = {
    color(255, 14, 0),
    color(108, 255, 0),
    color(0, 44, 255)
}
laserColors = {
    color(0, 255, 0),
    color(255, 255, 0),
    color(255, 125, 0),
    color(255, 0, 0)
}
doorColors = {
    color(255, 14, 0),
    color(108, 255, 0),
    color(0, 44, 255)
}
doorDarkColors = {
    color(100, 14, 0),
    color(8, 100, 0),
    color(0, 44, 100)
}

function addAnim(assetName, msPerFrame)
    local anim = readAnimAsset(assetName, msPerFrame)
    table.insert(sprites, anim)
end

-- Use this function to perform your initial setup
function setup()
    Button.useAppFont = true
    Button.defaultStrokeWidth = 2
    
    --local icon = readImage(asset.LostControlsIcon)
    --saveImage(asset.Icon,icon)
    
    localization = Localization("fr")

    sprites = {}
    editor = LevelEditor()
    isEditor = false
    introTime = 0
    waitForButtonRelease = false
    isDeveloper = false
    tileSize = 16
    cellSize = tileSize * 2
    levelY = HEIGHT/2 - 40
    torchWallIndex = 146
    waitToStart = true
    maxUndo = 100

    noSmooth()
    
    readTilesetAsset(tileSize, asset.Dungeon_Tileset, sprites)
    
    animTorch = readAnimAsset(tileSize, asset.torch_prop_anim_strip_5, 100)
    animCrystal = readAnimAsset(tileSize, asset.crystal_item_anim_strip_6, 100)
    animRobot = readAnimAsset(tileSize, asset.Robot_v1, 400)
    animPortal = readAnimAsset(tileSize, asset.Portal, 100)
    animPortablePortal = readAnimAsset(tileSize, asset.PortablePortal, 100)
    animFan = readAnimAsset(tileSize, asset.Fan, 66)

    defaultWallSprite = sprites[70]
    bloodSprite = sprites[120]
    waterSprite = sprites[163]
    
    laserSprites = {}
    laserSprites[">"] = sprites[133]
    laserSprites["<"] = sprites[134]
    laserSprites["^"] = sprites[135]
    laserSprites["v"] = sprites[136]
    
    laserLightSprites = {}
    laserLightSprites[">"] = sprites[137]
    laserLightSprites["<"] = sprites[138]
    laserLightSprites["^"] = sprites[139]
    laserLightSprites["v"] = sprites[140]
    
    boxSprite = sprites[141]
    
    doorClosedSprite = sprites[151]
    doorOpenedSprite = sprites[152]
    doorLightsClosedSprite = sprites[153]
    doorLightsOpenedSprite = sprites[154]
    switchSprite = sprites[155]
    switchLights = sprites[156]
    
    simpleLevelMapping = json.decode(simpleTileMappingJson)
    mappingEffects = {
        ["F"] = {},
        ["#"] = { "F", "#", " " },
        ["_"] = { "_" },
        ["$"] = {},
        [" "] = { "#" }
    }
    
    itemSprites = {}
    for k, v in pairs(itemSpriteIndex) do
        itemSprites[k] = sprites[v]
    end
    
    parameter.integer("charSize", 8, 40, 20)
    parameter.action("Test JSCodea", function()
        if _isJSCodea then
            _isJSCodea = nil
        else
            _isJSCodea = true
        end
    end)
        
    viewer.mode = FULLSCREEN_NO_BUTTONS
    
    game = Game()
    showLevel = true
    
    firstPortal = string.byte("1")
    lastPortal = string.byte("9")
    
    local levelToLoad = 1
    
    if _isJSCodea == true and context ~= nil then
        local parameters = context:getParameters()
        if parameters["levelToLoad"] ~= nil then
            levelToLoad = tonumber(parameters["levelToLoad"])
            print("willLoadLevel " .. levelToLoad)
        end
    end
    
    loadLevel(levelToLoad)
end

function startGame()
    music(asset.downloaded.A_Hero_s_Quest.Dungeon,true,0.5)
    waitToStart = false
end

function getLevelVisuals(level, levelHeight, levelWidth)
    local pending = {}
    local visuals = {}
    local visited = {}
    local valid = true
    for row = 1, levelHeight do
        visited[row] = {}
        visuals[row] = {}
        for col = 1, levelWidth do
            visited[row][col] = false
            local levelChar = string.sub(level[row], col, col)
            visuals[row][col] = levelChar
            if levelChar == "P" or tonumber(levelChar) ~= nil then
                table.insert(pending, vec2(row, col))
            end
        end
    end
    
    while #pending > 0 do
        local current = table.remove(pending, 1)
        
        if current.x == 1 or current.x == levelHeight or
           current.y == 1 or current.y == levelWidth then
            valid = false
        end
        
        -- Down
        if current.x > 1 and not visited[current.x - 1][current.y] and
        string.sub(level[current.x - 1], current.y, current.y) ~= "#" then
            table.insert(pending, vec2(current.x - 1, current.y))
            visited[current.x - 1][current.y] = true
        end
        
        -- Up
        if current.x < levelHeight and not visited[current.x + 1][current.y] and
        string.sub(level[current.x + 1], current.y, current.y) ~= "#" then
            table.insert(pending, vec2(current.x + 1, current.y))
            visited[current.x + 1][current.y] = true
        end
        
        -- Left
        if current.y > 1 and not visited[current.x][current.y - 1] and
        string.sub(level[current.x], current.y - 1, current.y - 1) ~= "#" then
            table.insert(pending, vec2(current.x, current.y - 1))
            visited[current.x][current.y - 1] = true
        end
        
        -- Right
        if current.y < levelWidth and not visited[current.x][current.y + 1] and
        string.sub(level[current.x], current.y + 1, current.y + 1) ~= "#" then
            table.insert(pending, vec2(current.x, current.y + 1))
            visited[current.x][current.y + 1] = true
        end
        
        local currentChar = string.sub(level[current.x], current.y, current.y)
        if not table.contains({ "$", "_" }, currentChar) then
            visuals[current.x][current.y] = "F"
        else
            visuals[current.x][current.y] = currentChar
        end
    end
    
    return visuals, valid
end

function prevLevel()
    local prevLevelIndex = levelIndex - 1
    if prevLevelIndex < 1 then
        prevLevelIndex = #levels
    end
    loadLevel(prevLevelIndex)
    
    if isEditor then
        editor:open()
    end
end

function nextLevel(isCheat)
    local nextLevelIndex = levelIndex + 1
    if levels[nextLevelIndex] ~= nil then
        loadLevel(nextLevelIndex)
    else
        if isCheat then
            loadLevel(1)
        else
            game:displayMessage(4, nil, true)
        end
    end

    if isEditor then
        editor:open()
    end
end

function restart()
    if isEditorLevel then
        loadEditorLevel()
    else
        loadLevel(levelIndex)
    end
end

function createMainButtons(isEditor)
    buttons = {}
    
    if not isRuntime() then
        viewerButton = Button(5, HEIGHT-60, 50, 50, ">", function()
            if viewer.mode == STANDARD then
                viewer.mode = FULLSCREEN_NO_BUTTONS
                viewerButton.text = ">"
            else
                viewer.mode = STANDARD
                viewerButton.text = "<"
            end
        end)
        table.insert(buttons, viewerButton)
        AddButton(65, HEIGHT-60, 50, 50, "X", function()
            viewer.close()
        end)
    end
    
    local buttonHeight = 60
    
    newButton = Button(5, 5, 150, buttonHeight, "developer", function() isDeveloper = not isDeveloper end)
    newButton.localizedText = true
    newButton.localizedArray = gameText
    table.insert(buttons, newButton)
            
    newButton = Button(160, 5, 120, buttonHeight, "prevLevel", prevLevel)
    newButton.localizedText = true
    newButton.localizedArray = gameText
    newButton.testFunc = function() return isDeveloper end
    table.insert(buttons, newButton)
    
    newButton = Button(285, 5, 100, buttonHeight, "nextLevel", function() nextLevel(true) end)
    newButton.localizedText = true
    newButton.localizedArray = gameText
    newButton.testFunc = function() return isDeveloper end
    table.insert(buttons, newButton)
        
    newButton = Button(WIDTH-155, 5, 150, buttonHeight, "restart", restart)
    newButton.localizedText = true
    newButton.localizedArray = gameText
    newButton.keyboardHint = "R"
    newButton.keyboardHintFunc = function() return _isJSCodea end
    newButton.keyboardHintSize = 12
    table.insert(buttons, newButton)
    
    newButton = Button(WIDTH-260, 5, 100, buttonHeight, "currentLanguage", changeLanguage)
    newButton.localizedText = true
    newButton.localizedArray = gameText
    table.insert(buttons, newButton)

    newButton = Button(WIDTH-465, 5, 200, buttonHeight, "editor", function()
        editor:open()
    end)
    newButton.localizedText = true
    newButton.localizedArray = gameText
    table.insert(buttons, newButton)

    newButton = Button(WIDTH-630, 5, 160, buttonHeight, "undo", function()
        if #undoBuffer > 0 then
            undo()
        end
    end)
    newButton.selectedFunc = function() return #undoBuffer > 0 end
    newButton.localizedText = true
    newButton.localizedArray = gameText
    newButton.keyboardHint = "backspace"
    newButton.keyboardHintFunc = function() return _isJSCodea end
    newButton.keyboardHintSize = 12
    table.insert(buttons, newButton)
    
    local actionTop = HEIGHT/2 + 20
    local actionWidth = 180
    
    newButton = Button(WIDTH - actionWidth - 5, actionTop-65, actionWidth, 60, "teleport", function() game:teleport() end)
    newButton.localizedText = true
    newButton.localizedArray = gameText
    newButton.testFunc = canTeleport
    newButton.keyboardHint = "space"
    newButton.keyboardHintFunc = function() return _isJSCodea end
    newButton.keyboardHintSize = 12
    table.insert(buttons, newButton)
    
    newButton = Button(WIDTH - actionWidth - 5, actionTop, actionWidth, 60, "explode", function() game:explode(false) end)
    newButton.localizedText = true
    newButton.localizedArray = gameText
    newButton.testFunc = hasExplosive
    newButton.keyboardHint = "E"
    newButton.keyboardHintFunc = function() return _isJSCodea end
    newButton.keyboardHintSize = 12
    table.insert(buttons, newButton)    

    newButton = Button(WIDTH - actionWidth - 5, actionTop-130, actionWidth, 60, "antiExplode", function() game:explode(true) end)
    newButton.localizedText = true
    newButton.localizedArray = gameText
    newButton.testFunc = hasAntiExplosive
    newButton.keyboardHint = "Q"
    newButton.keyboardHintFunc = function() return _isJSCodea end
    newButton.keyboardHintSize = 12
    table.insert(buttons, newButton)
    
    game:createButtons(false, game.inventoryCenter)
    game:createButtons(true, game.groundCenter)
end

function isPortalByte(b)
    return b >= firstPortal and b <= lastPortal
end

function isPortalChar(c)
    local byteValue = string.byte(c)
    return isPortalByte(byteValue)
end

function hasPortal(row, col)
    local value = game:getValue(playerLine, playerCol)
    return isPortalChar(value)
end

function hasPortablePortal(row, col)
    for i = 1, #portablePortals do
        if portablePortals[i].pos.x == row and portablePortals[i].pos.y == col then
            return true
        end
    end
    
    return false
end

function canTeleport()
    if hasPortal(playerLine, playerCol) then
        return true
    end
    
    if hasPortablePortal(playerLine, playerCol) then
        for i = 1, #portablePortals do
            if portablePortals[i].pos.x ~= playerLine or portablePortals[i].pos.y ~= playerCol then
                return true
            end
        end
    end
    
    return false
end

function countInventory()
    local count = 0

    for i = 1, game.maxInventory do
        if game.inventory[i] ~= nil then
            count = count + 1
        end
    end
    
    return count
end

function hasInventory(item)
    for i = 1, game.maxInventory do
        if game.inventory[i] == item then
            return true
        end
    end
    
    return false
end

function hasAnyInventory(items)
    for i = 1, game.maxInventory do
        if table.contains(items, game.inventory[i]) then
            return true
        end
    end
end

function hasExplosive()
    return hasInventory("X")
end

function hasAntiExplosive()
    return hasInventory("I")
end

function hasAction()
    return canTeleport() or hasExplosive() or hasAntiExplosive()
end

function loadEditorLevel()
    createMainButtons(true)
    
    laserPhase = 1
    intro = false
    isEditor = false
    isEditorLevel = true
    music.paused = false
    
    level = table.clone(editor.level)
    levelType = editor.levelType
    levelBlood = editor.levelBlood
    
    loadGlobalLevel()
    
    for k, v in ipairs(editor.startingInventory) do
        game:addInventory(v, true)
    end
    
    game.currentMessageId = -1
end

function isItem(char)
    return table.contains({"N", "S", "E", "W", "B", "X", "M", "I", "V", "H", "p"}, char)
end

function isLaser(char)
    return table.contains({"<", ">", "^", "v"}, char)
end

function isBlocker(char, row, col)
    if isDoor(char) then
        return not isDoorOpened(row, col)
    end
    return isLaser(char) or table.contains({"#", "_", "$", "f"}, char)
end

function canWarpThrough(char, row, col)
    local box = getBox(newRow, newCol)
    if box ~= nil then
        return false
    end

    if isDoor(char) then
        return isDoorOpened(row, col)
    end
    
    if isLaser(char) then
        return false
    end
    
    if table.contains({"#", "$", "o"}, char) then
        return false
    end
    
    return true
end

function isDoor(char)
    return char == "d" or char == "D"
end

function getDoor(row, col)
    for k, v in pairs(doors) do
        if k.x == row and k.y == col then
            return v
        end
    end
    
    return nil
end

function getSwitch(row, col)
    for k, v in pairs(switches) do
        if k.x == row and k.y == col then
            return v
        end
    end
    
    return nil
end

function getBox(row, col)
    for i, v in ipairs(boxes) do
        if v.pos.x == row and v.pos.y == col then
            return v
        end
    end
    
    return nil
end

function isDoorOpened(row, col)
    for k, v in pairs(doors) do
        if k.x == row and k.y == col then
            local anySwitch = false
            local allSwitches = true
            local startOpened = v.startOpened
            local doorType = v.type
            for k, v in pairs(switches) do
                if v.type == doorType then
                    local blood = game:getBlood(k.x, k.y)
                    if blood ~= nil and blood > 0 then
                        anySwitch = true
                    else
                        allSwitches = false
                    end
                end
            end
            if startOpened then
                return not anySwitch
            else
                return allSwitches
            end
        end
    end
    
    return false
end

function isSwitch(char)
    return char == "."
end

function canHaveBlood(row, col)
    local char = game:getValue(row, col)
    return not isBlocker(char, row, col) and 
           not isDoor(char) and
           getBox(row, col) == nil and
           char ~= "~"
end

function blocksBlood(char, row, col)
    for i, v in ipairs(boxes) do
        if v.pos.x == row and v.pos.y == col then
            return true
        end
    end
    if isDoor(char) then
        return not isDoorOpened(row, col)
    end
    return char == "#" or char == "o" or char == "f"
    -- or isLaser(char)
end

function getLevelType(row, col)
    for k, v in pairs(levelType) do
        if k.x == row and k.y == col then
            return v
        end
    end
    
    return 1
end

function getLevelBlood(row, col)
    for k, v in pairs(levelBlood) do
        if k.x == row and k.y == col then
            return v
        end
    end
    
    return 0
end

function addToGround(i, j, c)
    for x = 1, game.maxGround do
        if ground[i][j][x] == nil then
            ground[i][j][x] = c
            return
        end
    end
end

function getLevelCharFromGrid(levelVisuals, row, col, levelHeight, levelWidth)
    local levelCol = col - 1
    local levelRow = levelHeight - (row - 1) + 1
    if levelCol < 1 or
       levelCol > levelWidth or
       levelRow < 1 or
       levelRow > levelHeight then
        return " "
    else
        local levelChar = levelVisuals[levelRow][levelCol]
        if levelChar == "#" or levelChar == "_" or levelChar == "$" or levelChar == "F" then
            return levelChar
        else
            return " "
        end      
    end
end

function applyMapping(levelGrid, levelVisuals, levelHeight, levelWidth)
    if simpleLevelMapping == nil then
        return
    end
    
    for row = 1, levelHeight + 2 do
        levelGrid[row] = {}
        for col = 1, levelWidth + 2 do
            levelGrid[row][col] = {}
            levelGrid[row][col].sprites = {}
        end
    end
    
    local nextTorch = math.random(0, 3)
    
    for row = 1, levelHeight + 2 do
        for col = 1, levelWidth + 2 do
            nextTorch = nextTorch - 1
            local currentKey = ""
            local centerChar = getLevelCharFromGrid(levelVisuals, row, col, levelHeight, levelWidth)
            local effect = mappingEffects[centerChar]
            for newRow = row + 1, row - 1, -1 do
                for newCol = col - 1, col + 1 do
                    local char = getLevelCharFromGrid(levelVisuals, newRow, newCol, levelHeight, levelWidth)
                    if (newRow == row and newCol == col) or table.contains(effect, char) then
                        currentKey = currentKey .. char
                    else
                        currentKey = currentKey .. "*"
                    end
                end
            end
            if simpleLevelMapping[currentKey] ~= nil then
                for i = 1, #simpleLevelMapping[currentKey] do
                    local sprIndex = simpleLevelMapping[currentKey][i]
                    local spr 
                    if sprIndex ~= -1 then
                        spr = sprites[sprIndex]
                    else
                        spr = {}
                    end
                    table.insert(levelGrid[row][col].sprites, spr)
                    if sprIndex == torchWallIndex and nextTorch <= 0 then
                        nextTorch = 2
                        local torch = copyAnim(animTorch)
                        table.insert(levelGrid[row][col].sprites, torch)
                        table.insert(anims, torch)
                    end
                end
            elseif centerChar == "#" then
                table.insert(levelGrid[row][col].sprites, defaultWallSprite)
            end
        end
    end
end

function recordUndo()
    local newUndo = {}
    
    newUndo.playerCol = playerCol
    newUndo.playerLine = playerLine
    
    newUndo.laserPhase = laserPhase
    
    newUndo.inventory = {}
    for i = 1, game.maxInventory do
        newUndo.inventory[i] = game.inventory[i]
    end
    
    newUndo.ground = {}
    for row = 1, levelHeight do
        for col = 1, levelWidth do
            local hasGround = false
            if blood[row][col] <= 0 then
                for i = 1, game.maxGround do                
                    if ground[row][col][i] ~= nil then
                        hasGround = true
                        break
                    end
                end
            end
            if hasGround or blood[row][col] > 0 then
                local groundValue = {}
                groundValue.row = row
                groundValue.col = col
                groundValue.ground = {}
                for i = 1, game.maxGround do                
                    groundValue.ground[i] = ground[row][col][i]
                end
                groundValue.blood = blood[row][col]
                table.insert(newUndo.ground, groundValue)
            end
        end
    end
    
    newUndo.boxes = {}
    for i, v in ipairs(boxes) do
        newUndo.boxes[i] = vec2(v.pos.x, v.pos.y)
    end
    
    if #undoBuffer >= maxUndo then
        table.remove(undoBuffer, 1)
    end
    
    table.insert(undoBuffer, newUndo)
end

function undo()
    local undoData = undoBuffer[#undoBuffer]
    table.remove(undoBuffer, #undoBuffer)
    
    playerCol = undoData.playerCol
    playerLine = undoData.playerLine
    portablePortals = {}
    
    laserPhase = undoData.laserPhase
    
    for i = 1, game.maxInventory do
        game.inventory[i] = undoData.inventory[i]
    end
    
    for row = 1, levelHeight do
        for col = 1, levelWidth do
            for i = 1, game.maxGround do
                ground[row][col][i] = nil
                blood[row][col] = 0
            end
        end
    end
    
    for i, v in ipairs(undoData.ground) do
        for groundIndex = 1, game.maxGround do
            local value = v.ground[groundIndex]
            ground[v.row][v.col][groundIndex] = value
            if value == "p" then
                local portablePortal = {}
                portablePortal.pos = vec2(v.row, v.col)
                table.insert(portablePortals, portablePortal)
            end
        end
        blood[v.row][v.col] = v.blood
    end
    
    for i, v in ipairs(undoData.boxes) do
        boxes[i].pos.x = v.x
        boxes[i].pos.y = v.y
    end
end
    
function loadGlobalLevel()
    blood = {}
    ground = {}
    portals = {}
    portablePortals = {}
    lasers = {}
    doors = {}
    switches = {}
    boxes = {}
    anims = { animRobot, animPortal, animPortablePortal, animCrystal, animFan }
    levelContainsExplosions = false
    levelContainsAntiExplosions = false
    undoBuffer = {}
    
    levelWidth = #level[1]
    levelHeight = #level
    
    levelVisuals = getLevelVisuals(level, levelHeight, levelWidth)
    
    for i, v in ipairs(level) do
        blood[i] = {}
        ground[i] = {}
        for j = 1, #v do
            c = v:sub(j, j)
            blood[i][j] = getLevelBlood(i, j)
            ground[i][j] = { nil, nil, nil }
            local charByte = string.byte(c)
            if isPortalByte(charByte) then
                if portals[charByte] == nil then
                    portals[charByte] = {}
                end
                table.insert(portals[charByte], vec2(i, j))
            elseif c == "p" then
                addToGround(i, j, c)
                removeFromLine(i, c)
                local portablePortal = {}
                portablePortal.pos = vec2(i, j)
                table.insert(portablePortals, portablePortal)
            elseif c == "P" then
                playerLine = i
                playerCol = j
                removeFromLine(i, c)
            elseif isItem(c) then
                addToGround(i, j, c)
                removeFromLine(i, c)
                if c == "X" then
                    levelContainsExplosions = true
                elseif c == "I" then
                    levelContainsAntiExplosions = true
                end
            elseif c == "o" then
                box = {}
                box.pos = vec2(i, j)
                table.insert(boxes, box)
                removeFromLine(i, c)
            elseif isLaser(c) then
                laser = {}
                laser.pos = vec2(i, j)
                if c == "<" then
                    laser.dir = vec2(0, -1)
                elseif c == ">" then
                    laser.dir = vec2(0, 1)
                elseif c == "^" then
                    laser.dir = vec2(-1, 0)
                elseif c == "v" then
                    laser.dir = vec2(1, 0)
                end
                table.insert(lasers, laser)
            elseif isDoor(c) then
                door = {}
                door.type = getLevelType(i, j)
                door.startOpened = (c == "d")
                doors[vec2(i, j)] = door
            elseif isSwitch(c) then
                switch = {}
                switch.type = getLevelType(i, j)
                switches[vec2(i, j)] = switch
            end
        end
    end
        
    
    showLevel = true
    game.inventory = { nil, nil, nil }
    game.showVoltages = true
    blood[playerLine][playerCol] = 1
            
    levelGrid = {}
    
    applyMapping(levelGrid, levelVisuals, levelHeight, levelWidth)
end

function loadLevel(in_levelIndex)
    createMainButtons(false)
    
    intro = (in_levelIndex == 1 and not isEditor)
    laserPhase = 1
    isEditorLevel = false
    levelIndex = in_levelIndex
    localizedStrings = levelStrings[levelIndex]
    level = table.clone(levels[levelIndex])
    levelType = levelTypes[levelIndex]
    levelBlood = levelBloods[levelIndex]
    story = stories[levelIndex]
    fullLevelLimit = nil
        
    loadGlobalLevel()
    
    if not intro then
        if story ~= nil then
            game:displayMessage(1)
        else
            game.currentMessageId = -1
        end
        if levelIndex ~= 1 then
            for k, v in ipairs(inventories[levelIndex]) do
                game:addInventory(v, true)
            end
        end
    end
end

function changeLanguage()
    if localization.language == "en" then
        localization:setLanguage("fr")
    else
        localization:setLanguage("en")
    end
end

function removeFromLine(in_line, in_value)
    level[in_line] = level[in_line]:gsub(in_value, " ")
end

function setShowLevel(in_value)
    showLevel = in_value
    if in_value then
        sound(DATA, "ZgBALy5JQGk5QEBAAAAAALZyQj419rA+QQBAf0BAQEBAQEBA")
    end
end

function introTap()
    if introTime < 6 then
        introTime = 6
    else
        endIntro()
    end
end

function touched(touch)
    if waitToStart then
        startGame()
        return
    end
    
    if intro then
        if touch.state == BEGAN then
            introTap()
        end
        return
    end
        
    local anyButton = false
    for i,v in ipairs(buttons) do
        if v:touched(touch) then
            anyButton = true
        end
    end
    
    if anyButton then
        waitForButtonRelease = true
    end
    
    if isEditor then
        editor:touched(touch, waitForButtonRelease)
    else
        game:touched(touch, waitForButtonRelease)
    end
    
    if not anyButton then
        waitForButtonRelease = false
    end
end

function drawButtons()
    for i,v in ipairs(buttons) do
        v:draw()
    end
end

function endIntro()
    intro = false
    game:displayMessage(1)
end

function handleDpadPressed(direction, x, y)
    if not isEditor and not intro then
        game:swipe(vec2(0, 0), direction, x, y)
    end
end

function checkGameController()
    if gameController == nil then
        initGameController()
        
        if gameController ~= nil then
            gameController.dpad.left.pressedChangedHandler = function(objButton, floatValue, boolPressed)
                if boolPressed then
                    handleDpadPressed(SwipeLeft, -1, 0)
                end
            end
        
            gameController.dpad.right.pressedChangedHandler = function(objButton, floatValue, boolPressed)
                if boolPressed then
                    handleDpadPressed(SwipeRight, 1, 0)
                end
            end
        
            gameController.dpad.up.pressedChangedHandler = function(objButton, floatValue, boolPressed)
                if boolPressed then
                    handleDpadPressed(SwipeUp, 0, 1)
                end
            end
        
            gameController.dpad.down.pressedChangedHandler = function(objButton, floatValue, boolPressed)
                if boolPressed then
                    handleDpadPressed(SwipeDown, 0, -1)
                end
            end
            
            gameController.gamepad.buttonA.pressedChangedHandler = function(objButton, floatValue, boolPressed)
                if boolPressed and not isEditor then
                    if waitToStart then
                        startGame()
                    elseif intro then
                        introTap()
                    else
                        game:tap()
                    end
                end
            end
        end
    end
end

function js_keydown(key)
    if waitToStart then
        if (key == "Enter" or key == "\n") then
            startGame()
        end
        return
    end
    
    if key == "Backspace" then
        undo()
    end
    if key == "ArrowLeft" or key == "a" then
        handleDpadPressed(SwipeLeft, -1, 0)
    end
    if key == "ArrowRight" or key == "d" then
        handleDpadPressed(SwipeRight, 1, 0)
    end
    if key == "ArrowUp" or key == "w" then
        handleDpadPressed(SwipeUp, 0, 1)
    end
    if key == "ArrowDown" or key == "s" then
        handleDpadPressed(SwipeDown, 0, -1)
    end
    if (key == "Enter" or key == "\n") and not isEditor then
        if intro then
            introTap()
        else
            game:tap()
        end
    end
    if (key == "r" or key == "R") and not isEditor then
        restart()
    end
    local keyNumber = tonumber(key)
    if keyNumber ~= nil then
        if keyNumber >= 1 and keyNumber <= 3 then
            onDropButton(keyNumber)
        elseif keyNumber >= 4 and keyNumber <= 6 then
            onTakeButton(keyNumber-3)
        end
    end
    if key == " " then
        game:teleport()
    end
    if key == "e" or key == "W" then
        game:explode(false)
    end
    if key == "q" or key == "Q" then
        game:explode(true)
    end
end

function getShortItemName(char)
    if localization:hasKey(char, shortItemName) then
        return localization:get(char, shortItemName)
    end
    
    return char
end

function countGround(i, j)
    local count = 0
    
    for x = 1, game.maxGround do
        if ground[i][j][x] ~= nil then
            count = count + 1
        end
    end
    
    return count
end

function getGround(i, j, index)
    local count = 0
    
    for x = 1, game.maxGround do
        if ground[i][j][x] ~= nil then
            count = count + 1
            
            if count == index then
                return ground[i][j][x]
            end
        end
    end
    
    return nil
end

function drawCell(x, y, levelCol, levelRow)
    if levelCol >= 1 and levelCol <= levelWidth and
    levelRow >= 1 and levelRow <= levelHeight then
        value = game:getValue(levelRow, levelCol)
        box = getBox(levelRow, levelCol)
        local byteValue = string.byte(value)
        local isPortal = isPortalByte(byteValue)
        if isPortal then
            local portalIndex = byteValue - firstPortal + 1
            local portalColor = portalColors[portalIndex]
            tint(portalColor)
            sprite(animPortal.image, x, y, cellSize, cellSize)
            tint(255)
        end
        
        if value == "*" and (levelCol ~= playerCol or levelRow ~= playerLine) then
            sprite(animCrystal.image, x, y, cellSize, cellSize)
        end
        
        local itemColor = color(255)
        if isLaser(value) then
            local offset = getLevelType(levelRow, levelCol)
            local phase = (((laserPhase - 1) + (offset - 1)) % 4) + 1
            itemColor = laserColors[phase]
            sprite(laserSprites[value].image, x, y, cellSize, cellSize)
            tint(itemColor)
            sprite(laserLightSprites[value].image, x, y, cellSize, cellSize)
            tint(255)
        elseif isDoor(value) then
            local door = getDoor(levelRow, levelCol)
            local doorColor
            local doorOpened = isDoorOpened(levelRow, levelCol)
            if doorOpened == door.startOpened then
                doorColor = doorDarkColors[door.type]
            else
                doorColor = doorColors[door.type]
            end
            if doorOpened then
                sprite(doorOpenedSprite.image, x, y, cellSize, cellSize)
                tint(doorColor)
                sprite(doorLightsOpenedSprite.image, x, y, cellSize, cellSize)
            else
                sprite(doorClosedSprite.image, x, y, cellSize, cellSize)
                tint(doorColor)
                sprite(doorLightsClosedSprite.image, x, y, cellSize, cellSize)
            end            
            tint(255)
        elseif isSwitch(value) then
            local switch = getSwitch(levelRow, levelCol)
            local blood = game:getBlood(levelRow, levelCol)
            
            local switchColor
            if blood ~= nil and blood > 0 then
                switchColor = doorColors[switch.type]
            else
                switchColor = doorDarkColors[switch.type]
            end
                
            sprite(switchSprite.image, x, y, cellSize, cellSize)
            tint(switchColor)
            sprite(switchLights.image, x, y, cellSize, cellSize)
            tint(255)
        end
                                    
        itemCount = countGround(levelRow, levelCol)
        if itemCount > 0 then
            index = math.floor(os.time()) % itemCount + 1
            value = getGround(levelRow, levelCol, index)
            if value == "p" then
                tint(92, 32, 104)
                sprite(animPortablePortal.image, x, y, cellSize, cellSize)
                tint(255)
            else
                sprite(itemSprites[value].image, x, y, cellSize, cellSize)
            end
        end
            
        fill(255)
        
        if levelCol == playerCol and levelRow == playerLine then
            sprite(animRobot.image, x, y, cellSize, cellSize)
        end
            
        if box ~= nil then
            sprite(boxSprite.image, x, y, cellSize, cellSize)
        end
    end
end

function drawFull()
    local width = levelWidth * cellSize
    local height = levelHeight * cellSize
    
    local x = math.floor(WIDTH/2 - width/2 - cellSize)
    local y = math.floor(levelY - height/2 - cellSize)
    
    spriteMode(CORNER)
    for row = 1, levelHeight + 2 do
        for col = 1, levelWidth + 2 do
            local levelCol = col - 1
            local levelRow = levelHeight - (row - 1) + 1
            if fullLevelLimit == nil or 
               isEditorLevel or
               (math.abs(levelRow - playerLine) <= fullLevelLimit and math.abs(levelCol - playerCol) <= fullLevelLimit) then
                local value = game:getValue(levelRow, levelCol)
                local currentX = x + (col - 1) * cellSize
                local currentY = y + (row - 1) * cellSize
                for layer = 1, #levelGrid[row][col].sprites do
                    local spr = levelGrid[row][col].sprites[layer]
                    if spr.image ~= nil then
                        sprite(spr.image, currentX, currentY, cellSize, cellSize)
                    end
                end
                if levelRow >= 1 and levelRow <= levelHeight and levelCol >= 1 and levelCol <= levelWidth then
                    if value == "f" then
                        sprite(animFan.image, currentX, currentY, cellSize, cellSize)
                    end
                    cellBlood = blood[levelRow][levelCol]
                    if cellBlood > 0 then
                        cellBlood = math.min(3, cellBlood)
                        for index = 1, cellBlood do
                            sprite(bloodSprite.image, currentX, currentY, cellSize, cellSize)
                        end
                    end
                    if value == "~" then
                        sprite(waterSprite.image, currentX, currentY, cellSize, cellSize)
                    end
                end
            end
        end
    end
    
    for row = 1, levelHeight do
        for col = 1, levelWidth do
            local levelRow = levelHeight - row + 1
            if fullLevelLimit == nil or isEditorLevel or
                (math.abs(levelRow - playerLine) <= fullLevelLimit and math.abs(col - playerCol) <= fullLevelLimit) then
                drawCell(x + (col) * cellSize, y + (row) * cellSize, col, levelRow)
            end
        end
    end
end

function keyboard(key)
    if not isRuntime() and _isJSCodea then
        js_keydown(key)
    end
end

-- This function gets called once every frame
function draw()
    checkGameController()
    
    background(40, 40, 50)
    
    strokeWidth(3)
    
    fill(255, 255, 255, 255)
    
    if waitToStart then
        font("SourceSansPro-Bold")
        fontSize(64)
        textMode(CENTER)
        text(localization:get("tapToStart", gameText), WIDTH/2, HEIGHT/2)
        return
    end
    
    
    if isEditor then
        editor:draw()
        return
    end
        
    if intro then
        local alpha = 255
        if introTime < 3 then alpha = (introTime / 3.0) end
        if introTime > 6 then
            alpha = (9 - introTime) / 3.0
            if alpha <= 0 then
                endIntro()
            end
        end
        fill(255, 255, 255, alpha * 255)
        font("Copperplate")
        fontSize(96)
        textMode(CENTER)
        textAlign(CENTER)
        
        pushMatrix()
        translate(WIDTH/2,HEIGHT/2)
        scale(0.7 + math.min(0.3, (introTime / 9.0) * 0.3))
        text(localization:get("title", gameText))

        translate(0, -100)
        font("AcademyEngravedLetPlain")
        fontSize(40)
        text("Introduction")
        introTime = introTime + 0.01667
        popMatrix()
        return
    end
    
    font("SourceSansPro-Bold")
    
    fontSize(charSize)
    
    textMode(CENTER)
    textAlign(CENTER)
    
    if showLevel then
        if anims ~= nil then
            updateAnims(anims)
        end
        
        drawFull()
    end
    
    if levelIndex > 0 and levelNames[levelIndex] ~= nil then
        fill(255)
        textMode(CORNER)
        local levelName = localization:get(levelNames[levelIndex], localizedLevelNames) 
        local levelString = levelName .. " (" .. levelIndex .. " / " .. #levels .. ")"
        local textWidth = textSize(levelString)
        text(levelString, WIDTH - textWidth - 5, 65)
    end
    
    game:draw()
    
    if gameController ~= nil then
        textMode(CENTER)
        text("Controller connected. Battery " .. gameController.controller.battery.batteryLevel * 100 .. " %", WIDTH / 2, 15)
    end
    
    if _isJSCodea then
        textMode(CORNER)
        fill(100)
        local jscodea = localization:get("jscodea", gameText)
        text(jscodea, 5, 65)
    end
end

