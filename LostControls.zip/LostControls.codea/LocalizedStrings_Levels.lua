levelStrings[2] = {}
levelStrings[2]["en"] = {}
levelStrings[2]["fr"] = {}
levelStrings[2]["en"]["01"] = "Hum, why can't I see a thing?"
levelStrings[2]["fr"]["01"] = "Hmm, pourquoi je ne peux rien voir?"
levelStrings[2]["en"]["02"] = "-= Oh, sorry about that. There you go! =-"
levelStrings[2]["fr"]["02"] = "-= Oh, désolé pour ça! Voilà! =-"
levelStrings[2]["en"]["03"] = "You're kidding me, right?"
levelStrings[2]["fr"]["03"] = "C'est une blague ou quoi?!"
levelStrings[2]["en"]["04"] = "-= Better? =-"
levelStrings[2]["fr"]["04"] = "-= C'est mieux? =-"
levelStrings[2]["en"]["05"] = "Can't you do better than this?"
levelStrings[2]["fr"]["05"] = "Tu ne peux pas faire mieux que ça?"
levelStrings[2]["en"]["06"] = "-= Cranking up to 100%! =-"
levelStrings[2]["fr"]["06"] = "-= Je monte à 100%! =-"
levelStrings[2]["en"]["07"] = "😧 ..."
levelStrings[2]["fr"]["07"] = "😧 ..."

levelStrings[7] = {}
levelStrings[7]["en"] = {}
levelStrings[7]["fr"] = {}
levelStrings[7]["en"]["01"] = "There's no way I can get to the exit!"
levelStrings[7]["fr"]["01"] = "Je ne me rendrai jamais à la sortie!"
levelStrings[7]["en"]["02"] = "-= Give it a try, you'll see! =-"
levelStrings[7]["fr"]["02"] = "-= Essaie-le, tu verras! "
levelStrings[7]["en"]["03"] = "What just happened? Why did I lose so much blood?"
levelStrings[7]["fr"]["03"] = "Qu'est-ce que... Pourquoi j'ai perdu autant de sang?"
levelStrings[7]["en"]["04"] = "-= You jumped over that hole at lightning speed! =-"
levelStrings[7]["fr"]["04"] = "-= Tu as sauté par-dessus ce trou à la vitesse de l'éclair! =-"
levelStrings[7]["en"]["05"] = "I guess throwing blood can be useful with that module..."
levelStrings[7]["fr"]["05"] = "J'imagine que lancer du sang peut m'être utile avec ce module..."

--[[
levelStrings[3] = {}
levelStrings[3]["en"] = {}
levelStrings[3]["fr"] = {}
levelStrings[3]["en"]["01"] = "-= LEVEL 2 =-"
levelStrings[3]["fr"]["01"] = "-= NIVEAU 2 =-"
levelStrings[3]["en"]["02"] = "-= Back & Forth =-"
levelStrings[3]["fr"]["02"] = "-= Aller retour =-"

levelStrings[4] = {}
levelStrings[4]["en"] = {}
levelStrings[4]["fr"] = {}
levelStrings[4]["en"]["01"] = "-= LEVEL 3 =-"
levelStrings[4]["fr"]["01"] = "-= NIVEAU 3 =-"
levelStrings[4]["en"]["02"] = "-= Bloody Explosion =-"
levelStrings[4]["fr"]["02"] = "-= Explosion sanglante =-"

levelStrings[5] = {}
levelStrings[5]["en"] = {}
levelStrings[5]["fr"] = {}
levelStrings[5]["en"]["01"] = "-= LEVEL 4 =-"
levelStrings[5]["fr"]["01"] = "-= NIVEAU 4 =-"
levelStrings[5]["en"]["02"] = "-= Water =-"
levelStrings[5]["fr"]["02"] = "-= L'eau =-"

levelStrings[6] = {}
levelStrings[6]["en"] = {}
levelStrings[6]["fr"] = {}
levelStrings[6]["en"]["01"] = "-= LEVEL 5 =-"
levelStrings[6]["fr"]["01"] = "-= NIVEAU 5 =-"
levelStrings[6]["en"]["02"] = "-= ... =-"
levelStrings[6]["fr"]["02"] = "-= ... =-"

levelStrings[7] = {}
levelStrings[7]["en"] = {}
levelStrings[7]["fr"] = {}
levelStrings[7]["en"]["01"] = "-= LEVEL 6 =-"
levelStrings[7]["fr"]["01"] = "-= NIVEAU 6 =-"
levelStrings[7]["en"]["02"] = "-= ... =-"
levelStrings[7]["fr"]["02"] = "-= ... =-"

levelStrings[8] = {}
levelStrings[8]["en"] = {}
levelStrings[8]["fr"] = {}
levelStrings[8]["en"]["01"] = "-= LEVEL 7 =-"
levelStrings[8]["fr"]["01"] = "-= NIVEAU 7 =-"
levelStrings[8]["en"]["02"] = "-= ... =-"
levelStrings[8]["fr"]["02"] = "-= ... =-"

levelStrings[9] = {}
levelStrings[9]["en"] = {}
levelStrings[9]["fr"] = {}
levelStrings[9]["en"]["01"] = "-= LEVEL 8 =-"
levelStrings[9]["fr"]["01"] = "-= NIVEAU 8 =-"
levelStrings[9]["en"]["02"] = "-= ... =-"
levelStrings[9]["fr"]["02"] = "-= ... =-"
--]]
