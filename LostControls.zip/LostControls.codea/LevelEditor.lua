LevelEditor = class()

function LevelEditor:init()
    self.mandatoryCharacters = "P*"
    self.moduleCharacters = "NSEWBMVH"
    self.inventoryCharacters = self.moduleCharacters .. "XIp"
    self.singleCharacters = self.mandatoryCharacters .. self.moduleCharacters
    self.multiCharacters = "# _~$XIp12345<>^vdD.of"
    self.typeCharacters = {
        ["<"] = 4,
        [">"] = 4,
        ["^"] = 4,
        ["v"] = 4,
        ["d"] = 3,
        ["D"] = 3,
        ["."] = 3
    }
    self.selectedCharacter = "P"
    self.startingInventory = {}
    self.gridSize = 20
    self.grid = {}
    self.gridType = {}
    self.gridBlood = {}
    self.lastTouch = vec2(0, 0)
    self.bloodLevel = 0
    self.levelVisuals = {}
    self.showPreview = false
    self:clear()
end

function LevelEditor:addCharButtons(x, y, str)
    for char in str:gmatch(".") do
        local button = AddButton(x, y, 40, 40, char, function() 
            self.selectedCharacter = char
        end)
        button.selectedFunc = function()
            return self.selectedCharacter == char
        end
        x = x + 42
    end
    
    return x
end

function LevelEditor:clear()
    self.levelName = "LevelName"
    self.hasPlayer = false
    self.hasCrystal = false
    self.validVisuals = false
    
    for row = 1, self.gridSize do
        self.grid[row] = {}
        self.gridType[row] = {}
        self.gridBlood[row] = {}
        for col = 1, self.gridSize do
            self.grid[row][col] = " "
            self.gridType[row][col] = 1
            self.gridBlood[row][col] = 0
        end
    end
    
    self:updatePreview()
end

function LevelEditor:updatePreview()    
    self.levelGrid = {}
    self.levelVisuals = {}
    
    self:generate()
    
    self.levelHeight = #self.level
    
    if self.levelHeight == 0 then
        self.levelWidth = 0
        return
    end
    
    self.levelWidth = #self.level[1]
    
    self.levelVisuals, self.validVisuals = getLevelVisuals(self.level, self.levelHeight, self.levelWidth)
    
    applyMapping(self.levelGrid, self.levelVisuals, self.levelHeight, self.levelWidth)
end

function LevelEditor:generate()
    self.min_x = self.gridSize
    self.min_y = self.gridSize
    self.max_x = 1
    self.max_y = 1
    
    for row = 1, self.gridSize do
        for col = 1, self.gridSize do
            if self.grid[row][col] ~= " " or self.gridBlood[row][col] > 0 then
                self.min_x = math.min(col, self.min_x)
                self.min_y = math.min(row, self.min_y)
                self.max_x = math.max(col, self.max_x)
                self.max_y = math.max(row, self.max_y)
            end
        end
    end
    
    self.hasPlayer = false
    self.hasCrystal = false
    self.level = {}
    self.levelType = {}
    self.levelBlood = {}
    for gridRow = self.min_y, self.max_y do
        local row = gridRow - self.min_y + 1
        self.level[row] = ""
        for gridCol = self.min_x, self.max_x do
            if self.grid[gridRow][gridCol] == "P" then
                self.hasPlayer = true
            end
            if self.grid[gridRow][gridCol] == "*" then
                self.hasCrystal = true
            end
            
            self.level[row] = self.level[row] .. self.grid[gridRow][gridCol]

            local col = gridCol - self.min_x + 1
            
            if self.gridType[gridRow][gridCol] ~= 1 then
                self.levelType[vec2(row, col)] = self.gridType[gridRow][gridCol]
            end
            
            if self.gridBlood[gridRow][gridCol] > 0 then
                self.levelBlood[vec2(row, col)] = self.gridBlood[gridRow][gridCol]
            end
        end
    end    
end

function LevelEditor:offset(x, y)
    local gridCopy = {}
    local gridTypeCopy = {}
    local gridBloodCopy = {}
    
    for row = 1, self.gridSize do
        gridCopy[row] = {}
        gridTypeCopy[row] = {}
        gridBloodCopy[row] = {}
        for col = 1, self.gridSize do
            local sourceRow = row - y
            local sourceCol = col - x
            if sourceRow >= 1 and sourceRow <= self.gridSize and
               sourceCol >= 1 and sourceCol <= self.gridSize then
                gridCopy[row][col] = self.grid[sourceRow][sourceCol]
                gridTypeCopy[row][col] = self.gridType[sourceRow][sourceCol]
                gridBloodCopy[row][col] = self.gridBlood[sourceRow][sourceCol]
            else
                gridCopy[row][col] = " "
                gridTypeCopy[row][col] = 1
                gridBloodCopy[row][col] = 0
            end     
        end
    end
        
    self.grid = gridCopy
    self.gridType = gridTypeCopy
    self.gridBlood = gridBloodCopy
end

function LevelEditor:test()
    self:generate()
    
    loadEditorLevel()
end

function LevelEditor:generateText()
    self:generate()
    
    local result = 'createLevel(\n\t"'
    
    result = result .. self.levelName
    
    result = result .. '",\n\t{'
    
    for i, v in ipairs(self.startingInventory) do
        if i > 1 then
            result = result .. ", "
        end
        result = result .. '"' .. v .. '"'
    end
    
    result = result .. "}, {\n"
    
    for i, v in ipairs(self.level) do
        result = result .. '"' .. v .. '",\n'
    end
    
    result = result .. "}"
    
    local hasTypes = false
    local types = {}
    for k, v in pairs(self.levelType) do
        if v > 1 then
            types[vec2(k.x, k.y)] = v
            hasTypes = true
        end
    end
    
    if hasTypes then
        result = result .. ", {\n"
        
        for k, v in pairs(types) do
            result = result .. '[vec2(' .. k.x .. ', ' .. k.y .. ')]'
            result = result .. ' = ' .. v .. ',\n'
        end
        
        result = result .. "}"
    else
        result = result .. ", {}"
    end
    
    local hasBlood = false
    local blood = {}
    for k, v in pairs(self.levelBlood) do
        if v > 0 then
            blood[vec2(k.x, k.y)] = v
            hasBlood = true
        end
    end
    
    if hasBlood then
        result = result .. ", {\n"
        
        for k, v in pairs(blood) do
            result = result .. '[vec2(' .. k.x .. ', ' .. k.y .. ')]'
            result = result .. ' = ' .. v .. ',\n'
        end
        
        result = result .. "}"
    else
        result = result .. ", {}"
    end
    
    result = result .. ")\n"
    
    return result    
end

function LevelEditor:toClipboard()
    pasteboard.text = self:generateText()
end

function LevelEditor:open()
    music.paused = true
    
    buttons = {}
    isEditor = true
    
    if not isEditorLevel then
        self:clear()
        self.levelName = levelNames[levelIndex]
        local level = levels[levelIndex]
        local levelType = levelTypes[levelIndex]
        local levelBlood = levelBloods[levelIndex]
        local height = #level
        local width = #level[1]
        for row, l in ipairs(level) do
            for col = 1, width do
                local x = math.floor(self.gridSize / 2 - width / 2) + col
                local y = math.floor(self.gridSize / 2 - height / 2) + row
                local char = l:sub(col, col)
                self.grid[y][x] = char
                self.gridType[y][x] = 1
            end
        end
        
        for k, v in pairs(levelType) do
            local gridCol = math.floor(self.gridSize / 2 - width / 2) + k.y
            local gridRow = math.floor(self.gridSize / 2 - height / 2) + k.x
            self.gridType[gridRow][gridCol] = v
        end
        
        for k, v in pairs(levelBlood) do
            local gridCol = math.floor(self.gridSize / 2 - width / 2) + k.y
            local gridRow = math.floor(self.gridSize / 2 - height / 2) + k.x
            self.gridBlood[gridRow][gridCol] = v
        end
        
        self.startingInventory = {}
        for k, v in ipairs(inventories[levelIndex]) do
            table.insert(self.startingInventory, v)
        end
    end
        
    AddButton(10, HEIGHT-60, 50, 50, "X", function()
        loadLevel(levelIndex)
        isEditor = false
        music.paused = false
    end)
    
    local testButton = AddButton(WIDTH-190, HEIGHT-60, 180, 50, localization:get("test", gameText), function()
        if editor:isValid() then
            self:test()
        end
    end)
    testButton.selectedFunc = function() return editor:isValid() end
    
    AddButton(WIDTH-190, HEIGHT-120, 180, 50, localization:get("clear", gameText), function()
        self:clear()
    end)
    
    AddButton(WIDTH-190, HEIGHT-180, 180, 50, localization:get("clipboard", gameText), function()
        self:toClipboard()
    end)
    
    AddButton(WIDTH-190, HEIGHT-240, 50, 50, "<", function()
        self:offset(-1, 0)
    end)
    
    AddButton(WIDTH-130, HEIGHT-240, 50, 50, ">", function()
        self:offset(1, 0)
    end)
    
    AddButton(WIDTH-190, HEIGHT-300, 50, 50, "^", function()
        self:offset(0, -1)
    end)
    
    AddButton(WIDTH-130, HEIGHT-300, 50, 50, "v", function()
        self:offset(0, 1)
    end)
    
    local button = AddButton(WIDTH-190, HEIGHT-360, 35, 35, "", function()
        self.bloodLevel = 0
    end)
    button.fillColor = color(0)
    button.selectionBorderOnly = true
    button.selectionTransparency = 1.0
    button.selectedFunc = function() return self.bloodLevel == 0 end
    
    button = AddButton(WIDTH-150, HEIGHT-360, 35, 35, "", function()
        self.bloodLevel = 1
    end)
    button.fillColor = color((1.0 / 3.0) * 255, 0, 0)
    button.selectionBorderOnly = true
    button.selectionTransparency = 1.0
    button.selectedFunc = function() return self.bloodLevel == 1 end
    
    button = AddButton(WIDTH-110, HEIGHT-360, 35, 35, "", function()
        self.bloodLevel = 2
    end)
    button.fillColor = color((2.0 / 3.0) * 255, 0, 0)
    button.selectionBorderOnly = true
    button.selectionTransparency = 1.0
    button.selectedFunc = function() return self.bloodLevel == 2 end
    
    button = AddButton(WIDTH-70, HEIGHT-360, 35, 35, "", function()
        self.bloodLevel = 3
    end)
    button.fillColor = color((3.0 / 3.0) * 255, 0, 0)
    button.selectionBorderOnly = true
    button.selectionTransparency = 1.0
    button.selectedFunc = function() return self.bloodLevel == 3 end
    
    button = AddButton(WIDTH-190, HEIGHT-420, 180, 50, "prevLevel", prevLevel)
    button.localizedText = true
    button.localizedArray = gameText
        
    button = AddButton(WIDTH-190, HEIGHT-480, 180, 50, "nextLevel", function() nextLevel(true) end)
    button.localizedText = true
    button.localizedArray = gameText
    
    if _isJSCodea then
        button = AddSpriteButton(WIDTH-135, HEIGHT-600, 64, 64, asset.share_2, shareLevel)
        button.localizedText = true
        button.localizedArray = gameText
        button.text = "share"
        button.textOffset = vec2(0, -50)
    end
    
    button = AddButton(WIDTH-190, HEIGHT-700, 180, 50, "preview", function()
        self.showPreview = not self.showPreview 
        if self.showPreview then
            self:updatePreview()
        end
    end)
    button.localizedText = true
    button.localizedArray = gameText
    button.selectedFunc = function() return self.showPreview end
    
    local x = 80
    x = self:addCharButtons(x, 10, self.multiCharacters)
    
    x = 80
    x = self:addCharButtons(x, 70, self.singleCharacters)
    
    local y = HEIGHT - 150
    for char in self.inventoryCharacters:gmatch(".") do
        local button = AddButton(10, y, 50, 50, char, function()
            if table.contains(self.startingInventory, char) then
                table.removeItem(self.startingInventory, char)
            else
                table.insert(self.startingInventory, char)
            end
        end)
        button.selectedFunc = function()
            return table.contains(self.startingInventory, char)
        end
        y = y - 60
    end
    
    self:updatePreview()
end

function shareLevel()
    if context ~= nil then
        local result = editor:generateText()
        context:shareLevel(result)
    end
end

function LevelEditor:isValid()
    return self.validVisuals and self.hasPlayer and self.hasCrystal
end

function LevelEditor:placeCharacter(row, col)
    if self.selectedCharacter ~= "$" and
       self.selectedCharacter ~= "^" and
       self.selectedCharacter ~= "." and
       string.find(self.singleCharacters, self.selectedCharacter) then
        for clearRow = 1, self.gridSize do
            for clearCol = 1, self.gridSize do
                if self.grid[clearRow][clearCol] == self.selectedCharacter then
                    self.grid[clearRow][clearCol] = " "
                    self.gridType[clearRow][clearCol] = 1
                end
            end
        end
    end
    
    self.gridBlood[row][col] = self.bloodLevel
    
    if self.grid[row][col] ~= self.selectedCharacter then
        self.grid[row][col] = self.selectedCharacter
        self.gridType[row][col] = 1
    elseif self.lastTouch ~= vec2(row, col) then
        local types = self.typeCharacters[self.selectedCharacter]
        if types ~= nil then
            self.gridType[row][col] = (self.gridType[row][col] % types) + 1
        end
    end
    
    self:updatePreview()
end
    
function LevelEditor:draw()
    drawButtons()
    
    pushStyle()
    
    textMode(CORNER)
    text(localization:get("startingInventory", gameText), 10, HEIGHT - 100)
    
    textMode(CENTER)
    text(self.levelName, WIDTH-100, HEIGHT-500)
    
    rectMode(CORNER)
    
    noFill()
    stroke(255)
    strokeWidth(1)
    spriteMode(CORNER)
    
    local cellSize = (HEIGHT - 200) / self.gridSize
    local cornerOffset = (self.gridSize / 2) * cellSize
    local x = (WIDTH / 2) - cornerOffset
    local y = (HEIGHT / 2) + cornerOffset + 30
    local bottom = (HEIGHT / 2) - cornerOffset + 30
    for row = 1, self.gridSize + 2 do
        for col = 1, self.gridSize + 2 do
            if self.showPreview and
               row >= self.min_y - 1 and row <= self.max_y + 1 and
               col >= self.min_x - 1 and col <= self.max_x + 1 then
                local gridRow = (self.levelHeight + 2) - (row - self.min_y + 2) + 1
                local gridCol = col - self.min_x + 2
                for layer = 1, #self.levelGrid[gridRow][gridCol].sprites do
                    local spr = self.levelGrid[gridRow][gridCol].sprites[layer]
                    if spr ~= nil and spr.image ~= nil then
                        local rx = x + (col - 1) * cellSize
                        local ry = y - (row - 1) * cellSize
                        sprite(spr.image, rx, ry, cellSize, cellSize)
                    end
                end
            end
            local levelRow = row - 2
            local levelCol = col - 2
            if levelRow >= 1 and levelRow <= self.gridSize and
               levelCol >= 1 and levelCol <= self.gridSize then
                local rx = x + (levelCol - 1) * cellSize
                local ry = y - (levelRow - 1) * cellSize
                noFill()
                rect(rx, ry, cellSize + 1, cellSize + 1)
                
                local value = self.grid[levelRow][levelCol]
                local cellBlood = self.gridBlood[levelRow][levelCol]
                
                if cellBlood > 0 then
                    pushStyle()
                    fill((cellBlood / 3.0) * 255, 0, 0)
                    strokeWidth(0)
                    rectMode(CORNER)
                    rect(rx, ry, cellSize + 1, cellSize + 1)
                    popStyle()
                end
                
                if isLaser(value) then
                    fill(laserColors[self.gridType[levelRow][levelCol]])
                elseif isDoor(value) then
                    fill(doorColors[self.gridType[levelRow][levelCol]])
                elseif isSwitch(value) then
                    fill(doorColors[self.gridType[levelRow][levelCol]])
                else
                    fill(255)
                end
                
                text(value, rx + 0.5 * cellSize, ry + 0.5 * cellSize)
                
                local mx = rx + cellSize
                local my = ry + cellSize
                
                if  CurrentTouch.state ~= ENDED and
                    CurrentTouch.pos.x >= rx and CurrentTouch.pos.x < mx and
                    CurrentTouch.pos.y >= ry and CurrentTouch.pos.y < my then
                    self:placeCharacter(levelRow, levelCol)
                    self.lastTouch = vec2(levelRow, levelCol)
                elseif CurrentTouch.state == ENDED then
                    self.lastTouch = vec2(0, 0)
                end
            end
        end
    end
    
    popStyle()
end

function LevelEditor:touched(touch, anyButton)
    
end
