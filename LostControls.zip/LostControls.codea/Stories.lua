stories[2] = {}

stories[2][1] = {
    ["text"] = "01", 
    ["next"] = 2,
    ["preFunc"] = setShowLevel,
    ["preParam"] = false
}

stories[2][2] = { 
    ["text"] = "02",
    ["next"] = 3,
    ["preFunc"] = function()
        fullLevelLimit = 0
        setShowLevel(true)
    end
}

stories[2][3] = { 
    ["text"] = "03",
    ["next"] = 4
}

stories[2][4] = { 
    ["text"] = "04",
    ["next"] = 5,
    ["preFunc"] = function()
        fullLevelLimit = 2
    end
}

stories[2][5] = { 
    ["text"] = "05",
    ["next"] = 6
}

stories[2][6] = { 
    ["text"] = "06",
    ["next"] = 7,
    ["preFunc"] = function()
        fullLevelLimit = nil
    end
}

stories[2][7] = { 
    ["text"] = "07"
}

stories[7] = {}

stories[7][1] = {
    ["text"] = "01",
    ["next"] = 2,
    ["preFunc"] = function() firstWarpDone = false end
}

stories[7][2] = {
    ["text"] = "02"
}

stories[7][3] = {
    ["text"] = "03",
    ["next"] = 4,
    ["preFunc"] = function() firstWarpDone = true end
}

stories[7][4] = {
    ["text"] = "04",
    ["next"] = 5
}

stories[7][5] = {
    ["text"] = "05"
}
