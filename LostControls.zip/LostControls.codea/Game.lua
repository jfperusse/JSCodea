Game = class()

function Game:init()
    itemsPerSwipe = {}
    itemsPerSwipe[SwipeUp] = {"N", "V"}
    itemsPerSwipe[SwipeDown] = {"S", "V"}
    itemsPerSwipe[SwipeLeft] = {"W", "H"}
    itemsPerSwipe[SwipeRight] = {"E", "H"}
    
    self.swipeHandler = SwipeHelper(self)
    self.swipeHandler.repeatSwipe = true
    self.swipeHandler.repeatDelay = 0.2
    self.currentMessageId = -1
    self.currentMessage = nil
    self.maxVoltage = 3
    self.inventory = { nil, nil, nil }
    self.showVoltages = true
    self.time = 0.0
    self.ignoreButtons = false
    self.voltage = 0
    
    self.inventoryCenter = WIDTH / 4
    self.groundCenter = 3 * WIDTH / 4
    self.itemWidth = 90
    self.itemHeight = 70
    self.itemMargin = 10
    self.itemY = HEIGHT - 90
    
    self.maxInventory = 3
    self.maxGround = 3
end

function Game:touched(touch, anyButton)
    self.ignoreButtons = anyButton
    self.swipeHandler:touched(touch)
    self.ignoreButtons = false
end

function Game:getValue(inRow, inCol)
    if level[inRow] ~= nil then
        return string.sub(level[inRow], inCol, inCol)
    end
    
    return nil
end

function Game:getBlood(inRow, inCol)
    if blood[inRow] ~= nil then
        if blood[inRow][inCol] ~= nil then
            return blood[inRow][inCol]
        end
    end
    
    return nil
end

function Game:isValidMove(inSrcCol, inSrcRow, inDirectionType, inColDiff, inRowDiff)
    local newCol = inSrcCol + inColDiff
    local newRow = inSrcRow - inRowDiff
    local value = self:getValue(newRow, newCol)
    local newBlood = self:getBlood(newRow, newCol)
    
    local warpCol = inSrcCol + 2 * inColDiff
    local warpRow = inSrcRow - 2 * inRowDiff
    local warpValue = self:getValue(warpRow, warpCol)
    local warpBlood = self:getBlood(warpRow, warpCol)
    
    local warpBox = getBox(warpRow, warpCol)
    local isWarpBox = warpBox ~= nil
    
    local canWarp = hasInventory("B") and
                    canWarpThrough(value, newRow, newCol) and
                    not isBlocker(warpValue, warpRow, warpCol) and 
                    warpBlood ~= nil and 
                    warpBlood > 0 and
                    not isWarpBox
    
    local box = getBox(newRow, newCol)
    local isBox = box ~= nil
    
    local canPush = isBox and not isBlocker(warpValue) and countGround(warpRow, warpCol) == 0 and not isWarpBox
    
    if isBlocker(value, newRow, newCol) then
        return false, canWarp, false
    end
        
    canMove = hasAnyInventory(itemsPerSwipe[inDirectionType]) or hasInventory("M")
        
    if value == "~" then
        return canMove, canWarp
    end
    
    if not canMove and newBlood > 0 and hasInventory("B") then
        canMove = true
    end
    
    if isBox then
        return false, canWarp, (canPush and canMove)
    end
    
    return canMove, canWarp, canPush
end

function Game:importantMessage()
    return self.currentMessageId ~= -1 and 
        (self.currentMessage["next"] ~= nil or self.currentMessage["postFunc"] ~= nil)
end

function Game:lastMessage()
    return self.currentMessageId ~= -1 and self.currentMessage["next"] == self.currentMessageId
end

function Game:processMessage()
    if self.currentMessageId ~= -1 then
        if self:importantMessage() then
            return true
        end
        self:nextMessage()
    end
    
    return false
end

function Game:addBlood(inRow, inCol, value)
    if not canHaveBlood(inRow, inCol) then
        return
    end
    
    local bloodValue = 1
    
    if value ~= nil then
        bloodValue = value
    end
    
    blood[inRow][inCol] = math.min(3, blood[inRow][inCol] + bloodValue)
end

function Game:removeBlood(inRow, inCol, value)
    local bloodValue = 1
    
    if value ~= nil then
        bloodValue = value
    end
    
    self.prevBlood = blood[inRow][inCol]
    
    blood[inRow][inCol] = math.max(0, blood[inRow][inCol] - bloodValue)
end

function Game:removeAllBlood(inRow, inCol)
    blood[inRow][inCol] = 0
end

function Game:moveTo(inRow, inCol, isMove, isWarp, warpDir)
    recordUndo()
    
    playerCol = inCol
    playerLine = inRow
    
    local value = self:getValue(inRow, inCol)
    
    if (isMove and value ~= "~") or not isWarp then
        self:addBlood(playerLine, playerCol)
    elseif isWarp then
        local bloodPos = vec2(inRow, inCol)
        for i = 3, 1, -1 do
            value = self:getValue(bloodPos.x, bloodPos.y)
            if value ~= nil then
                if blocksBlood(value, bloodPos.x, bloodPos.y) then
                    break
                end
                if not isBlocker(value, bloodPos.x, bloodPos.y) then
                    self:addBlood(bloodPos.x, bloodPos.y, i)
                end
                bloodPos = bloodPos + warpDir
            end
        end
    end
        
    itemCount = countGround(playerLine, playerCol)
    if itemCount > 0 then
        if not self.showVoltages then
            item = ground[playerLine][playerCol][1]
            if self:addInventory(item) then
                ground[playerLine][playerCol][1] = nil
            end
        end
    end
    
    laserPhase = laserPhase + 1
    
    local didShoot = false
    
    for k, v in ipairs(lasers) do
        local pos = vec2(v.pos.x, v.pos.y)
        local offset = getLevelType(pos.x, pos.y)
        local phase = (((laserPhase - 1) + (offset - 1)) % 4) + 1
        if phase == 4 then
            if not didShoot then
                sound(DATA, "ZgBAdBktQGwgQEBAAAAAAG69TD5ozmo+QABAf0BCQEI+QEBA")
                didShoot = true
            end
            local dir = v.dir
            local hit = false
            local bloodLeft = 6
            pos = pos + dir
            while pos.x > 0 and pos.x <= levelHeight and
            pos.y > 0 and pos.y <= levelWidth do
                value = self:getValue(pos.x, pos.y)
                if blocksBlood(value, pos.x, pos.y) then
                    break
                end
                if pos.x == playerLine and pos.y == playerCol then
                    hit = true
                end
                if hit then
                    if canHaveBlood(pos.x, pos.y) then
                        local bloodValue = math.floor((bloodLeft + 1) / 2)
                        self:addBlood(pos.x, pos.y, bloodValue)
                    end
                    bloodLeft = bloodLeft - 1
                    if bloodLeft == 0 then
                        break
                    end
                end
                pos = pos + dir               
            end
        end
    end

    if laserPhase > 4 then
        laserPhase = 1
    end
end
    
function Game:swipe(inFromPosition, inDirectionType, inColDiff, inRowDiff)
    if self.ignoreButtons then return end
    
    if self:processMessage() then
        return
    end

    self.prevRow = playerLine
    self.prevCol = playerCol
    
    newCol = playerCol + inColDiff
    newRow = playerLine - inRowDiff
    value = self:getValue(newRow, newCol)
    
    warpCol = playerCol + 2 * inColDiff
    warpRow = playerLine - 2 * inRowDiff
    warpValue = self:getValue(warpRow, warpCol)
    
    canMove, canWarp, canPush = self:isValidMove(playerCol, playerLine, inDirectionType, inColDiff, inRowDiff)

    if not canMove and not canWarp and not canPush then
        if not isBlocker(value, newRow, newCol) then
            self:displayMessage(1, nil, true)
        end
        return
    end
    
    if canMove then
        self:doMove(newRow, newCol)
    elseif canPush then
        self:doMove(newRow, newCol)
        local box = getBox(newRow, newCol)
        box.pos.x = warpRow
        box.pos.y = warpCol
    elseif canWarp then
        local warpDir = vec2(-inRowDiff, inColDiff)
        self:moveTo(warpRow, warpCol, false, true, warpDir)
        sound(asset.downloaded.Game_Sounds_One.Land_Hay)
        if levelIndex == 7 and firstWarpDone == false then
            self:displayMessage(3)
        end
    end
    
    if (canMove and value == "*") or
    (not canMove and canWarp and warpValue == "*") then
        if isEditorLevel then
            restart()
        else
            if context ~= nil then
                context:levelEnd(levelIndex, localization:get(levelNames[levelIndex], localizedLevelNames, "en"))
            end
            self:displayMessage(7, nil, true)
        end
    end
end

function Game:doMove(newRow, newCol)
    self:moveTo(newRow, newCol, true, false)
    if math.random() > 0.5 then
        sound(asset.downloaded.Game_Sounds_One.Whoosh_1)
    else
        sound(asset.downloaded.Game_Sounds_One.Whoosh_2)
    end    
end

function Game:explode(isAntiExplosion)
    if isAntiExplosion then
        if not hasAntiExplosive() then return end
        recordUndo()
        sound(DATA, "ZgNADgBRQEBAQEBA6HYtPaSm/D3EHfg+XABAf0BAQFowQHZT")
        destroyItem("I")
    else
        if not hasExplosive() then return end
        recordUndo()
        sound(asset.downloaded.Game_Sounds_One.Land)
        destroyItem("X")
    end
    
    self:processMessage()
    
    for dCol = -2, 2 do
        for dRow = -2, 2 do
            local dColAbs = math.abs(dCol)
            local dRowAbs = math.abs(dRow)
            local count = math.max(0, 3 - (dColAbs + dRowAbs))
            local col = playerCol + dCol
            local row = playerLine + dRow
            if row >= 1 and row <= #level then
                local value = game:getValue(row, col)
                local otherValue = ""
                local otherRow = 0
                local otherCol = 0
                if (dColAbs == 0 and dRowAbs == 2) or
                (dColAbs == 2 and dRowAbs == 0) then
                    otherCol = playerCol + dCol / 2
                    otherRow = playerLine + dRow / 2
                    otherValue = game:getValue(otherRow, otherCol)
                end
                if row >= 1 and row <= #blood and
                col >= 1 and col <= #blood[row] and
                canHaveBlood(row, col) and not blocksBlood(otherValue, otherRow, otherCol) then
                    for index = 0, count - 1 do
                        if isAntiExplosion then
                            --self:removeBlood(row, col, 1)
                            self:removeAllBlood(row, col)
                        else
                            self:addBlood(row, col, 1)
                        end
                    end
                end
            end
        end
    end
end

function Game:teleport()
    if not canTeleport() then return end
    
    local pos = vec2(0, 0)
    if hasPortablePortal(playerLine, playerCol) then
        local count = #portablePortals
        if count < 2 then
            return
        end
        for i = 1, count do
            local portal = portablePortals[i]
            if portal.pos.x == playerLine and portal.pos.y == playerCol then
                index = (i % count) + 1
                break
            end
        end
        
        pos = portablePortals[index].pos
    else
    local value = self:getValue(playerLine, playerCol)
        local byteValue = string.byte(value)
        local count = #portals[byteValue]
        local index = 1
        for i = 1, count do
            pos = portals[byteValue][i]
            if pos.x == playerLine and pos.y == playerCol then
                index = (i % count) + 1
                break
            end
        end
        
        pos = portals[byteValue][index]
    end

    if math.random() > 0.5 then
        sound(asset.downloaded.Game_Sounds_One.Zapper_1)
    else
        sound(asset.downloaded.Game_Sounds_One.Zapper_2)
    end

    
    self:moveTo(pos.x, pos.y, false, false)
end

function Game:updateVoltage()
    self.voltage = 0
    for i = 1, game.maxInventory do
        if self.inventory[i] ~= nil then
            self.voltage = self.voltage + itemVolts[self.inventory[i]]
        end
    end
end

function Game:canAddInventory(in_item)
    self:updateVoltage()
    
    local itemVoltage = itemVolts[in_item]
    
    if (self.voltage + itemVoltage) > self.maxVoltage then
        return false
    end
    
    local hasAvailableSpot = false
    for i = 1, game.maxInventory do
        if self.inventory[i] == nil then
            hasAvailableSpot = true
            break
        end
    end
    
    return hasAvailableSpot
end

function Game:addInventory(in_item, inInitial)
    local added = false
    
    self:updateVoltage()
    
    local itemVoltage = itemVolts[in_item]
    
    if (self.voltage + itemVoltage) <= self.maxVoltage then
        for i = 1, game.maxInventory do
            if self.inventory[i] == nil then
                self.inventory[i] = in_item
                added = true
                break
            end
        end
        self:updateVoltage()
        if not inInitial then
            sound(DATA, "ZgBAOwBKQFdAQEBAikuGPAysLj7QdFQ+QABAf0BAQEBAcEBA")
            if self.currentMessageId == -1 then
                if in_item == "B" then
                    self:displayMessage(3, nil, true)
                elseif in_item == "X" then
                    self:displayMessage(8, nil, true)
                else
                    self:displayMessage(2, localization:get(in_item, itemName), true)
                end
            end
        end
    else
        sound(asset.downloaded.Game_Sounds_One.Blaster)
        if not self.showVoltages then
            self:displayMessage(104)
        else
            self:displayMessage(6, nil, true)
        end
    end
    
    if added and in_item == "p" and not inInitial then
        for i = 1, #portablePortals do
            if portablePortals[i].pos.x == playerLine and portablePortals[i].pos.y == playerCol then
                table.remove(portablePortals, i)
                break
            end
        end
    end
    
    return added
end

function giveInventory(in_item)
    return game:addInventory(in_item)
end

function giveInventoryFromGround(in_item)
    game:addInventory(in_item)
    for i = 1, game.maxGround do
        if ground[playerLine][playerCol][i] == in_item then
            ground[playerLine][playerCol][i] = nil
            return
        end
    end
end

function initFirstLevel()
    fullLevelLimit = 4
    showLevel = false
    game.inventory = { nil, nil, nil }
    game.showVoltages = false
    blood[playerLine][playerCol] = 3
    blood[playerLine-1][playerCol] = 2
    blood[playerLine+1][playerCol] = 2
    blood[playerLine][playerCol-1] = 2
    blood[playerLine][playerCol+1] = 2
    blood[playerLine-1][playerCol-1] = 1
    blood[playerLine-1][playerCol+1] = 1
    blood[playerLine+1][playerCol-1] = 1
    blood[playerLine+1][playerCol+1] = 1
end

function systemShutDown()
    sound(DATA, "ZgFAJQBfQEBAQEBAPNNfPFOWuD6GvEM+QABAf0BAQEBAa0BA")
    showLevel = false
end

function destroyInventory()
    game.inventory = { nil, nil, nil }
end

function showVoltages()
    game.showVoltages = true
end

function dropItem(in_index)
    local item = game.inventory[in_index]
    
    if item == nil then return end
    
    local dropped = false
    for i = 1, game.maxGround do
        if ground[playerLine][playerCol][i] == nil then
            ground[playerLine][playerCol][i] = item
            dropped = true
            break
        end
    end
    
    if not dropped then return end
    
    game.inventory[in_index] = nil
        
    game:updateVoltage()
    
    if item == "p" then
        local portablePortal = {}
        portablePortal.pos = vec2(playerLine, playerCol)
        table.insert(portablePortals, portablePortal)
    end
end

function destroyItem(in_item)
    for i = 1, game.maxInventory do
        if game.inventory[i] == in_item then
            game.inventory[i] = nil
            break
        end
    end
    
    game:updateVoltage()
end

function canDrop()
    if hasPortal(playerLine, playerCol) then
        return false
    end
    
    if countGround(playerLine, playerCol) >= 3 then
        return false
    end
    
    return true
end

function onDropButton(in_index)
    if game.showVoltages and not game:importantMessage() then
        if game.inventory[in_index] ~= nil then
            if not canDrop() then
                game:displayMessage(9, nil, true)
                return
            end
            recordUndo()
            game:nextMessage()
            dropItem(in_index)
            sound(DATA, "ZgBAHABIQE9AQEBAAAAAAMJphD3lM7U+QABAf0BAQEBAYUBA")
        end
    end
end

function onTakeButton(in_index)
    if game.showVoltages and not game:importantMessage() then
        local item = ground[playerLine][playerCol][in_index]
        if item ~= nil then
            game:nextMessage()
            if game:canAddInventory(item) then
                recordUndo()
            end
            if giveInventory(item) then
                ground[playerLine][playerCol][in_index] = nil
            end
        end
    end
end

function endOfDemo()
    music("A Hero's Quest:Hero's Triumph")
end

function Game:nextMessage()
    local message = self.currentMessage
    local globalMessage = self.globalMessage
    local messageId = self.currentMessageId
    if self.currentMessageId ~= -1 then
        if message["postFunc"] ~= nil then
            if message["postParam"] ~= nil then
                message["postFunc"](message["postParam"])
            else
                message["postFunc"]()                
            end
        end
        if messageId == self.currentMessageId then
            if message["next"] ~= nil then
                self:displayMessage(message["next"], nil, globalMessage)
            else
                self.currentMessageId = -1
            end
        end
    end
end

function Game:tap(inPosition)
    if self.ignoreButtons then return end

    self:nextMessage()
end

function Game:displayMessage(messageId, param1, global)
    self.currentMessageId = messageId
    self.globalMessage = (global == true)
    if global == true then
        self.currentMessage = globalStory[messageId]
    else
        self.currentMessage = story[messageId]
    end
    self.currentParam1 = param1
    if self.currentMessage["preFunc"] ~= nil then
        if self.currentMessage["preParam"] ~= nil then
            self.currentMessage["preFunc"](self.currentMessage["preParam"])
        else
            self.currentMessage["preFunc"]()                
        end
    end
    if self.currentMessage["soundName"] ~= nil then
        if self.currentMessage["soundSeed"] ~= nil then
            sound(self.currentMessage["soundName"], self.currentMessage["soundSeed"])
        else
            sound(self.currentMessage["soundName"])
        end
    end
end

function Game:createButtons(isTake, center)
    left = center - self.itemWidth
    
    for i = 1, game.maxInventory do
        local newButton = Button(
            left - self.itemWidth / 2 + (i - 1) * self.itemWidth + self.itemMargin / 2,
            self.itemY - 18,
            self.itemWidth - self.itemMargin,
            self.itemHeight - self.itemMargin)
        newButton.drawRectangle = true
        newButton.fillRectangle = false
        newButton.strokeWidth = 2
        newButton.keyboardHint = i + (isTake and 3 or 0)
        newButton.keyboardHintFunc = function() return _isJSCodea and game.showVoltages end
        newButton.keyboardHintSize = 12
        newButton.testFunc = function()
            if isTake then
                return ground[playerLine][playerCol][i] ~= nil
            else
                return self.inventory[i] ~= nil
            end
        end
        if isTake then
            newButton.func = function() onTakeButton(i) end
        else
            newButton.func = function() onDropButton(i) end
        end
        table.insert(buttons, newButton)
    end
end

function countItems(items, maxItems)
    local count = 0
    
    for i = 1, maxItems do
        if items[i] ~= nil then
            count = count + 1
        end
    end
    
    return count
end

function Game:drawItems(items, maxItems, center, titleKey, keyOffset, helpKey)
    local defaultFont = font()
    local defaultSize = fontSize()
    local defaultStroke = strokeWidth()
    local itemCount = countItems(items, maxItems)
    
    if itemCount > 0 or self.showVoltages then
        rectMode(CENTER)
        noStroke()
        fill(30)
        rect(center, self.itemY + 11, 3 * self.itemWidth + self.itemMargin, 0.5 * self.itemHeight + 20 + self.itemMargin)
        strokeWidth(1)
        
        fill(255)
        textMode(CENTER)
        text(localization:get(titleKey, gameText), center, self.itemY + 55)
        
        if self.showVoltages and itemCount then
            fontSize(15)
            fill(100)
            text(
                localization:get(helpKey, gameText),
                center, 
                self.itemY - self.itemHeight / 2)
        end
        
        spriteMode(CORNER)
        left = center - self.itemWidth
        for i = 1, maxItems do
            local v = items[i]
            if v ~= nil then
                local textX = left + self.itemWidth * (i - 1) 
                local spriteX = textX - 0.5 * self.itemWidth + self.itemMargin
                if v == "p" then
                    tint(92, 32, 104)
                    sprite(animPortablePortal.image, math.floor(spriteX), self.itemY, cellSize, cellSize)
                    tint(255)
                else
                    sprite(itemSprites[v].image, math.floor(spriteX), self.itemY, cellSize, cellSize)
                end
                if self.showVoltages then
                    textMode(CORNER)
                    fill(255)
                    fontSize(15)
                    text(itemVolts[v] .. "x", textX - 3, self.itemY - 15)
                    fontSize(24)
                    --font("AppleColorEmoji")
                    text("🔋", textX + 12, self.itemY - 15)
                    font(defaultFont)
                end
            end
        end
    end
    
    font(defaultFont)
    fontSize(defaultSize)    
end

function Game:drawVoltages()
    if not self.showVoltages then return end
    
    local defaultFont = font()
    local defaultSize = fontSize()
    local defaultStroke = strokeWidth()
    
    rectMode(CENTER)
    noStroke()
    fill(30)
    rect(WIDTH / 2, self.itemY + 11, 2 * self.itemWidth + 2 * self.itemMargin, 0.5 * self.itemHeight + 20 + self.itemMargin)
    strokeWidth(defaultStroke)
    
    fill(255)
    text(localization:get("energyStatus", gameText), WIDTH / 2, self.itemY + 55)
    
    local batteryOffset = 50
    local availableVoltage = 3 - self.voltage
    for i = 1, self.maxVoltage do
        local left = WIDTH / 2 + (i - 2) * batteryOffset
        textMode(CENTER)
        fontSize(40)
        if i <= availableVoltage then
            fill(255)
            text("🔋", left, self.itemY + 10)
        else
            -- TODO Find a way to support transparent / tinted emojis in JSCodea
            if not _isJSCodea then
                fill(255, 255, 255, 30)
                text("🔋", left, self.itemY + 10)
            end
        end
    end
    
    font(defaultFont)
    fontSize(defaultSize)    
end

function Game:drawMessage()
    local defaultFont = font()
    
    if self.currentMessageId ~= -1 then
        textMode(CENTER)
        textAlign(CENTER)
        fontSize(20)
        
        local tapMessage
        local tapWidth = 0
        local messageWidth = 0
        if not self:lastMessage() then
            if _isJSCodea then
                tapMessage = localization:get("enterContinue", gameText)
            else
                tapMessage = localization:get("tapContinue", gameText)
            end
            tapWidth = textSize(tapMessage)
        end
        
        fill(255, 255, 255, 255)
        
        local key = "text"
        
        if _isJSCodea and self.currentMessage["jscodea"] ~= nil then
            key = "jscodea"
        end
        
        message = localization:get(
            self.currentMessage[key],
            self.globalMessage and gameText or nil)
        if self.currentParam1 ~= nil then
            message = string.gsub(message, "{0}", self.currentParam1)
        end
        if message:starts("-=") then
            message = string.upper(message)
        end
        messageWidth = textSize(message)
        
        rectMode(CENTER)
        stroke(200)
        strokeWidth(2)
        fill(0, 0, 0, 150)
        rect(WIDTH/2, 100, math.max(tapWidth, messageWidth) + 50, 60)
        
        if message:starts("-=") then
            fill(0, 171, 255, 255)
        else
            fill(182, 167, 137, 255)
        end
        
        text(message, WIDTH/2, 115)
        fill(255, 255, 255, 255)
        if self:importantMessage() then
            font("Baskerville-SemiBoldItalic")
            pushMatrix()
            translate(WIDTH/2, 85)
            scale(0.95 + 0.05 * math.sin(0.2 * self.time))
            if not self:lastMessage() then
                if _isJSCodea then
                    text(localization:get("enterContinue", gameText))
                else
                    text(localization:get("tapContinue", gameText))
                end
            end
            popMatrix()
        end
        fontSize(20)
    end
    
    font(defaultFont)
end

function Game:draw()
    self.swipeHandler:update()
    
    if isRuntime() then
        if _keyboardLeftBegan then
            self:swipe(vec2(0, 0), SwipeLeft, -1, 0)
        end
        if _keyboardRightBegan then
            self:swipe(vec2(0, 0), SwipeRight, 1, 0)
        end
        if _keyboardUpBegan then
            self:swipe(vec2(0, 0), SwipeUp, 0, 1)
        end
        if _keyboardDownBegan then
            self:swipe(vec2(0, 0), SwipeDown, 0, -1)
        end
    end
    
    self.time = self.time + 0.1666
    
    strokeWidth(3)
    
    self:drawMessage()
    local dropKey = _isJSCodea and "keyboardDrop" or "drop"
    local takeKey = _isJSCodea and "keyboardTake" or "take"
    self:drawItems(self.inventory, self.maxInventory, self.inventoryCenter, "installed1", 0, dropKey)
    self:drawItems(ground[playerLine][playerCol], self.maxGround, self.groundCenter, "ground", 3, takeKey)
    self:drawVoltages()

    drawButtons()
end

function canShowButtons()
    return game.showVoltages and
           not game:importantMessage() and
           not isSwitch(game:getValue(playerLine, playerCol))
end
