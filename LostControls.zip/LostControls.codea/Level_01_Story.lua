stories[1] = {}
stories[1][1] = { ["text"] = "01", ["next"] = 2}
stories[1][2] = { ["text"] = "02", ["next"] = 3}
stories[1][3] = { ["text"] = "03", ["next"] = 4}
stories[1][4] = { ["text"] = "04", ["next"] = 5}
stories[1][5] = { ["text"] = "05", ["next"] = 6}
stories[1][6] = { ["text"] = "06", ["next"] = 7}
stories[1][7] = { ["text"] = "07", ["next"] = 8}
stories[1][8] = { ["text"] = "08", ["next"] = 9}
stories[1][9] = { ["text"] = "09", ["next"] = 10}
stories[1][10] = { ["text"] = "10", ["next"] = 11}
stories[1][11] = { ["text"] = "11", ["next"] = 12}
stories[1][12] = { ["text"] = "12", ["next"] = 13}
stories[1][13] = { ["text"] = "13", ["next"] = 14}
stories[1][14] = { ["text"] = "14", ["next"] = 15}
stories[1][15] = { ["text"] = "15", ["next"] = 16}
stories[1][16] = { ["text"] = "16", ["next"] = 109}
stories[1][17] = { ["text"] = "17", ["next"] = 29}
stories[1][18] = { ["text"] = "18", ["next"] = 19}
stories[1][19] = { ["text"] = "19", ["next"] = 20}
stories[1][20] = { ["text"] = "20", ["next"] = 21}
stories[1][21] = { ["text"] = "21", ["next"] = 22}
stories[1][22] = { ["text"] = "22", ["next"] = 23}
stories[1][23] = { ["text"] = "23", ["next"] = 24}
stories[1][24] = { ["text"] = "24", ["next"] = 25}
stories[1][25] = { ["text"] = "25", ["next"] = 26}
stories[1][26] = { ["text"] = "26", ["next"] = 27}
stories[1][27] = { ["text"] = "27", ["next"] = 28}
stories[1][28] = { ["text"] = "28", ["next"] = 30}
stories[1][29] = { ["text"] = "", ["next"] = 18}
stories[1][30] = { ["text"] = "30", ["next"] = 31}
stories[1][31] = { ["text"] = "31", ["next"] = 32}
stories[1][32] = { ["text"] = "32"}

stories[1][104] = { ["text"] = "104", ["next"] = 17 }
stories[1][109] = { ["text"] = "109", ["next"] = 110, ["jscodea"] = "109_jscodea" }
stories[1][110] = { ["text"] = "110" }

stories[1][1]["preFunc"] = initFirstLevel
stories[1][1]["soundName"] = DATA
stories[1][1]["soundSeed"] = "ZgBANwBIQGNASWNAAAAAAG/5Rj4m6ZA+QABAf0BAQEBAQEBA"

stories[1][2]["postFunc"] = setShowLevel
stories[1][2]["postParam"] = true

stories[1][10]["postFunc"] = giveInventory
stories[1][10]["postParam"] = "N"

stories[1][17]["postFunc"] = systemShutDown

stories[1][18]["soundName"] = DATA
stories[1][18]["soundSeed"] = "ZgBANwBIQGNASWNAAAAAAG/5Rj4m6ZA+QABAf0BAQEBAQEBA"

stories[1][19]["postFunc"] = setShowLevel
stories[1][19]["postParam"] = true

stories[1][27]["postFunc"] = showVoltages
