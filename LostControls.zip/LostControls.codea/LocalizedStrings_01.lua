levelStrings[1] = {}

levelStrings[1]["en"] = {}
levelStrings[1]["fr"] = {}

levelStrings[1]["en"]["01"] = "-= SYSTEM BOOT SUCCESSFUL - v. 2.0.1 =-"
levelStrings[1]["fr"]["01"] = "-= SYSTÈME INITIALISÉ - v. 2.0.1 =-"

levelStrings[1]["en"]["02"] = "-= ACTIVATING CAMERAS =-"
levelStrings[1]["fr"]["02"] = "-= ACTIVATION DES CAMÉRAS =-"

levelStrings[1]["en"]["03"] = "-= LIQUID LEAK DETECTED =-"
levelStrings[1]["fr"]["03"] = "-= PERTE DE LIQUIDE DÉTECTÉE =-"

levelStrings[1]["en"]["04"] = "-= ANALYZING LIQUID =-"
levelStrings[1]["fr"]["04"] = "-= ANALYSE DU LIQUIDE =-"

levelStrings[1]["en"]["05"] = "-= LIQUID ANALYZED : Human Blood =-"
levelStrings[1]["fr"]["05"] = "-= RÉSULTAT DE L'ANALYSE : Sang Humain =-"

levelStrings[1]["en"]["06"] = "-= LAUNCHING MIND SOFTWARE =-"
levelStrings[1]["fr"]["06"] = "-= LANCEMENT DU LOGICIEL DE PENSÉE =-"

levelStrings[1]["en"]["07"] = "Wh-where am I?"
levelStrings[1]["fr"]["07"] = "Où... où suis-je?"

levelStrings[1]["en"]["08"] = "-= GPS MODULE MISSING =-"
levelStrings[1]["fr"]["08"] = "-= MODULE GPS MANQUANT =-"

levelStrings[1]["en"]["09"] = "Great... Anything else missing?"
levelStrings[1]["fr"]["09"] = "Super... Il manque autre chose?"

levelStrings[1]["en"]["10"] = "-= MODULES INSTALLED : North Module =-"
levelStrings[1]["fr"]["10"] = "-= MODULES INSTALLÉS : Module Nord =-"

levelStrings[1]["en"]["11"] = "That's all? I can only move North?!"
levelStrings[1]["fr"]["11"] = "C'est tout? Je peux simplement me déplacer vers le Nord?!"

levelStrings[1]["en"]["12"] = "-= AFFIRMATIVE =-"
levelStrings[1]["fr"]["12"] = "-= AFFIRMATIF =-"

levelStrings[1]["en"]["13"] = "Great... Anything else I should know?"
levelStrings[1]["fr"]["13"] = "Super... Autre chose à savoir?"

levelStrings[1]["en"]["14"] = "-= LIQUID LEAK DETECTED : Human Blood =-"
levelStrings[1]["fr"]["14"] = "-= PERTE DE LIQUIDE DÉTECTÉE : Sang Humain =-"

levelStrings[1]["en"]["15"] = "Blood! How is this even possible? I'm a robot!"
levelStrings[1]["fr"]["15"] = "Du sang! Comment est-ce possible? Je suis un robot!"

levelStrings[1]["en"]["16"] = "Better get to the EXIT (DIAMOND) now..."
levelStrings[1]["fr"]["16"] = "Je devrais aller à la SORTIE (DIAMANT) maintenant..."

levelStrings[1]["en"]["17"] = "-= CRITICAL ERROR - SYSTEM SHUTDOWN =-"
levelStrings[1]["fr"]["17"] = "-= ERREUR CRITIQUE - MISE HORS TENSION =-"

levelStrings[1]["en"]["18"] = "-= SYSTEM BOOT SUCCESSFUL - v. 2.0.1 =-"
levelStrings[1]["fr"]["18"] = "-= SYSTÈME INITIALISÉ - v. 2.0.1 =-"

levelStrings[1]["en"]["19"] = "-= RECOVERING SYSTEM. =-"
levelStrings[1]["fr"]["19"] = "-= RESTAURATION SYSTÈME. =-"

levelStrings[1]["en"]["20"] = "-= RECOVERING SYSTEM.. =-"
levelStrings[1]["fr"]["20"] = "-= RESTAURATION SYSTÈME.. =-"

levelStrings[1]["en"]["21"] = "Hello?!"
levelStrings[1]["fr"]["21"] = "Allo?!"

levelStrings[1]["en"]["22"] = "-= RECOVERING SYSTEM... =-"
levelStrings[1]["fr"]["22"] = "-= RESTAURATION SYSTÈME... =-"

levelStrings[1]["en"]["23"] = "-= RECOVERING SYSTEM.... =-"
levelStrings[1]["fr"]["23"] = "-= RESTAURATION SYSTÈME.... =-"

levelStrings[1]["en"]["24"] = "-= RECOVERING SYSTEM..... =-"
levelStrings[1]["fr"]["24"] = "-= RESTAURATION SYSTÈME..... =-"

levelStrings[1]["en"]["25"] = "-= SYSTEM RESTORED =-"
levelStrings[1]["fr"]["25"] = "-= RESTAURATION TERMINÉE =-"

levelStrings[1]["en"]["26"] = "Hey, where's the new Blood Module?"
levelStrings[1]["fr"]["26"] = "Hey, où est le nouveau Module Sang?"

levelStrings[1]["en"]["27"] = "-= POWER SURGE DETECTED - TOO MANY MODULES =-"
levelStrings[1]["fr"]["27"] = "-= SURCHARGE DÉTECTÉE - TROP DE MODULES =-"

levelStrings[1]["en"]["28"] = "Aw, come on!"
levelStrings[1]["fr"]["28"] = "Oh, et quoi encore!"

levelStrings[1]["en"][""] = ""
levelStrings[1]["fr"][""] = ""

levelStrings[1]["en"]["30"] = "-= SURGE PROTECTION ENGAGED =-"
levelStrings[1]["fr"]["30"] = "-= PROTECTION DE SURCHARGE ACTIVÉE =-"

levelStrings[1]["en"]["31"] = "-= AUTO-INSTALLING MODULES DISABLED =-"
levelStrings[1]["fr"]["31"] = "-= INSTALLATION AUTOMATIQUE DE MODULES DÉSACTIVÉE =-"

levelStrings[1]["en"]["32"] = "Oh well... I guess that's fine."
levelStrings[1]["fr"]["32"] = "Et bien... Je suppose que c'est pour le mieux."

levelStrings[1]["en"]["104"] = "-= BLO0D FOL1oW1nG M@dulE InSt... =-"
levelStrings[1]["fr"]["104"] = "-= M0DuL3 De sU1vi dE SanG 1nst... =-"

levelStrings[1]["en"]["109"] = "-= SWIPE FINGER TO MOVE ROBOT =-"
levelStrings[1]["fr"]["109"] = "-= GLISSER VOTRE DOIGT POUR DÉPLACER LE ROBOT =-"

levelStrings[1]["en"]["109_jscodea"] = "-= USE THE ARROW KEYS TO MOVE THE ROBOT =-"
levelStrings[1]["fr"]["109_jscodea"] = "-= UTILISEZ LES TOUCHES DIRECTIONNELLES POUR DÉPLACER LE ROBOT =-"

levelStrings[1]["en"]["110"] = "-= FIND HOW TO GET TO THE EXIT (DIAMOND) =-"
levelStrings[1]["fr"]["110"] = "-= TROUVEZ COMMENT ATTEINDRE LA SORTIE (DIAMANT) =-" 
