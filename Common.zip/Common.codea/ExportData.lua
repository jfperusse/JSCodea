-- DO NOT MODIFY THIS FILE MANUALLY!
exportDataArray = {}
exportDataArray["s"] = "string"
exportDataArray["b"] = false
exportDataArray["n"] = 186787
