function readTilesetAsset(tileSize, assetName, outSprites)
    local spriteSheet = readImage(assetName)
    local spriteRows = spriteSheet.height / tileSize
    local spriteColumns = spriteSheet.width / tileSize 
    for row = 1, spriteRows do
        for col = 1, spriteColumns do
            local x = (col - 1) * tileSize + 1
            local y = (row - 1) * tileSize + 1
            local img = spriteSheet:copy(x, y, tileSize, tileSize)
            local spr = {}
            spr.image = img
            spr.isAnim = false
            table.insert(outSprites, spr)
        end
    end
end

function readAnimImage(tileSize, img, msPerFrame)
    local frameCount = img.width / tileSize 
    local spr = {}
    spr.isAnim = true
    spr.images = {}
    spr.msPerFrame = msPerFrame
    spr.msLeft = msPerFrame
    spr.imageIndex = 1
    for frame = 1, frameCount do
        local x = (frame - 1) * tileSize + 1
        local img = img:copy(x, 1, tileSize, tileSize)
        table.insert(spr.images, img)
    end
    spr.imageIndex = math.random(1, frameCount)
    spr.image = spr.images[spr.imageIndex]
    return spr
end

function readAnimAsset(tileSize, asset, msPerFrame)
    local img = readImage(asset)
    return readAnimImage(tileSize, img, msPerFrame)
end

function copyAnim(anim)
    local newAnim = {}
    newAnim.isAnim = true
    newAnim.images = anim.images
    newAnim.msPerFrame = anim.msPerFrame
    newAnim.msLeft = anim.msPerFrame
    newAnim.imageIndex = math.random(1, #anim.images)
    newAnim.image = newAnim.images[newAnim.imageIndex]
    return newAnim
end

function updateAnims(anims)
    for i, v in ipairs(anims) do
        v.msLeft = v.msLeft - DeltaTime * 1000
        if v.msLeft < 0 then
            v.msLeft = v.msPerFrame
            v.imageIndex = (v.imageIndex % #v.images) + 1
            v.image = v.images[v.imageIndex]
        end
    end
end
