displayMode(FULLSCREEN)

function setup()    
    print(string.trim("    trim    "))
    
    Button.useAppFont = true
    
    --[[
    testTable={1, 2, 3}
    testClone=table.clone(testTable)
    testClone[2]=4
    print(json.encode(testTable))
    print(json.encode(testClone))
    
    testTable={a=1, b=2}
    print(json.encode(testTable))
    
    local tb = base64.enc("patate:carotte")
    print(tb)
    print(base64.dec(tb))
    
    testString = "  Text  "      
    print("Trim test => '" .. testString .. "' : '" .. trim(testString) .. "'")
    
    testString = "a,b,c,d,e"
    result = testString:split(",")
    print("Split test")
    for i,v in ipairs(result) do
        print("  " .. i .. " => " .. v)
    end
    
    localizedStrings = {}
    localizedStrings["en"] = {}
    localizedStrings["fr"] = {}
    localizedStrings["en"]["en_only"] = "English Only"
    localizedStrings["fr"]["fr_only"] = "French Only"
    localizedStrings["en"]["both"] = "Both"
    localizedStrings["fr"]["both"] = "Tous"
    
    localization = Localization()
    localization.language = "fr"
    if isNative() then
        print("Device language : " .. native.getDeviceLanguage())
    end
    print(localization:get("en_only"))
    print(localization:get("fr_only"))
    print(localization:get("both"))
    
    for i = 3, 1 do
        print("revTest" .. i)
    end
    
    startTest = "qwertyuiop"
    if not startTest:starts("qwerty") then print("error") end
    if startTest:starts("uiop") then print("error") end
    if not startTest:ends("uiop") then print("error") end
    if startTest:ends("qwerty") then print("error") end
    
    myTable = {}
    table.insert(myTable, "a")
    table.insert(myTable, "b")
    print("Contains a? " .. tostring(table.contains(myTable, "a")))
    print("Contains c? " .. tostring(table.contains(myTable, "c")))
    
    debugExportTabs = true
    print("Reading export tab s : " .. readExportData("s", "default"))
    print("Reading export tab b : " .. tostring(readExportData("b", false)))
    print("Reading export tab n : " .. readExportData("n", 0))
    debugExportTabs = false
    
    print("Reading default export t : " .. readExportData("t", "default"))
    saveExportData("s", "string")
    print("Reading export s : " .. readExportData("s", "default"))
    saveExportData("b", not readExportData("b", false))
    saveExportData("n", math.random(1, 1000000))
    print("Reading export b : " .. tostring(readExportData("b", false)))
    print("Reading export n : " .. readExportData("n", 0))
    --]]
    
    --[[
    local timer = PerfTimer("TestTimer")
    local num = 0
    for i = 0, 1000000 do
        num = num + 1
    end
    timer:pauseAndPrint()
    timer:resume()
    for i = 0, 1000000 do
        num = num + 1
    end
    timer:pauseAndPrint()
    timer:restart("TestTimer2")
    for i = 0, 10000000 do
        num = num + 1
    end
    timer:pauseAndPrint()
    --]]
    
    --perfTests()
    
    --funcPerfTests()
    
    buttons = {}
    
    button = AddButton(WIDTH/2 - 100, HEIGHT/2 + 10, 200, 50, "Teleporter",
        function()
            print("Down1")
    end)
    button.keyboardHint = "Space"
    button.keyboardHintFunc = function() return ((math.floor(ElapsedTime) % 2) == 1) end
    button.keyboardHintSize = 10
    button.releasedFunc = function()
        print("Up1")
    end
    
    button = AddButton(WIDTH/2 - 100, HEIGHT/2 - 60, 200, 50, "Test3",
    function()
        print("Down3")
    end)
    button:setTestFunc(function() return math.random(1, 100) < 98 end)
    
    button = AddSpriteButton(WIDTH/2 - 100, HEIGHT/2 + 100, 200, 200, asset.Icon2,
        function()
            print("Down2")
            button.spriteAngle = button.spriteAngle + 10
        end)
    button.releasedFunc = function()
        print("Up2")
    end
    button.text = "Test2"
    button.textOffset.y = -80
    button.textColor = color(0, 0, 0)
    button.drawRectangle = true
    button.testFunc = function() return true end
    button.fillRectangle = false
    
    tab1 = {1,2,3}
    tab2 = {}
    table.move(tab1, 1, 3, 1, tab2)
    print(table.concat(tab1, ","))
    print(table.concat(tab2, ","))
    
    AddButton(0, 0, 50, 50, "BottomLeft")
    AddButton(WIDTH - 50, 0, 50, 50, "BottomRight")
    AddButton(0, HEIGHT - 50, 50, 50, "TopLeft")
    AddButton(WIDTH - 50, HEIGHT - 50, 50, 50, "TopRight")
end

regA = 0
regs = { a = 0 }
regs2 = { a = { val = 0 } }
regs3 = { 0 }
local regL = 0

function globalFunc()
    regs3[1] = regs3[1] + 1
end

local function localFunc()
    regs3[1] = regs3[1] + 1
end

local localizedFunc = globalFunc

function funcPerfTests()
    local timer = PerfTimer("Global")
    for i = 0, 1000000 do
        globalFunc()
    end
    timer:pauseAndPrint()
    timer:restart("Local")
    for i = 0, 1000000 do
        localFunc()
    end
    timer:pauseAndPrint()
    timer:restart("Localized")
    for i = 0, 1000000 do
        localizedFunc()
    end
    timer:pauseAndPrint()
    local globalFunc = globalFunc
    timer:restart("Localized2")
    for i = 0, 1000000 do
        globalFunc()
    end
    timer:pauseAndPrint()
end

function perfTests()
    local timer = PerfTimer("Access1")
    for i = 0, 1000000 do
        regA = regA + 1
    end
    timer:pauseAndPrint()
    timer:restart("Access2")
    for i = 0, 1000000 do
        regs.a = regs.a + 1
    end
    timer:pauseAndPrint()
    timer:restart("Access3")
    for i = 0, 1000000 do
        regs2.a.val = regs2.a.val + 1
    end
    timer:pauseAndPrint() 
    timer:restart("Access4")
    local val = regs2.a
    for i = 0, 1000000 do
        val.val = val.val + 1
    end
    timer:pauseAndPrint()
    timer:restart("Access5")
    val = regs3
    for i = 0, 1000000 do
        val[1] = val[1] + 1
    end
    timer:pauseAndPrint()
    timer:restart("AccessFileLocal")
    for i = 0, 1000000 do
        regL = regL + 1
    end
    timer:pauseAndPrint()
    timer:restart("AccessOtherFile")
    for i = 0, 1000000 do
        testValue = testValue + 1
    end
    timer:pauseAndPrint()
end

function touched(touch)
    trackTouch(touch)
    
    for i,v in ipairs(buttons) do
        v:touched(touch)
    end
end

function drawButtons()
    for i,v in ipairs(buttons) do
        v:draw()
    end
end

function draw()
    background(0)

    drawButtons()
    
    drawTouches()
    
    --spriteMode(CENTER)
    --sprite("Project:Icon2", WIDTH/2, HEIGHT/2, HEIGHT - 200, HEIGHT - 200)
    --fill(0)
    --rectMode(CORNER)
    --rect(0, HEIGHT - 101, WIDTH, 100)
end
