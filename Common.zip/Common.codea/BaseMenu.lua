BaseMenu = class()

function BaseMenu:init()

end

function BaseMenu:onActivate()
    buttons = {}
end

function BaseMenu:onDeactivate()
    
end

function BaseMenu:update()

end

function BaseMenu:draw()
    
end

function BaseMenu:touched(touch)

end

function BaseMenu:collide(contact)
    
end
